# DSH Codex Controller

`@shamcleren/dsh-codex-controller` adds a `codex_delegate` tool to DeepSeek Harness. The bundle composes the verified `@deepseek-ai/dsh-subagent-codex` provider, which starts the official Codex wrapper in `app-server --stdio` mode for each delegation, and the shared `@deepseek-ai/dsh-tool-subagent` consumer.

## Install

```sh
dsh plugin --profile web add /absolute/path/to/dsh-codex-controller
dsh web
```

Codex authentication and settings come from the native Codex configuration visible to the Host process. The plugin does not log in, create `CODEX_HOME`, select a model, or copy credentials into DSH configuration.

## Behavior

Each `codex_delegate` call creates one managed Codex process, one ephemeral thread, and one turn in the calling session's workspace. The provider performs `initialize`, `initialized`, `thread/start`, and `turn/start`, selects the final answer from terminal app-server notifications, and waits for the complete process tree to stop during cancellation or disposal.

The public tool accepts the shared subagent arguments, including a self-contained task and optional `run_in_background`. Foreground calls return the final Codex answer. Background calls return a Job id for `job_output` and `job_kill`.

## Permissions

The bundled provider uses `permissionMode: never`. Codex keeps its native sandbox and does not wait for a human approval channel; unattended command and file escalation requests are declined. A profile may replace the complete `codex-controller-provider` row with `permissionMode: approve-for-me` after reviewing the automated reviewer behavior.

The bundle does not enable `dangerously-bypass-approvals-and-sandbox`. Operators who add that mode assume responsibility for every filesystem and command side effect performed by the Codex worker.

## Model Experience

The model sees one static `codex_delegate` tool and a short policy requiring explicit human intent, a self-contained task, and safe handling of sandbox limitations. Codex reasoning, intermediate tool activity, stderr, protocol messages, and product identifiers do not enter the parent conversation; only the selected final answer or a bounded diagnostic does.

Codex token use and KV cache are independent from the parent agent. The parent sees only appended tool or Job messages, so earlier parent cache prefixes remain unchanged.

## Known Limitations and Deferred Work

`pnpm check` includes a real keyless handshake using the provider's pinned Codex binary and an isolated Codex configuration directory. It exercises `initialize`, `initialized`, and `config/read` without starting a model turn or reading the user's authentication. This does not replace an authorized end-to-end delegation test. See the [official app-server protocol](https://learn.chatgpt.com/docs/app-server).

- Every call creates a fresh process, ephemeral thread, and turn. Persistent Codex threads, resume, fork, progress streaming, and pooling are not exposed.
- The default mode cannot relay a Codex approval request to the DSH approval UI. It fails closed instead.
- The provider protocol baseline is pinned by `@deepseek-ai/dsh-subagent-codex@0.1.0-rc.8`; upgrading its Codex dependency requires the provider's schema and real-product verification.
- The child receives the parent workspace and task text, not the parent transcript, role, tools, or structured-output request.
