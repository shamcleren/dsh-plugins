import type { Config as PlainConfig } from './config.js';
import { type Volatile, type Context } from '@deepseek-ai/cordis';
export { WeComBotAccount } from './account.js';
export type { WeComBotClient } from './account.js';
export declare const Config: import("@deepseek-ai/schemastery").default<NoInfer<PlainConfig>, NoInfer<PlainConfig>, "volatile">;
export { DEFAULT_BOT_ID_ENV, DEFAULT_SECRET_ENV, DEFAULT_THINKING_TEXT, DEFAULT_TURN_TIMEOUT_MS, DEFAULT_WORKSPACE_NAME, } from './config.js';
export type { Config as WeComAiBotConfig, WeComCredentials, } from './config.js';
/** Stable Cordis plugin name. */
export declare const name = "wecom-aibot";
/** Host gateway required for durable session and turn orchestration. */
export declare const inject: string[];
/** User-settings namespace that keeps this installed plugin configurable while disconnected. */
export declare const WECOM_AIBOT_SETTINGS_NAMESPACE = "wecom-aibot";
/** Connect one configured WeCom Bot for the lifetime of this plugin fiber. */
export declare function apply(ctx: Context, config: PlainConfig | Volatile<PlainConfig>): void;
