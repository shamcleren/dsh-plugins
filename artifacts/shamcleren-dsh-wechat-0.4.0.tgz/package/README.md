# `@shamcleren/dsh-wechat`

Personal WeChat channel for DeepSeek Harness, backed by Tencent's official iLink Bot protocol.

## Install

Install through **Remote Market** or from this repository's local release tarball. For source changes, build `plugins/wechat` before installing the directory. See the [plugin management guide](../../docs/plugin-management.md) for commands, updates, removal, and the `before-web-app` ordering required after local installation. Loading the plugin starts all previously bound accounts automatically. New accounts need only QR authorization.

## Capabilities

- QR-code login with local owner-only credential persistence.
- Multiple authorized accounts, all started automatically.
- Restart-safe long-poll cursors and per-peer reply context tokens.
- Direct text and image prompts; voice transcription, file names, and video notices are retained as text.
- Durable account-and-peer Session routing and callback deduplication. Messages steer an active channel-owned turn; otherwise they queue through the upstream Host API. A rejected steer retries once as queued input.
- Final assistant output accumulated across model steps, Unicode-safe outbound chunking, and typing indicators.
- `/new`, Host slash commands, `/approve`, `/reject`, and `/answer` interaction replies.
- Channel-owned approvals use the upstream approval waterfall and canonical audit id; unrelated sessions delegate to the Host UI. Questions use the Host interaction API. Web and WeChat do not present the same approval concurrently.

## Login

Open the WeChat card under Plugins settings and select **Connect WeChat**. Scan and confirm in WeChat; the plugin saves the account and starts receiving messages automatically, without writing settings. The card presents a numeric verification field if WeChat requests one. No user ID, administrator ID, or separate start action is required. **Add account** starts another authorization flow and includes the new account in an existing account selection.

Chat is open to anyone who can send a direct message to the bot. No WeChat name, allowed-user ID, account selection or enable switch is needed. Management commands and WeChat tool approvals belong to the scanning owner, identified automatically by the iLink callback; other users' tool approvals remain with the DSH Host. Separate account/peer pairs have separate sessions. If the callback has no owner identity, reconnect instead of granting management to arbitrary users.

The card contains QR binding, add-account and refresh actions, plus a separate receiver status. “Bound” means credentials were saved; “receiver running” describes the local polling service and is not a guarantee of upstream connectivity. Keep DSH running to receive messages. Disable/unload the plugin to stop; loading it again resumes bound accounts without another QR scan. Existing `enabled`, `accountIds`, `allowedUsers` and `adminUsers` settings are retired and do not control startup or access.

Credentials, poll cursors and peer context tokens remain under `<dsh-home>/channels/wechat/accounts.json`, with owner-only permissions. They never enter the browser response or composition. Newly created default conversations use `<dsh-home>/workspaces/wechat`, separate from channel credentials. Existing sessions and explicitly selected workspaces are retained.

## Automatic defaults

No settings form is required. New sessions use the managed “微信机器人” workspace and inherit the DSH default agent preset/model. Defaults are a five-minute turn observation limit, 20 MiB inbound image limit, a thinking message and typing indicators. Existing optional operational settings remain compatible, but there are no ID or tuning inputs on the card. Channel access does not bypass DSH tool permissions or approval policies.

## Protocol limits

Tencent iLink currently exposes direct-chat semantics to this plugin. Group behavior is not advertised. Harness prompt transport accepts text and image bytes, so voice uses Tencent's transcript when available; files and videos retain descriptive metadata instead of injecting unsupported binary prompt blocks. Assistant replies are text-only because durable assistant messages currently expose text content to external channels.

## Development

```sh
pnpm --filter @shamcleren/dsh-wechat test
pnpm --filter @shamcleren/dsh-wechat typecheck
pnpm --filter @shamcleren/dsh-wechat build
```
