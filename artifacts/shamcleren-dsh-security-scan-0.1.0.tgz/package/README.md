# 代码安全扫描

`@shamcleren/dsh-security-scan` 提供 `security_scan` 工具和 `security-review` Skill，面向 Python、Go、JavaScript/TypeScript。使用官方 DSH `0.1.0-rc.8` 的工具、Skill、设置扩展点，不修改官方代码。

## 安装和使用

在仓库根目录执行，完成后重启 DSH：

```sh
make plugin-install PLUGIN=security-scan
```

也可在远端市场刷新目录后安装 **Code Security Scan**。两种方式安装同一个包；原生市场与远端市场保持独立。

在 DSH 中选择要审查的项目，直接说：

> 使用 security-review 检查当前项目的 Python、Go 和 JS 代码，先扫描再逐项复核，输出文件行号、触发条件和修复建议。

也可以指定子目录，例如“只审查 backend/ 的认证和文件上传”。工具参数 `path` 仅接受当前工作区内的目录；`mode=inventory` 仅提供覆盖清单，默认 `auto` 尝试使用 Semgrep。工具不会自行调用额外 LLM，复核使用当前 DSH 会话模型。**没有 Semgrep 也能使用审计 Skill，但会明确标记静态扫描未执行。**

## 可选：启用本地 Semgrep

当前实际验证版本为 **Semgrep CE 1.176.1**。若已有 Python 3.10+ 和 pipx，可按 [Semgrep 安装说明](https://docs.semgrep.dev/getting-started/quickstart) 安装固定版本：

```sh
pipx install semgrep==1.176.1
command -v semgrep
```

若桌面 App 的 PATH 找不到它，在 DSH 设置的 `security-scan` 命名空间指定上面输出的绝对路径；也可编辑实际 DSH 数据目录的 `settings.yaml`，示例：

```yaml
security-scan:
  semgrepPath: /absolute/path/to/semgrep
```

配置写在 DSH 设置中，不写在待扫描项目里。配置的扫描器必须位于工作区外，不能指向待审计项目提供的可执行文件。版本不匹配时返回 `unsupported-scanner`；安装插件本身不下载或执行 Python 安装器，不修改全局环境。

## 扫描与复核范围

包内自有规则覆盖 12 类候选风险：Python shell/eval/pickle/TLS/unsafe YAML，Go shell/TLS/格式化 SQL，JS/TS eval/shell/TLS/HTML sink。命中统一标成 `needs-review`，由模型追踪调用链、输入控制及已有防护后确认或排除；危险 API 的存在不等于漏洞。

Skill 另外检查认证授权、租户隔离、SSRF、路径和归档处理、会话凭据及业务流程。当前没有集成依赖 CVE 数据库、专用密钥检测器、动态漏洞利用或自动修复。LLM 的结论与质量依赖当前模型及提供的代码上下文，测试通过不代表能发现所有漏洞。

## 数据与执行边界

- 源文件在本机复制到私有临时目录后扫描；不执行项目、安装钩子或自带扫描配置，结束后删除快照。Semgrep 只使用包内规则，关闭指标和版本检查，不连接规则注册表，也不上传源码；LLM 复核的代码读取遵循当前 DSH 模型的数据流。
- 默认排除隐藏条目、符号链接、依赖和构建目录，只处理 `.py/.go/.js/.jsx/.mjs/.cjs/.ts/.tsx`。**不使用项目 `.gitignore` 或 `.semgrepignore`**；实际扫描的是报告列出的受限快照。
- 上限：1,500 个源文件、20,000 个目录项、单文件 1 MiB、总源码 32 MiB、每次扫描器进程 120 秒；报告最多返回 200 个文件位置和 200 个命中，其余计数会保留。通过 `path` 分批审查大项目。
- 返回规则、相对文件路径、行号和 CWE，不返回源码片段、匹配中的密钥或原始扫描器日志。报告要求区分已确认、待确认、已排除和未覆盖；`partial`、失败和缺少扫描器不能当成安全结论。
- 取消或卸载会终止并等待插件拥有的扫描进程。工具临时文件不进入被扫描仓库；插件不更改用户代码或依赖。

## 验证与开发

```sh
pnpm --filter @shamcleren/dsh-security-scan typecheck
pnpm --filter @shamcleren/dsh-security-scan test
SECURITY_TEST_SEMGREP=/absolute/path/to/semgrep pnpm --filter @shamcleren/dsh-security-scan test
pnpm --filter @shamcleren/dsh-security-scan build
```

默认测试跳过需要真实 Semgrep 的用例，并明确显示跳过；设置上述变量后才验证真实扫描器的正反例。选型依据见 [方案比较](../../docs/decisions/security-scan.md)。
