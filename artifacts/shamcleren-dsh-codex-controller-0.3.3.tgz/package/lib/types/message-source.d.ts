import type { ContextFormed } from '@deepseek-ai/dsh-llm';
declare module '@deepseek-ai/dsh-llm' {
    interface MessageSourceMap {
        'plugin:codex-controller': {
            kind: 'plugin:codex-controller';
        } & ContextFormed;
        'codex-controller': {
            kind: 'codex-controller';
        } & ContextFormed;
    }
}
