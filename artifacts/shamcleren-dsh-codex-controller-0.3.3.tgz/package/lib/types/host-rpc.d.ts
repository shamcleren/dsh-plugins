import type { Context } from '@deepseek-ai/cordis';
import { type ConnectionRpcHandler } from '@deepseek-ai/dsh-client-connection';
type RpcHandler = ConnectionRpcHandler;
export declare function registerHostRpc(ctx: Context, channel: string, handler: RpcHandler): void;
export {};
