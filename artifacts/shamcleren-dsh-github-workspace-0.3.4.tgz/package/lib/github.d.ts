import { z } from 'zod';
import type { Account, Login, Owner, Repository } from './types.js';
import type { Execute, CommandOptions } from './process.js';
export declare const repositoryName: z.ZodString;
export declare class GitHub {
    private readonly run;
    private readonly options;
    login: Login | null;
    private loginAbort;
    private loginTask;
    constructor(run: Execute, options: () => CommandOptions);
    private api;
    account(): Promise<Account>;
    owners(): Promise<Owner[]>;
    repositories(page: number, owner?: Owner): Promise<Repository[]>;
    repository(fullName: string): Promise<Repository>;
    beginLogin(): Login;
    cancelLogin(): Promise<void>;
}
