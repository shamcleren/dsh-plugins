import type { Context } from '@deepseek-ai/cordis';
import type { WorkspaceService } from './service.js';
export declare function registerRpc(ctx: Context, service: Pick<WorkspaceService, 'request'>): void;
