import { z } from 'zod';
import type { CommandOptions, Execute, Result } from './process.js';
import { type Project } from './types.js';
export declare const encryptionSchema: z.ZodPipe<z.ZodDiscriminatedUnion<[z.ZodObject<{
    mode: z.ZodLiteral<"git-crypt">;
    keySource: z.ZodLiteral<"file">;
    keyFile: z.ZodString;
    binaryPath: z.ZodOptional<z.ZodString>;
}, z.core.$strict>, z.ZodObject<{
    mode: z.ZodLiteral<"git-crypt">;
    keySource: z.ZodLiteral<"gpg">;
    binaryPath: z.ZodOptional<z.ZodString>;
}, z.core.$strict>], "keySource">, z.ZodTransform<{
    mode: "git-crypt";
    keySource: "gpg";
    binaryPath?: string;
} | {
    mode: "git-crypt";
    keySource: "file";
    keyFile: string;
    binaryPath?: string;
}, {
    mode: "git-crypt";
    keySource: "file";
    keyFile: string;
    binaryPath?: string | undefined;
} | {
    mode: "git-crypt";
    keySource: "gpg";
    binaryPath?: string | undefined;
}>>;
type Command = (args: string[], options?: CommandOptions) => Promise<Result>;
export declare class EncryptionSupport {
    private readonly run;
    private readonly options;
    private readonly scratch;
    private readonly hooks;
    private readonly binaries;
    private readonly bindings;
    private readonly verified;
    constructor(run: Execute, options: () => CommandOptions, scratch: string, hooks: string);
    arguments(cwd: string): string[];
    private checked;
    private protected;
    private required;
    private binary;
    private internalKey;
    ready(project: Project, command: Command): Promise<boolean>;
    private sample;
    unlock(project: Project, command: Command): Promise<void>;
    private decrypted;
    verifyTree(project: Project, command: Command, tree: string, paths: string[], env: NodeJS.ProcessEnv, prior?: Set<string>, budget?: {
        bytes: number;
    }): Promise<void>;
    protectedPaths(command: Command, paths: string[], env: NodeJS.ProcessEnv): Promise<Set<string>>;
    plaintext(project: Project, paths: Iterable<string>): Promise<void>;
    audit(project: Project, command: Command): Promise<void>;
}
export {};
