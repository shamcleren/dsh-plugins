import { type Task, type TaskPhase } from './types.js';
/** Keep long commands outside HTTP response lifetimes, with bounded history. */
export declare class Tasks {
    private readonly entries;
    private stopped;
    list(): Task[];
    start(fullName: string, kind: Task['kind'], work: (signal: AbortSignal, report: (phase: TaskPhase, progress?: number) => void) => Promise<unknown>): Task;
    cancel(id: string): Task;
    stop(): Promise<void>;
    cancelSync(fullName: string): Promise<void>;
}
