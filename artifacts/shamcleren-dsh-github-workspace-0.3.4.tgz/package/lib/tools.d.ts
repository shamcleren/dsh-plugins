import { type CommandOptions, type Execute } from './process.js';
import { type ToolsState } from './types.js';
export declare const GH_VERSION = "2.103.3";
/** Read one known regular executable from a verified archive, never extract paths. */
export declare function releaseBinary(bytes: Buffer, hash: string, entry: string, zip: boolean): Buffer;
export declare function downloadRelease(url: string, signal: AbortSignal, progress: (value: number) => void): Promise<Buffer>;
export declare class Tools {
    private root;
    private readonly execute;
    private readonly prepare;
    private readonly download;
    private readonly system;
    private readonly release;
    private value;
    private pending;
    private binary;
    private readonly controller;
    constructor(root: string, execute: Execute, prepare: () => Promise<void>, download?: typeof downloadRelease, system?: boolean, release?: {
        suffix: string;
        hash: string;
    } | undefined);
    state(): ToolsState;
    environment(): NodeJS.ProcessEnv;
    start(retry?: boolean): ToolsState;
    close(): Promise<void>;
    run(command: string, args: string[], options?: CommandOptions): Promise<import("./process.js").Result>;
    setup(retry?: boolean): Promise<string>;
    private valid;
    private install;
}
