export interface CommandOptions {
    cwd?: string;
    env?: NodeJS.ProcessEnv;
    signal?: AbortSignal;
    timeoutMs?: number;
    maxBytes?: number;
    captureBinary?: boolean;
    stdoutLimit?: number;
    input?: string | Buffer;
    onOutput?(text: string): void;
}
export interface Result {
    code: number;
    stdout: string;
    stderr: string;
    stdoutBytes?: Buffer;
}
export type Execute = (command: string, args: string[], options?: CommandOptions) => Promise<Result>;
/** Own the entire command group; reject only after its streams and processes close. */
export declare const execute: Execute;
export declare function commandEnvironment(): NodeJS.ProcessEnv;
