declare function listRecent(): Promise<unknown>;
/** A local, authorized CLI may identify a group absent from the SDK callback. */
export declare class WeComGroupDirectory {
    private readonly list;
    private cached;
    constructor(list?: typeof listRecent);
    name(chatId: string): Promise<string | undefined>;
}
export {};
