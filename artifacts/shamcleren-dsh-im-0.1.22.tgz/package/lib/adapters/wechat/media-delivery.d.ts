export type MediaStage = 'read' | 'upload' | 'send';
/** Carry only allowlisted diagnostics: never retain file paths, tokens or CDN URLs. */
export declare class MediaDeliveryError extends Error {
    readonly stage: MediaStage;
    readonly category: string;
    constructor(stage: MediaStage, category: string);
}
export declare function mediaFailure(stage: MediaStage, error: unknown): MediaDeliveryError;
/** Sniff common raster formats rather than trusting a potentially misleading extension. */
export declare function isImageBytes(bytes: Buffer): boolean;
