type SendTyping = (userId: string, status: 1 | 2, contextToken: string | undefined, signal: AbortSignal) => Promise<void>;
/** One renewable indicator per peer, shared by every turn still delivering a reply. */
export declare class WeChatTyping {
    private readonly send;
    private readonly warn;
    private readonly peers;
    private closed;
    constructor(send: SendTyping, warn: () => void);
    update(key: string, contextToken: string | undefined): void;
    acquire(key: string, userId: string, contextToken: string | undefined): () => Promise<void>;
    stop(): Promise<void>;
    private refresh;
    private retire;
}
export {};
