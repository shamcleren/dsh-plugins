export declare function formatWeChatReply(markdown: string): string;
/** Prefer complete paragraphs/lines, retaining every character and whole UTF-16 pairs. */
export declare function weChatTextChunks(text: string, limit?: number): string[];
