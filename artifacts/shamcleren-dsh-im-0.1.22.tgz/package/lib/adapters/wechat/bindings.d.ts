import { ConversationBindings as ChannelBindings } from '../../core/conversation-bindings.js';
export type ConversationBindings = ChannelBindings;
export declare const ConversationBindings: {
    open: (filename: string) => Promise<ChannelBindings>;
};
