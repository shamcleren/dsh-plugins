/** Durable channel conversation-to-Session bindings without raw chat identifiers. */
/** Owner-only JSON persistence for the active Session of each channel conversation. */
export declare class ConversationBindings {
    private readonly filename;
    private readonly validSession;
    private readonly bindings;
    private readonly histories;
    private writeTail;
    private constructor();
    static open(filename: string, channel: 'wechat' | 'wecom'): Promise<ConversationBindings>;
    current(key: string, fallback: string): string;
    /** Creation order gives stable selection numbers even after another turn updates a title. */
    list(key: string, fallback: string): string[];
    set(key: string, sessionId: string, previousSessionId?: string): Promise<void>;
    drain(): Promise<void>;
}
