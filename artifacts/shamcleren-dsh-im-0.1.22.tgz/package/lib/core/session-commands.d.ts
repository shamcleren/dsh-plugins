import type { ConversationBindings } from './conversation-bindings.js';
import { type HostApiProxy } from './host-api.js';
export declare function displayLabel(value: string | undefined, fallback: string, limit?: number): string;
export declare function runSessionCommand(options: {
    sessions: HostApiProxy['sessions'];
    bindings: Pick<ConversationBindings, 'list' | 'set'>;
    key: string;
    currentSessionId: string;
    args: readonly string[];
    titlePrefix: string;
}): Promise<string>;
