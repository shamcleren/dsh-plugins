import { z } from 'zod';
export declare const wecomSessionId: z.ZodString;
export declare const groupName: z.ZodString;
export declare const sessionSourceSchema: z.ZodNullable<z.ZodObject<{
    group: z.ZodString;
    speakers: z.ZodArray<z.ZodString>;
}, z.core.$strip>>;
export type SessionSource = z.infer<typeof sessionSourceSchema>;
export declare const capabilitySchema: z.ZodEnum<{
    file: "file";
    text: "text";
    image: "image";
    video: "video";
    approval: "approval";
    questions: "questions";
    groups: "groups";
    notifications: "notifications";
}>;
export declare const failureSchema: z.ZodEnum<{
    "message-format": "message-format";
    media: "media";
    host: "host";
    connection: "connection";
}>;
export declare const adapterIdSchema: z.ZodString;
export declare const capabilitiesSchema: z.ZodArray<z.ZodEnum<{
    file: "file";
    text: "text";
    image: "image";
    video: "video";
    approval: "approval";
    questions: "questions";
    groups: "groups";
    notifications: "notifications";
}>>;
export declare const adapterStateSchema: z.ZodObject<{
    enabled: z.ZodBoolean;
    status: z.ZodEnum<{
        disabled: "disabled";
        waiting: "waiting";
        starting: "starting";
        running: "running";
        failed: "failed";
    }>;
    accounts: z.ZodNumber;
}, z.core.$strip>;
export declare const adapterViewsSchema: z.ZodArray<z.ZodObject<{
    enabled: z.ZodBoolean;
    status: z.ZodEnum<{
        disabled: "disabled";
        waiting: "waiting";
        starting: "starting";
        running: "running";
        failed: "failed";
    }>;
    accounts: z.ZodNumber;
    id: z.ZodString;
    capabilities: z.ZodArray<z.ZodEnum<{
        file: "file";
        text: "text";
        image: "image";
        video: "video";
        approval: "approval";
        questions: "questions";
        groups: "groups";
        notifications: "notifications";
    }>>;
    lastFailure: z.ZodOptional<z.ZodObject<{
        kind: z.ZodEnum<{
            "message-format": "message-format";
            media: "media";
            host: "host";
            connection: "connection";
        }>;
        at: z.ZodNumber;
    }, z.core.$strip>>;
}, z.core.$strip>>;
export type IMCapability = z.infer<typeof capabilitySchema>;
export type IMFailure = z.infer<typeof failureSchema>;
export type IMAdapterState = z.infer<typeof adapterStateSchema>;
export type IMAdapterView = z.infer<typeof adapterViewsSchema>[number];
export interface IMAdapter {
    id: string;
    capabilities: readonly IMCapability[];
    state(): IMAdapterState;
}
