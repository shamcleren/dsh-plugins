/** Persistent Marketplace Catalog cache keyed by the configured repository source. */
import type { MarketplaceCatalogView } from './types.ts';
/** Source identity, validation limits, and storage root for one Catalog cache entry. */
export interface MarketplaceCatalogCacheRequest {
    /** Absolute Harness home containing `plugin-cache`. */
    readonly home: string;
    /** Trusted Gongfeng API origin. */
    readonly baseUrl: string;
    /** Trusted namespace/repository identity. */
    readonly repository: string;
    /** Branch, tag, or commit selecting repository content. */
    readonly ref: string;
    /** Repository-relative Catalog path. */
    readonly catalogPath: string;
    /** Running DSH version used to derive entry compatibility. */
    readonly dshVersion: string;
    /** Installed profile identity and package versions; changes invalidate the Catalog. */
    readonly profileState: string;
    /** Maximum artifact size accepted while parsing the Catalog. */
    readonly maxArtifactBytes: number;
    /** Maximum bytes read from or written to one cache entry. */
    readonly maxCatalogBytes: number;
}
/**
 * Read a valid source-specific Catalog cache; malformed or absent cache files are misses.
 * @param request - Source identity, validation limits, and Harness storage root.
 * @returns The validated cached Catalog, or `undefined` when the cache cannot be reused.
 */
export declare function readMarketplaceCatalogCache(request: MarketplaceCatalogCacheRequest): Promise<MarketplaceCatalogView | undefined>;
/**
 * Atomically replace the source-specific Catalog cache after validating its contents.
 * @param request - Source identity, validation limits, and Harness storage root.
 * @param text - Exact trusted repository Catalog text.
 * @returns The validated Catalog written to the cache.
 */
export declare function writeMarketplaceCatalogCache(request: MarketplaceCatalogCacheRequest, text: string): Promise<MarketplaceCatalogView>;
