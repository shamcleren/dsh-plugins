import type { ISessions } from '@deepseek-ai/dsh-client-runtime/client';
import { type LocaleKey } from './locales.js';
interface ClientContext {
    sessions?: Pick<ISessions, 'open'>;
    effect(callback: () => unknown, label?: string): void;
    locale: {
        register(namespace: string, dictionaries: {
            zh: Record<string, string>;
            en: Record<string, string>;
        }): unknown;
        bind(namespace: string): (key: LocaleKey) => string;
    };
    connection: {
        rpc: {
            call<T>(channel: string, endpoint: string, payload: unknown): Promise<{
                ok: true;
                value: T;
            } | {
                ok: false;
                error: {
                    message: string;
                };
            }>;
        };
    };
    slots: {
        inject(slot: string, register: () => unknown): void;
        register(meta: Record<string, unknown>, component: (props: {
            wide?: boolean;
        }) => unknown): unknown;
    };
}
export declare const name = "@shamcleren/dsh-security-scan";
export declare const inject: string[];
export declare function reportLinkId(href: string, current: string): string | undefined;
/** Additive sidebar navigation and an independent workbench, without replacing DSH's conversation. */
export declare function apply(ctx: ClientContext): void;
export {};
