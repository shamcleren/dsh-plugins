import { type ApiProxy } from '@deepseek-ai/dsh-host-apiproxy';
import { type SessionStore } from '@deepseek-ai/dsh-session';
import type { Run } from './ui-contract.js';
export interface ScanSession {
    start(run: Run, cwd: string): Promise<string>;
    publish(id: string, run: Run): Promise<void>;
}
/** Host-owned ordinary sessions; progress is plugin context, never a second model prompt. */
export declare function scanSession(api: {
    sessions: Pick<ApiProxy['sessions'], 'create' | 'rename'>;
    workspace: Pick<ApiProxy['workspace'], 'create'>;
}, sessions: SessionStore): ScanSession;
