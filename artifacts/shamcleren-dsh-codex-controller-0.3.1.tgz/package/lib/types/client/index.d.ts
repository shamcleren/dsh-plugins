/** Codex identity and live activity. A normal new session plus the Codex preset is the entry. */
import type { SessionId } from '@deepseek-ai/dsh-session/types';
import { type LocaleKey } from './locales.js';
import { codexNoticeDefinition, codexViewDefinition } from '../conversation.js';
import { type CodexState } from '../ui-contract.js';
interface ClientContext {
    sessions?: {
        open(id: SessionId): void;
        list: {
            getSnapshot(): {
                current?: string;
                byId: Record<string, {
                    cwd?: string;
                }>;
            };
        };
    };
    uiConversation: {
        events: {
            register(definition: ReturnType<typeof codexNoticeDefinition>): () => void;
        };
        views: {
            register(definition: ReturnType<typeof codexViewDefinition>): () => void;
        };
    };
    effect(callback: () => unknown, label?: string): void;
    locale: {
        register(namespace: string, dictionaries: {
            zh: Record<string, string>;
            en: Record<string, string>;
        }): unknown;
        bind(namespace: string): (key: LocaleKey) => string;
    };
    connection: {
        rpc: {
            call<T>(channel: string, endpoint: string, payload: unknown): Promise<{
                ok: true;
                value: T;
            } | {
                ok: false;
                error: {
                    message: string;
                };
            }>;
        };
    };
    slots: {
        inject(slot: string, register: () => unknown): void;
        register(meta: Record<string, unknown>, component: (props: {
            wide?: boolean;
        }) => unknown): unknown;
    };
}
export declare const name = "@shamcleren/dsh-codex-controller";
export declare const inject: string[];
export declare function apply(ctx: ClientContext): void;
export declare function BadgeView(props: {
    state: CodexState | undefined;
    t: (key: LocaleKey) => string;
}): import("react").DetailedReactHTMLElement<{
    className: string;
}, HTMLElement> | null;
export declare function QuotaView(props: {
    state: CodexState | undefined;
    t: (key: LocaleKey) => string;
}): import("react").DetailedReactHTMLElement<{
    className: string;
    title: string;
}, HTMLElement> | null;
export declare function resetLabel(epochMs: number, timeZone?: string): string;
export {};
