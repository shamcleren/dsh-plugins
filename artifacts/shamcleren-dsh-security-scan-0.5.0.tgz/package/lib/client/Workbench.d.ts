import { type UiRemote } from '../ui-contract.js';
import { type LocaleKey } from './locales.js';
type Translate = (key: LocaleKey) => string;
export declare function Workbench({ remote, t, close }: {
    remote: UiRemote;
    t: Translate;
    close(): void;
}): import("react").JSX.Element;
export {};
