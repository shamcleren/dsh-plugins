import { type LlmRuntime, type LlmCallConfig } from '@deepseek-ai/dsh-llm';
import { type Review, type AdditionalFinding } from './report.js';
import { type AgentPolicy, type AgentAudit } from './agent-contract.js';
/** Remove common credential literals before code reaches the configured model or report. */
export declare function redactAgentText(value: string): string;
type Selection = LlmCallConfig;
export interface AgentReviewOptions {
    reportFile: string;
    workspace: string;
    policy: AgentPolicy;
    signal: AbortSignal;
    llm?: Pick<LlmRuntime, 'prepareCall'>;
    selection?: Selection;
    onProgress?(audit: AgentAudit): Promise<void>;
}
export interface AgentReviewResult {
    audit: AgentAudit;
    reviews: Review[];
    findings: AdditionalFinding[];
}
/** A bounded tool loop over the public LLM service. No ambient DSH tools are dispatched. */
export declare function runAgentReview(options: AgentReviewOptions): Promise<AgentReviewResult>;
export {};
