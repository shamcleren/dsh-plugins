/** Shared configuration and audit metadata; safe to import in the browser. */
import { z } from 'zod';
export declare const AgentPolicySchema: z.ZodObject<{
    enabled: z.ZodDefault<z.ZodBoolean>;
    provider: z.ZodDefault<z.ZodString>;
    model: z.ZodDefault<z.ZodString>;
    maxSteps: z.ZodDefault<z.ZodNumber>;
    maxMinutes: z.ZodDefault<z.ZodNumber>;
    maxTokens: z.ZodDefault<z.ZodNumber>;
}, z.core.$strict>;
export type AgentPolicy = z.infer<typeof AgentPolicySchema>;
export declare const ReviewAreaSchema: z.ZodEnum<{
    "entry-points": "entry-points";
    authentication: "authentication";
    authorization: "authorization";
    injection: "injection";
    "data-exposure": "data-exposure";
    "business-logic": "business-logic";
}>;
export declare const AgentEventSchema: z.ZodObject<{
    step: z.ZodNumber;
    kind: z.ZodEnum<{
        planning: "planning";
        listing: "listing";
        reading: "reading";
        reviewing: "reviewing";
        rejected: "rejected";
        finished: "finished";
    }>;
    files: z.ZodDefault<z.ZodArray<z.ZodString>>;
    count: z.ZodDefault<z.ZodNumber>;
}, z.core.$strict>;
export declare const AgentAuditSchema: z.ZodObject<{
    status: z.ZodEnum<{
        completed: "completed";
        incomplete: "incomplete";
    }>;
    reason: z.ZodEnum<{
        completed: "completed";
        "step-limit": "step-limit";
        "time-limit": "time-limit";
        "context-limit": "context-limit";
        "model-unavailable": "model-unavailable";
        "model-failed": "model-failed";
        "invalid-response": "invalid-response";
        "evidence-unavailable": "evidence-unavailable";
        cancelled: "cancelled";
    }>;
    provider: z.ZodString;
    model: z.ZodString;
    steps: z.ZodNumber;
    areas: z.ZodArray<z.ZodEnum<{
        "entry-points": "entry-points";
        authentication: "authentication";
        authorization: "authorization";
        injection: "injection";
        "data-exposure": "data-exposure";
        "business-logic": "business-logic";
    }>>;
    files: z.ZodArray<z.ZodString>;
    reviewedFindings: z.ZodNumber;
    additionalFindings: z.ZodDefault<z.ZodNumber>;
    inputTokens: z.ZodNumber;
    outputTokens: z.ZodNumber;
    usageAvailable: z.ZodBoolean;
    events: z.ZodArray<z.ZodObject<{
        step: z.ZodNumber;
        kind: z.ZodEnum<{
            planning: "planning";
            listing: "listing";
            reading: "reading";
            reviewing: "reviewing";
            rejected: "rejected";
            finished: "finished";
        }>;
        files: z.ZodDefault<z.ZodArray<z.ZodString>>;
        count: z.ZodDefault<z.ZodNumber>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type AgentAudit = z.infer<typeof AgentAuditSchema>;
