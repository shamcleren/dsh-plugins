/** Group aliases span sessions. Speaker lists belong only to the session where they spoke. */
export declare class WeComSessionSources {
    private readonly root;
    constructor(root?: string);
    private sessionPath;
    private groupPath;
    record(id: string, group: string, speaker: string): Promise<void>;
    nameGroup(key: string, name: string): Promise<void>;
    get(id: string): Promise<{
        group: string;
        speakers: string[];
    } | null>;
}
