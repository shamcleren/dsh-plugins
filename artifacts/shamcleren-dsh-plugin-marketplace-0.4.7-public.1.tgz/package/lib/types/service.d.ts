/** Trusted single-source plugin Marketplace and profile mutation service. */
import { Service, type Volatile, type Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import type { MarketplaceCatalogView, MarketplaceConfigureRequest, MarketplaceMutationResult, MarketplaceOAuthRequest, MarketplaceOAuthStart, MarketplaceOAuthStatus, MarketplaceState } from './types.ts';
export type * from './types.ts';
export { parseMarketplaceCatalog } from './catalog.ts';
/** Stable Cordis service name. */
export declare const name = "trusted-marketplace";
/** Marketplace source and installer policy. */
export interface Config {
    /** Gongfeng API base URL. */
    baseUrl?: string;
    /** Single trusted namespace/repository source. */
    repository?: string;
    /** Branch, tag, or commit used for the catalog and artifacts. */
    ref?: string;
    /** Catalog path inside the repository. */
    catalogPath?: string;
    /** Public Gongfeng OAuth application id used for PKCE. */
    oauthClientId?: string;
    /** Credential reference containing the OAuth access token. */
    oauthAccessTokenRef?: string;
    /** Credential reference containing the OAuth refresh token. */
    oauthRefreshTokenRef?: string;
    /** Epoch milliseconds when the current OAuth access token expires. */
    oauthExpiresAt?: number;
    /** Legacy setting retained for config import only; the active Host owns the target. */
    profile?: string;
    /** Maximum decoded tarball bytes. */
    maxArtifactBytes?: number;
}
/** Remote Marketplace service backed by Gongfeng and the canonical profile CLI. */
export declare class MarketplaceService extends Service {
    static inject: string[];
    static Config: z<NoInfer<Schemastery.ObjectS<NoInfer<{
        baseUrl: z<string, string, "defined">;
        repository: z<string, string, "defined">;
        ref: z<string, string, "defined">;
        catalogPath: z<string, string, "defined">;
        oauthClientId: z<string, string, "defined">;
        oauthAccessTokenRef: z<string, string, "defined">;
        oauthRefreshTokenRef: z<string, string, "defined">;
        oauthExpiresAt: z<number, number, "plain">;
        profile: z<string, string, "plain">;
        maxArtifactBytes: z<number, number, "defined">;
    }>>>, NoInfer<Schemastery.ObjectT<NoInfer<{
        baseUrl: z<string, string, "defined">;
        repository: z<string, string, "defined">;
        ref: z<string, string, "defined">;
        catalogPath: z<string, string, "defined">;
        oauthClientId: z<string, string, "defined">;
        oauthAccessTokenRef: z<string, string, "defined">;
        oauthRefreshTokenRef: z<string, string, "defined">;
        oauthExpiresAt: z<number, number, "plain">;
        profile: z<string, string, "plain">;
        maxArtifactBytes: z<number, number, "defined">;
    }>>>, "volatile">;
    private readonly entry;
    private current;
    private settings;
    private mutationTail;
    private readonly oauth;
    private readonly callbackListener;
    constructor(ctx: Context, config?: Config | Volatile<Config>);
    private handleOAuthCallback;
    /**
     * Read safe source, credential, native bridge, and installed-package state.
     * @returns Browser-safe Marketplace state without credential values.
     */
    state(): Promise<MarketplaceState>;
    /**
     * Start a Gongfeng OAuth authorization using PKCE and the loopback callback.
     * @param request Repository address selected by the user.
     * @returns Authorization URL and polling identity.
     */
    beginOAuth(request: MarketplaceOAuthRequest): Promise<MarketplaceOAuthStart>;
    /**
     * Poll one Gongfeng OAuth authorization.
     * @param flowId Identity returned from {@link beginOAuth}.
     * @returns Current flow status without authorization secrets.
     */
    oauthStatus(flowId: string): Promise<MarketplaceOAuthStatus>;
    /** Save one authorized repository, resolving its default branch without listing unrelated projects. */
    configure(request: MarketplaceConfigureRequest): Promise<MarketplaceState>;
    /**
     * Read the validated local Catalog cache, fetching it only on a cache miss.
     * @returns Compatible and incompatible entries from the current cached or remote Catalog.
     */
    catalog(): Promise<MarketplaceCatalogView>;
    /**
     * Fetch the configured Catalog from its trusted source and atomically refresh the local cache.
     * @returns Compatible and incompatible entries from the refreshed Catalog.
     */
    refreshCatalog(): Promise<MarketplaceCatalogView>;
    /**
     * Install or update one compatible Catalog package into the configured profile.
     * @param packageName Exact package identity present in the current Catalog.
     * @returns Mutation identity and restart requirement.
     */
    add(packageName: string): Promise<MarketplaceMutationResult>;
    /**
     * Remove one installed Catalog package from the configured profile.
     * @param packageName Exact package identity present in the current Catalog.
     * @returns Mutation identity and restart requirement.
     */
    deletePackage(packageName: string): Promise<MarketplaceMutationResult>;
    private repositoryFile;
    private catalogCacheRequest;
    private fetchCatalog;
    private oauthConfig;
    private cacheArtifact;
    private matchesArtifact;
    private verifyPackageManifest;
    private installed;
    private requireApplied;
    /** The public manifest writer preserves other metadata; use the manager's same file lock. */
    private placeBeforeWebApp;
    private serializeMutation;
}
export default MarketplaceService;
