/** Trusted Marketplace plugin using the upstream Connection RPC extension. */
import type { Context, Volatile } from '@deepseek-ai/cordis';
export { parseMarketplaceCatalog } from './catalog.ts';
export type Config = import('./service.ts').Config;
export declare const name = "trusted-marketplace";
export declare const Config: import("@deepseek-ai/schemastery").default<NoInfer<Schemastery.ObjectS<NoInfer<{
    baseUrl: import("@deepseek-ai/schemastery").default<string, string, "defined">;
    repository: import("@deepseek-ai/schemastery").default<string, string, "defined">;
    ref: import("@deepseek-ai/schemastery").default<string, string, "defined">;
    catalogPath: import("@deepseek-ai/schemastery").default<string, string, "defined">;
    oauthClientId: import("@deepseek-ai/schemastery").default<string, string, "defined">;
    oauthAccessTokenRef: import("@deepseek-ai/schemastery").default<string, string, "defined">;
    oauthRefreshTokenRef: import("@deepseek-ai/schemastery").default<string, string, "defined">;
    oauthExpiresAt: import("@deepseek-ai/schemastery").default<number, number, "plain">;
    profile: import("@deepseek-ai/schemastery").default<string, string, "plain">;
    maxArtifactBytes: import("@deepseek-ai/schemastery").default<number, number, "defined">;
}>>>, NoInfer<Schemastery.ObjectT<NoInfer<{
    baseUrl: import("@deepseek-ai/schemastery").default<string, string, "defined">;
    repository: import("@deepseek-ai/schemastery").default<string, string, "defined">;
    ref: import("@deepseek-ai/schemastery").default<string, string, "defined">;
    catalogPath: import("@deepseek-ai/schemastery").default<string, string, "defined">;
    oauthClientId: import("@deepseek-ai/schemastery").default<string, string, "defined">;
    oauthAccessTokenRef: import("@deepseek-ai/schemastery").default<string, string, "defined">;
    oauthRefreshTokenRef: import("@deepseek-ai/schemastery").default<string, string, "defined">;
    oauthExpiresAt: import("@deepseek-ai/schemastery").default<number, number, "plain">;
    profile: import("@deepseek-ai/schemastery").default<string, string, "plain">;
    maxArtifactBytes: import("@deepseek-ai/schemastery").default<number, number, "defined">;
}>>>, "volatile">;
export declare const inject: string[];
/** Mount the service and browser RPC with Host-enforced loopback authorization. */
export declare function apply(ctx: Context, config: Config | Volatile<Config>): Promise<void>;
