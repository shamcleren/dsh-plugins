/** Browser-safe configuration and wire contracts. No filesystem or scanner imports. */
import { z } from 'zod';
export declare const SECURITY_CHANNEL = "/security-scan";
export declare const TaskConfigSchema: z.ZodObject<{
    name: z.ZodString;
    kind: z.ZodEnum<{
        local: "local";
        remote: "remote";
    }>;
    target: z.ZodString;
    ref: z.ZodDefault<z.ZodString>;
    scope: z.ZodEnum<{
        diff: "diff";
        full: "full";
        staged: "staged";
    }>;
    baseline: z.ZodEnum<{
        git: "git";
        none: "none";
        report: "report";
    }>;
    base: z.ZodDefault<z.ZodString>;
    baselineId: z.ZodDefault<z.ZodUnion<readonly [z.ZodLiteral<"">, z.ZodString]>>;
    engine: z.ZodEnum<{
        auto: "auto";
        inventory: "inventory";
    }>;
    dependencies: z.ZodDefault<z.ZodBoolean>;
    secrets: z.ZodDefault<z.ZodBoolean>;
    syncSession: z.ZodDefault<z.ZodBoolean>;
    view: z.ZodDefault<z.ZodEnum<{
        all: "all";
        new: "new";
    }>>;
    autoScan: z.ZodDefault<z.ZodBoolean>;
    agent: z.ZodDefault<z.ZodObject<{
        enabled: z.ZodDefault<z.ZodBoolean>;
        provider: z.ZodDefault<z.ZodString>;
        model: z.ZodDefault<z.ZodString>;
        maxSteps: z.ZodDefault<z.ZodNumber>;
        maxMinutes: z.ZodDefault<z.ZodNumber>;
        maxTokens: z.ZodDefault<z.ZodNumber>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type TaskConfig = z.infer<typeof TaskConfigSchema>;
export declare const TaskSchema: z.ZodObject<{
    id: z.ZodString;
    revision: z.ZodNumber;
    updatedAt: z.ZodString;
    config: z.ZodObject<{
        name: z.ZodString;
        kind: z.ZodEnum<{
            local: "local";
            remote: "remote";
        }>;
        target: z.ZodString;
        ref: z.ZodDefault<z.ZodString>;
        scope: z.ZodEnum<{
            diff: "diff";
            full: "full";
            staged: "staged";
        }>;
        baseline: z.ZodEnum<{
            git: "git";
            none: "none";
            report: "report";
        }>;
        base: z.ZodDefault<z.ZodString>;
        baselineId: z.ZodDefault<z.ZodUnion<readonly [z.ZodLiteral<"">, z.ZodString]>>;
        engine: z.ZodEnum<{
            auto: "auto";
            inventory: "inventory";
        }>;
        dependencies: z.ZodDefault<z.ZodBoolean>;
        secrets: z.ZodDefault<z.ZodBoolean>;
        syncSession: z.ZodDefault<z.ZodBoolean>;
        view: z.ZodDefault<z.ZodEnum<{
            all: "all";
            new: "new";
        }>>;
        autoScan: z.ZodDefault<z.ZodBoolean>;
        agent: z.ZodDefault<z.ZodObject<{
            enabled: z.ZodDefault<z.ZodBoolean>;
            provider: z.ZodDefault<z.ZodString>;
            model: z.ZodDefault<z.ZodString>;
            maxSteps: z.ZodDefault<z.ZodNumber>;
            maxMinutes: z.ZodDefault<z.ZodNumber>;
            maxTokens: z.ZodDefault<z.ZodNumber>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
}, z.core.$strict>;
export type Task = z.infer<typeof TaskSchema>;
export declare const RunSchema: z.ZodObject<{
    id: z.ZodString;
    taskId: z.ZodString;
    config: z.ZodObject<{
        name: z.ZodString;
        kind: z.ZodEnum<{
            local: "local";
            remote: "remote";
        }>;
        target: z.ZodString;
        ref: z.ZodDefault<z.ZodString>;
        scope: z.ZodEnum<{
            diff: "diff";
            full: "full";
            staged: "staged";
        }>;
        baseline: z.ZodEnum<{
            git: "git";
            none: "none";
            report: "report";
        }>;
        base: z.ZodDefault<z.ZodString>;
        baselineId: z.ZodDefault<z.ZodUnion<readonly [z.ZodLiteral<"">, z.ZodString]>>;
        engine: z.ZodEnum<{
            auto: "auto";
            inventory: "inventory";
        }>;
        dependencies: z.ZodDefault<z.ZodBoolean>;
        secrets: z.ZodDefault<z.ZodBoolean>;
        syncSession: z.ZodDefault<z.ZodBoolean>;
        view: z.ZodDefault<z.ZodEnum<{
            all: "all";
            new: "new";
        }>>;
        autoScan: z.ZodDefault<z.ZodBoolean>;
        agent: z.ZodDefault<z.ZodObject<{
            enabled: z.ZodDefault<z.ZodBoolean>;
            provider: z.ZodDefault<z.ZodString>;
            model: z.ZodDefault<z.ZodString>;
            maxSteps: z.ZodDefault<z.ZodNumber>;
            maxMinutes: z.ZodDefault<z.ZodNumber>;
            maxTokens: z.ZodDefault<z.ZodNumber>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    status: z.ZodEnum<{
        cancelled: "cancelled";
        cancelling: "cancelling";
        failed: "failed";
        interrupted: "interrupted";
        partial: "partial";
        queued: "queued";
        running: "running";
        succeeded: "succeeded";
    }>;
    phase: z.ZodEnum<{
        agent: "agent";
        baseline: "baseline";
        finished: "finished";
        preparing: "preparing";
        queued: "queued";
        report: "report";
        scanning: "scanning";
    }>;
    trigger: z.ZodEnum<{
        conversation: "conversation";
        edit: "edit";
        manual: "manual";
    }>;
    createdAt: z.ZodString;
    finishedAt: z.ZodOptional<z.ZodString>;
    reportId: z.ZodOptional<z.ZodString>;
    rulesReportId: z.ZodOptional<z.ZodString>;
    reportRoot: z.ZodOptional<z.ZodString>;
    error: z.ZodOptional<z.ZodString>;
    sessionId: z.ZodOptional<z.ZodString>;
    sessionWarning: z.ZodOptional<z.ZodBoolean>;
    diagnostics: z.ZodOptional<z.ZodArray<z.ZodString>>;
    findings: z.ZodOptional<z.ZodNumber>;
    agent: z.ZodOptional<z.ZodObject<{
        status: z.ZodEnum<{
            completed: "completed";
            incomplete: "incomplete";
        }>;
        reason: z.ZodEnum<{
            cancelled: "cancelled";
            completed: "completed";
            "context-limit": "context-limit";
            "evidence-unavailable": "evidence-unavailable";
            "invalid-response": "invalid-response";
            "model-failed": "model-failed";
            "model-unavailable": "model-unavailable";
            "step-limit": "step-limit";
            "time-limit": "time-limit";
        }>;
        provider: z.ZodString;
        model: z.ZodString;
        steps: z.ZodNumber;
        areas: z.ZodArray<z.ZodEnum<{
            authentication: "authentication";
            authorization: "authorization";
            "business-logic": "business-logic";
            "data-exposure": "data-exposure";
            "entry-points": "entry-points";
            injection: "injection";
        }>>;
        files: z.ZodArray<z.ZodString>;
        eligibleCandidates: z.ZodOptional<z.ZodNumber>;
        excludedCandidates: z.ZodOptional<z.ZodNumber>;
        reviewedFindings: z.ZodNumber;
        additionalFindings: z.ZodDefault<z.ZodNumber>;
        inputTokens: z.ZodNumber;
        outputTokens: z.ZodNumber;
        usageAvailable: z.ZodBoolean;
        events: z.ZodArray<z.ZodObject<{
            step: z.ZodNumber;
            kind: z.ZodEnum<{
                finished: "finished";
                listing: "listing";
                planning: "planning";
                reading: "reading";
                rejected: "rejected";
                reviewing: "reviewing";
            }>;
            files: z.ZodDefault<z.ZodArray<z.ZodString>>;
            code: z.ZodOptional<z.ZodString>;
            count: z.ZodDefault<z.ZodNumber>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type Run = z.infer<typeof RunSchema>;
export declare const SettingsSchema: z.ZodObject<{
    semgrepPath: z.ZodString;
    gitleaksPath: z.ZodString;
    reportDirectory: z.ZodString;
    autoScan: z.ZodBoolean;
    hookTools: z.ZodArray<z.ZodString>;
}, z.core.$strict>;
export type ScanSettings = z.infer<typeof SettingsSchema>;
export declare const ReportItemSchema: z.ZodObject<{
    id: z.ZodString;
    createdAt: z.ZodString;
    source: z.ZodString;
    scope: z.ZodString;
    findings: z.ZodNumber;
    json: z.ZodString;
    html: z.ZodString;
}, z.core.$strip>;
export type ReportItem = z.infer<typeof ReportItemSchema>;
export declare const ToolchainStateSchema: z.ZodObject<{
    status: z.ZodEnum<{
        failed: "failed";
        idle: "idle";
        installing: "installing";
        ready: "ready";
    }>;
    phase: z.ZodEnum<{
        checking: "checking";
        download: "download";
        gitleaks: "gitleaks";
        idle: "idle";
        python: "python";
        ready: "ready";
        semgrep: "semgrep";
    }>;
    semgrep: z.ZodString;
    gitleaks: z.ZodString;
    error: z.ZodString;
}, z.core.$strip>;
export type ToolchainState = z.infer<typeof ToolchainStateSchema>;
export declare const UiStateSchema: z.ZodObject<{
    tasks: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        revision: z.ZodNumber;
        updatedAt: z.ZodString;
        config: z.ZodObject<{
            name: z.ZodString;
            kind: z.ZodEnum<{
                local: "local";
                remote: "remote";
            }>;
            target: z.ZodString;
            ref: z.ZodDefault<z.ZodString>;
            scope: z.ZodEnum<{
                diff: "diff";
                full: "full";
                staged: "staged";
            }>;
            baseline: z.ZodEnum<{
                git: "git";
                none: "none";
                report: "report";
            }>;
            base: z.ZodDefault<z.ZodString>;
            baselineId: z.ZodDefault<z.ZodUnion<readonly [z.ZodLiteral<"">, z.ZodString]>>;
            engine: z.ZodEnum<{
                auto: "auto";
                inventory: "inventory";
            }>;
            dependencies: z.ZodDefault<z.ZodBoolean>;
            secrets: z.ZodDefault<z.ZodBoolean>;
            syncSession: z.ZodDefault<z.ZodBoolean>;
            view: z.ZodDefault<z.ZodEnum<{
                all: "all";
                new: "new";
            }>>;
            autoScan: z.ZodDefault<z.ZodBoolean>;
            agent: z.ZodDefault<z.ZodObject<{
                enabled: z.ZodDefault<z.ZodBoolean>;
                provider: z.ZodDefault<z.ZodString>;
                model: z.ZodDefault<z.ZodString>;
                maxSteps: z.ZodDefault<z.ZodNumber>;
                maxMinutes: z.ZodDefault<z.ZodNumber>;
                maxTokens: z.ZodDefault<z.ZodNumber>;
            }, z.core.$strict>>;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    runs: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        taskId: z.ZodString;
        config: z.ZodObject<{
            name: z.ZodString;
            kind: z.ZodEnum<{
                local: "local";
                remote: "remote";
            }>;
            target: z.ZodString;
            ref: z.ZodDefault<z.ZodString>;
            scope: z.ZodEnum<{
                diff: "diff";
                full: "full";
                staged: "staged";
            }>;
            baseline: z.ZodEnum<{
                git: "git";
                none: "none";
                report: "report";
            }>;
            base: z.ZodDefault<z.ZodString>;
            baselineId: z.ZodDefault<z.ZodUnion<readonly [z.ZodLiteral<"">, z.ZodString]>>;
            engine: z.ZodEnum<{
                auto: "auto";
                inventory: "inventory";
            }>;
            dependencies: z.ZodDefault<z.ZodBoolean>;
            secrets: z.ZodDefault<z.ZodBoolean>;
            syncSession: z.ZodDefault<z.ZodBoolean>;
            view: z.ZodDefault<z.ZodEnum<{
                all: "all";
                new: "new";
            }>>;
            autoScan: z.ZodDefault<z.ZodBoolean>;
            agent: z.ZodDefault<z.ZodObject<{
                enabled: z.ZodDefault<z.ZodBoolean>;
                provider: z.ZodDefault<z.ZodString>;
                model: z.ZodDefault<z.ZodString>;
                maxSteps: z.ZodDefault<z.ZodNumber>;
                maxMinutes: z.ZodDefault<z.ZodNumber>;
                maxTokens: z.ZodDefault<z.ZodNumber>;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        status: z.ZodEnum<{
            cancelled: "cancelled";
            cancelling: "cancelling";
            failed: "failed";
            interrupted: "interrupted";
            partial: "partial";
            queued: "queued";
            running: "running";
            succeeded: "succeeded";
        }>;
        phase: z.ZodEnum<{
            agent: "agent";
            baseline: "baseline";
            finished: "finished";
            preparing: "preparing";
            queued: "queued";
            report: "report";
            scanning: "scanning";
        }>;
        trigger: z.ZodEnum<{
            conversation: "conversation";
            edit: "edit";
            manual: "manual";
        }>;
        createdAt: z.ZodString;
        finishedAt: z.ZodOptional<z.ZodString>;
        reportId: z.ZodOptional<z.ZodString>;
        rulesReportId: z.ZodOptional<z.ZodString>;
        reportRoot: z.ZodOptional<z.ZodString>;
        error: z.ZodOptional<z.ZodString>;
        sessionId: z.ZodOptional<z.ZodString>;
        sessionWarning: z.ZodOptional<z.ZodBoolean>;
        diagnostics: z.ZodOptional<z.ZodArray<z.ZodString>>;
        findings: z.ZodOptional<z.ZodNumber>;
        agent: z.ZodOptional<z.ZodObject<{
            status: z.ZodEnum<{
                completed: "completed";
                incomplete: "incomplete";
            }>;
            reason: z.ZodEnum<{
                cancelled: "cancelled";
                completed: "completed";
                "context-limit": "context-limit";
                "evidence-unavailable": "evidence-unavailable";
                "invalid-response": "invalid-response";
                "model-failed": "model-failed";
                "model-unavailable": "model-unavailable";
                "step-limit": "step-limit";
                "time-limit": "time-limit";
            }>;
            provider: z.ZodString;
            model: z.ZodString;
            steps: z.ZodNumber;
            areas: z.ZodArray<z.ZodEnum<{
                authentication: "authentication";
                authorization: "authorization";
                "business-logic": "business-logic";
                "data-exposure": "data-exposure";
                "entry-points": "entry-points";
                injection: "injection";
            }>>;
            files: z.ZodArray<z.ZodString>;
            eligibleCandidates: z.ZodOptional<z.ZodNumber>;
            excludedCandidates: z.ZodOptional<z.ZodNumber>;
            reviewedFindings: z.ZodNumber;
            additionalFindings: z.ZodDefault<z.ZodNumber>;
            inputTokens: z.ZodNumber;
            outputTokens: z.ZodNumber;
            usageAvailable: z.ZodBoolean;
            events: z.ZodArray<z.ZodObject<{
                step: z.ZodNumber;
                kind: z.ZodEnum<{
                    finished: "finished";
                    listing: "listing";
                    planning: "planning";
                    reading: "reading";
                    rejected: "rejected";
                    reviewing: "reviewing";
                }>;
                files: z.ZodDefault<z.ZodArray<z.ZodString>>;
                code: z.ZodOptional<z.ZodString>;
                count: z.ZodDefault<z.ZodNumber>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    reports: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        createdAt: z.ZodString;
        source: z.ZodString;
        scope: z.ZodString;
        findings: z.ZodNumber;
        json: z.ZodString;
        html: z.ZodString;
    }, z.core.$strip>>;
    settings: z.ZodObject<{
        semgrepPath: z.ZodString;
        gitleaksPath: z.ZodString;
        reportDirectory: z.ZodString;
        autoScan: z.ZodBoolean;
        hookTools: z.ZodArray<z.ZodString>;
    }, z.core.$strict>;
    settingsWritable: z.ZodBoolean;
    toolchains: z.ZodOptional<z.ZodObject<{
        status: z.ZodEnum<{
            failed: "failed";
            idle: "idle";
            installing: "installing";
            ready: "ready";
        }>;
        phase: z.ZodEnum<{
            checking: "checking";
            download: "download";
            gitleaks: "gitleaks";
            idle: "idle";
            python: "python";
            ready: "ready";
            semgrep: "semgrep";
        }>;
        semgrep: z.ZodString;
        gitleaks: z.ZodString;
        error: z.ZodString;
    }, z.core.$strip>>;
    agentDefault: z.ZodDefault<z.ZodNullable<z.ZodObject<{
        provider: z.ZodString;
        model: z.ZodString;
    }, z.core.$strip>>>;
    warnings: z.ZodDefault<z.ZodArray<z.ZodString>>;
}, z.core.$strip>;
export type UiState = z.infer<typeof UiStateSchema>;
export declare const HookRequestSchema: z.ZodObject<{
    taskId: z.ZodString;
    revision: z.ZodNumber;
    event: z.ZodEnum<{
        "pre-commit": "pre-commit";
        "pre-push": "pre-push";
    }>;
    action: z.ZodEnum<{
        install: "install";
        remove: "remove";
    }>;
    enforce: z.ZodBoolean;
    base: z.ZodDefault<z.ZodString>;
    confirm: z.ZodLiteral<true>;
}, z.core.$strict>;
export type HookRequest = z.infer<typeof HookRequestSchema>;
export type UiRemote = {
    state(): Promise<UiState>;
    setup(): Promise<void>;
    save(config: TaskConfig, id?: string, revision?: number): Promise<Task>;
    remove(id: string, revision: number): Promise<void>;
    run(id: string, revision: number): Promise<Run>;
    cancel(id: string): Promise<void>;
    settings(value: ScanSettings): Promise<void>;
    hook(request: HookRequest): Promise<void>;
    report(id: string, format: 'html' | 'json'): Promise<string>;
};
export declare const newTask: () => TaskConfig;
