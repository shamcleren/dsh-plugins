# 代码安全扫描 0.6

面向 Python、Go、JavaScript/TypeScript 的 DSH 插件。扫描、Git hook 和 CLI 共用同一套逻辑；可在工作台按任务启用 Agentic AI，复用 DSH 模型进行证据复核。官方运行时保持 `0.1.0-rc.8`，未修改上游源码。

## 安装与首次扫描

退出 DSH，在本仓库执行，然后重新打开 App。已有桌面版先用 `make init` 更新应用壳（0.2.6 起支持原生报告保存）；Web 版只需安装插件：

```sh
make plugin-install PLUGIN=security-scan
```

在 DSH 中选择项目并说：

> 使用 security-review 扫描当前仓库，复核候选漏洞和业务权限问题，输出 HTML 报告，把证据和修复建议保存到 JSON。

也可以说：

> 扫描 https://git.woa.com/team/project.git 的 main 分支，生成 HTML 安全报告。

URL 支持 HTTPS / SSH，不允许内嵌密码或 Token。使用本机现有 Git 凭据和 SSH agent；不会借用市场的 OAuth token。远端仓库临时裸克隆，不 checkout、不执行项目脚本、不安装依赖，不更新用户现有工作树。Git 操作最长 120 秒，大仓库或不可达历史会明确失败。

## 独立安全扫描工作台

安装后重新打开 DSH，点击**侧边栏底部的「安全扫描」**直接进入工作台，不需要从设置入口进入。

- **扫描任务**：新建、编辑和移除任务，配置本地目录或仓库 URL、分支/提交、全量/增量/暂存区、Git 或历史报告基线、扫描方式、可选依赖/密钥检测、DSH 编辑后自动检查。保存任务不会自行扫描；使用“保存并运行”或“立即扫描”启动。
- **运行记录**：查看排队、扫描阶段、完成、覆盖不完整、失败、取消和中断状态。一次执行一个扫描，最多 10 个待完成运行（包含正在执行的）；关闭工作台后任务继续执行。任务修改只影响之后启动的运行。最多保留最近 100 次运行；记录总量超过 4 MiB 时提前淘汰较旧的已结束记录，已有 HTML/JSON 文件不会随着记录滚动删除。
- **历史报告**：查找最近的报告，在工作台内预览 HTML，下载 HTML 或 JSON。0.2 报告仍可打开；任务运行记录保留当时的报告目录，修改输出目录后仍可查看这些记录关联的旧报告。
- **扫描设置**：查看 Semgrep/Gitleaks 自动安装进度和重试，配置报告目录。自定义扫描器路径、编辑工具与旧版全局开关收在高级设置。设置通过官方 provider 写入 `settings.yaml`，不需要手工编辑。

每个本地任务都有 **Git hooks** 按钮。选择提交前或推送前、安装或卸载，检查仓库和推送基线后再确认。保存任务不会悄悄修改仓库，也不会覆盖已有用户 hook 或 hooksPath。Git hooks 执行 Semgrep 规则；任务里的依赖查询、密钥检测和盘点模式不会自动带入 hook。配置这些检查时请使用手动任务或 DSH 编辑后自动任务。

按任务启用“DSH 编辑后自动检查”后，匹配该代码目录的编辑会合并触发该任务；扫描期间发生的编辑会在结束后再检查一次。不需要同时打开旧版全局开关。用户主动取消记录为“已取消”，Host 正常关闭中止的任务记录为“已中断”，再次打开后由用户决定是否重跑，不自动恢复执行。

任务定义和运行记录保存在实际 DSH 数据目录的 `security-scan/tasks.json`。任务存储使用独占锁；异常退出遗留锁时应先核实进程归属，不自动清除未知锁。移除任务保留报告、运行记录和已经安装的 Git hooks。

工作台使用官方 `sidebar.footer.action` 和 `shell.overlay` 扩展点，保留原有对话和侧边栏；“返回 DSH”回到原界面。RPC 仅通过官方 Connection 的 loopback 授权通道开放。报告在独立 sandbox iframe 中显示，不能操作外层 DSH 页面。

工作台可执行规则扫描及按任务启用的 AI 复核，也保留 DSH 会话中的 `security-review` 入口。没有扫描器时可选择“仅盘点文件”验证任务和报告流程，但这不会执行静态安全规则。

## 工作台与会话两种启动入口

- **工作台启动**：新建或编辑任务，按需勾选“同步到 DSH 会话”（默认关闭），保存并运行。开启时，每次执行创建一条独立观察会话，运行记录中可点击“打开会话”。
- **会话启动**：在已选择工作区的 DSH session 中说“用安全扫描插件后台扫描当前项目，并复核候选漏洞”。`security_start_scan` 创建任务并加入同一队列，返回 runId 后即可继续使用会话；默认同步到发起扫描的原会话，也可要求关闭同步。`security_scan_status` 查询该次运行，工作台同时展示任务、运行和报告。

同步内容是扫描阶段、模型操作摘要、读取文件名、拒绝原因、覆盖缺口和报告位置。记录标记为插件通知，不伪造模型发言，不保存思考过程或源码，不因同步额外调用模型。同步失败会提示，扫描仍继续；关闭观察会话不取消任务，请在运行记录取消。对话启动默认仅规则，用户请求模型复核时才启用任务 AI。CLI 和兼容的同步 `security_audit` 不自动创建会话。

如果结果为“覆盖不完整”，展开运行记录中的“覆盖缺口与诊断”，分别查看源码、密钥、依赖与 AI 的状态。例如文件数量上限、暂不支持的 `uv.lock`、模型预算或工具请求无效属于不同原因；缩小到具体子项目后重扫，不通过提高置信度或忽略缺口来标记完成。

## 按任务启用 Agentic AI

编辑任务，打开 **启用 Agentic AI**，保存后运行。每个任务的代码来源、扫描范围、基线、自动触发和 AI 预算分别保存；可搜索或复制已有任务，复制后先编辑再保存，不自动启动。

流程是：**代码快照 → 规则与基线 → AI 计划和取证 → 复核结论 → HTML 报告**。AI 通过官方 `ctx.llm.prepareCall()` 使用已有 DSH provider，默认读取 DSH 默认模型，也可在“模型与执行预算”填写已配置的 provider/model。插件不保存或要求另一份 API Key。启用表示允许把选取的源码片段发送给该模型，DSH 编辑后自动任务沿用这一选择。

AI 不是单次总结扫描器输出：它可以列出文件、选择审查方向、按需读取精确快照、追踪调用者和安全保护、批量复核候选并补充业务风险。默认最多 12 次模型调用、5 分钟，每次最多 4096 个输出 Token；支持按任务调整。预算耗尽、模型不可用、失败或证据不足会标明覆盖不完整，保留已有结果。

运行记录展示实际模型、轮次、读取文件、已复核候选及操作记录；报告包含同样的审查范围和结构化引用。原始规则报告与 AI 复核报告分别保留，可从运行记录打开。记录操作事实和结论，不保存模型私有推理过程或原始源码对话。AI 只复核可取证的源码候选，依赖公告和非源码密钥发现留在规则报告并显示为源码复核范围外；候选按页读取，避免大批依赖结果挤占模型上下文。工具参数、未读引用等拒绝原因会显示在执行记录，并反馈给模型纠正；连续 4 次无效调用结束本轮，已有结果保留。

AI 的工具列表固定为计划、文件列表、候选分页、证据读取、复核提交和结束。没有 shell、写文件、安装、Git hook、任意 HTTP 或 DSH 其他工具。证据限制在本次快照中的非隐藏 Python/Go/JS/TS 文件；每次最多 5 个文件、每文件 200 行，累计最多 100 个文件。上下文和单次响应另有字节上限。同一位置和 CWE 的重复补充发现不会重复计数。确认和排除均需引用真实已读的行，修改后的源码会拒绝读取。常见凭据字面量在发送前做脱敏，但这不是识别全部敏感信息的保证；仍应选择适合该代码保密级别的 DSH 模型。

AI 结束只表示本次有界流程结束，不代表所有文件或业务链路均已覆盖，不作为安全认证。AI 不执行复现代码，修复建议需要人工判断和针对性验证。规则未覆盖的候选（例如配置文件中的密钥）可能需要在会话中进一步审查；CLI/Git hooks 保持规则执行，不自动消费模型额度。

## 短命令

在本插件仓库执行。`REPO` 是待审查仓库，与插件的安装目录 `DIR` 分开：

```sh
# 全量：当前本地文件，包含未提交和未跟踪文件
make scan REPO=/absolute/path/project

# 增量：相对显式指定目标分支的共同祖先；包含本地未提交改动
make scan REPO=/absolute/path/project MODE=diff BASE=origin/main

# 暂存区：读取 Git index，不混入未暂存修改
make scan REPO=/absolute/path/project MODE=staged

# 远端指定分支/提交
make scan REPO=https://git.woa.com/team/project.git REF=main

# 全量扫描，使用历史报告作为基线，页面默认只看新增
make scan REPO=/absolute/path/project BASELINE=/path/report.json VIEW=new

# 全量扫描指定提交，并与另一个提交比较
make scan REPO=/absolute/path/project REF=HEAD BASE=HEAD~1

# 自定义输出目录；每次创建新的扫描编号，不覆盖历史
make scan REPO=/absolute/path/project OUTPUT=/absolute/path/reports
```

未指定 `REPO` 时扫描当前目录。旧的独立安装在上述命令后加相同的 `DIR=/installation/path`。命令运行**已安装的发布包**，不隐式编译开发源码。

`MODE=full|diff|staged` 控制范围；`VIEW=all|new` 只控制页面初始筛选，JSON 始终保留全部发现。`BASE` 使用 Git 重新扫描基线；`BASELINE` 使用以前的 JSON，两者互斥。`MODE=diff` 需要 `BASE`，不猜测目标分支。新增判断要求仓库、规则、引擎配置、扫描覆盖可比较；否则显示“未比较”。位置行号移动不会自动产生新问题；完全相同内容的重命名可识别。重命名同时修改、复杂跨文件关系仍需人工复核。

## 扫描器与依赖查询

**安装后首次启用插件会自动准备 Semgrep CE 1.176.1、Gitleaks 8.24.2 和独立 Python 3.13.7，无需预装 Python、pipx 或扫描器。** CLI 首次扫描也会自动准备；只做盘点且未开启密钥检查时无需下载。扫描任务等待准备完成，失败时可在「安全扫描 → 扫描设置」查看状态并重试。

工具保存在 `~/.dsh/security-scan/toolchains/`（跟随 `DSH_HOME`），与系统环境隔离。重复启动复用已验证版本；不会改 PATH、Homebrew、系统 Python 或用户配置。自动下载需要访问 GitHub Releases 和 PyPI；不上传代码。当前支持 macOS arm64/x64、Linux glibc ≥ 2.34 arm64/x64 的发布资产，真实安装及扫描已在 macOS arm64 验证，其他平台尚未实机验收。

插件包携带安装清单和依赖锁，而不是把所有平台二进制塞入 npm 包。uv 0.8.22、Gitleaks 的官方发布包按内置 SHA-256 校验；uv 使用其内置的 Python 发布校验信息，Semgrep 及依赖只接受锁文件中的 wheel 和 SHA-256，不运行项目安装脚本。失败只清理本次创建的目录，已有版本保留；并发安装有锁保护，不自动删除异常退出遗留的锁。

如需提前准备，运行 `make scan ACTION=setup`（独立安装加相同的 `DIR`）；对应 CLI 为 `dsh-security setup`。已有扫描器可在高级设置填写绝对路径，留空恢复插件管理；CLI 仍支持 `SCANNER=/absolute/path/semgrep` 和 `GITLEAKS=/absolute/path/gitleaks` 覆盖。自定义工具仍需满足上述验证版本。

Semgrep 只用包内 12 类基础规则，关闭规则联网、指标和版本检查。不是商业跨文件分析的替代品。规则包括 shell、动态代码、反序列化、TLS、SQL 和 HTML sink；模型补充权限、租户隔离、SSRF 等业务风险。

可选密钥检测使用自动准备的 Gitleaks：

```sh
make scan REPO=/path/project SECRETS=1
```

它扫描受限文件快照（包括隐藏配置文件），不扫描 Git 历史；只使用扫描器内置规则，不执行项目配置。报告不保存匹配值或原始日志，命中仍需判断真假，不尝试使用凭据。

依赖漏洞查询使用官方 OSV API：

```sh
make scan REPO=/path/project DEPS=1
```

**`DEPS=1` 明确允许向 OSV 发送依赖名称和版本，不发送源码。** 解析 npm package-lock v2/v3、pnpm lock v9、Go go.sum、Python requirements 精确版本；其他格式、未锁定项、超过 1000 条的依赖、分页或查询失败都标明覆盖不足。依赖可达性及合适的修复版本仍需复核，不猜测 CVE 或升级版本。

源码引擎按所选范围执行；密钥和依赖引擎启用时分析整份受限快照，因此即使依赖文件未改动，也可能发现新公告。报告分别列出各引擎状态。

## 报告与模型复核

默认输出到实际 DSH 数据目录的 `security-scan/reports/<扫描编号>/`：

```text
report.json  # 唯一数据源：提交/快照、范围、规则、发现、证据、建议、历史比较
report.html  # 从 JSON 生成，可离线查看、筛选、展开和打印为 PDF
```

不生成 Markdown 报告。长期只需保留 JSON，HTML 可重新生成。HTML 不加载外部脚本、字体或资源；所有报告字段作为文本转义。报告包含仓库元数据和漏洞位置，分享前按项目保密要求处理。

```sh
# 列出最近报告（自动检查的报告也在这里）
make scan ACTION=list
make scan ACTION=render REPORT=/path/report.json OUTPUT=/path/new-report.html
make scan ACTION=render REPORT=/path/report.json OUTPUT=/path/report.sarif FORMAT=sarif
```

DSH 使用 `security_audit` 生成报告；`security_read_evidence` 读取精确快照中的代码供当前模型复核；`security_review_report` 保存确认、排除、补充发现、修复建议和验证方式，生成新的 JSON/HTML 版本，保留原报告。远端证据按记录的提交重新读取；本地工作树或 index 变化后必须重扫。复核不自动修改用户代码。要求修复时，模型可以通过 DSH 原有编辑/测试工具生成补丁和针对性测试，再重新扫描验证。

CLI 本身**不启动额外 LLM**。CLI 结果标记待复核；模型复核在 DSH 会话或工作台中按任务执行。CI 可导入已有复核 JSON：

```sh
make scan ACTION=review REPORT=/path/report.json REVIEWS=/path/reviews.json
make scan ACTION=check REPORT=/path/reviewed-report.json FAIL_ON=high
```

复核输入是数组，每项包含 `findingId`、`status`（confirmed/needs-review/dismissed）、`severity`、`evidence`、`recommendation`、`verification`、`reviewer`。未复核部分不会自动算通过；“本次未检出”不会自动算已修复。

## 可选自动检查

### Git hooks

```sh
make scan ACTION=hook REPO=/path/project EVENT=pre-commit
make scan ACTION=hook REPO=/path/project EVENT=pre-push BASE=origin/main
make scan ACTION=hook REPO=/path/project EVENT=pre-commit HOOK_ACTION=remove
```

仅在显式安装命令后写入目标仓库的 hook。pre-push 读取 Git 提供的实际推送提交，逐个检查非删除的 ref，不混入未提交改动。默认提醒，不阻断提交。`ENFORCE=1` 可令扫描失败/不完整阻断 hook；候选发现不会冒充已确认漏洞来阻断。复核后可用 `ACTION=check FAIL_ON=high|medium` 对新增、已确认问题执行质量门禁。

已有 hook 或 `core.hooksPath` 一律保留；请将上述 scan 命令接入既有 hook 管理器，不自动覆盖或拼接未知脚本。修改本插件的 hook 选项时先 remove 再 install。钩子固定引用安装时的 CLI、Node、扫描器和报告目录，移动安装后应重新安装 hook。

### DSH 编辑后检查

在实际 DSH 的 `settings.yaml` 中配置，默认关闭：

```yaml
security-scan:
  semgrepPath: /absolute/path/to/semgrep
  gitleaksPath: /absolute/path/to/gitleaks
  autoScan: true
  hookTools: [write, edit, str_replace_editor, write_file, edit_file, apply_patch]
```

使用官方 `tools/result` 事件观察成功的指定工具调用；按工作区合并连续编辑，后台对 `HEAD` 做增量规则检查。默认覆盖官方 `write`、`edit` 和 `str_replace_editor`，并保留其他编辑插件常用别名；`str_replace_editor` 的 view 不触发。旧版显式配置了别名列表的用户，可在工作台扫描设置里补入官方名称。不监听本插件自己的工具，不递归扫描报告，不自动联网查询或启动 LLM；报告位置写入 Host 日志。无 Git 历史或扫描失败会提示重新手动检查。禁用后停止接收新任务；卸载时取消并等待已有任务。

### CI / 定期全量

统一入口也可在已准备好 DSH、插件和扫描器的 CI runner 中调用：

```sh
# PR/MR job：TARGET_BRANCH 由 CI 提供，先确保目标分支历史已获取
make scan REPO="$PROJECT_DIR" MODE=diff BASE="$TARGET_BRANCH" OUTPUT="$ARTIFACT_DIR/security"
# 主分支或定期 job
make scan REPO="$PROJECT_DIR" MODE=full OUTPUT="$ARTIFACT_DIR/security"
```

归档 JSON/HTML；如平台支持，再导出 SARIF。调度由现有 CI 配置负责，此插件不创建系统 cron、不修改远端流水线。没有后台模型账号时，CI 只运行规则，不能将其称作已完成模型审计。

退出码：`0` 扫描完成且未触发所配置门禁；`1` 新增已确认问题超过阈值；`2` 扫描不完整、扫描器缺失/失败或输入错误。`ENGINE=inventory` 只盘点范围，不代表安全检查通过。

## 边界与开发

临时快照限 5000 个文本文件、20000 个目录项、单文件 1 MiB、总计 64 MiB；源码扫描另外限 1500 个源文件、32 MiB、200 条规则发现。隐藏源码、二进制、符号链接、依赖/构建目录按报告说明排除。不应用项目 `.gitignore`、`.semgrepignore` 或自带扫描配置；不执行子模块、项目脚本或依赖安装。超限和覆盖缺口在报告中保留。

```sh
pnpm --filter @shamcleren/dsh-security-scan typecheck
pnpm --filter @shamcleren/dsh-security-scan test
SECURITY_TEST_SEMGREP=/path/semgrep pnpm --filter @shamcleren/dsh-security-scan test
pnpm --filter @shamcleren/dsh-security-scan build
```

规则引擎真实用例未配置扫描器时明确跳过。设置 `SECURITY_TEST_INSTALLATION` 指向隔离的测试安装后，还会验证发布包经官方 profile 加载器成功合成；未设置时该项明确跳过。真实微信/模型账号、远端私有仓库权限和不同平台兼容性需要分别验收。
