/** Minimal same-process Host API used by the channel plugin. */
export interface RpcRequest<T> {
    rpcId: string;
    payload: T;
}
export type RpcResult<T> = {
    ok: true;
    value: T;
} | {
    ok: false;
    error: {
        code: string;
        message: string;
    };
};
export interface RpcResponse<T> {
    rpcId: string;
    result: RpcResult<T>;
}
export interface HostSessionEvent {
    type: string;
    seq: number;
    data: unknown;
}
export interface SessionEventFrame {
    type: 'session/event';
    sessionId: string;
    event: HostSessionEvent;
}
export type HostMuxFrame = SessionEventFrame | {
    type: string;
    sessionId?: string;
};
export interface HistoryEntry {
    event: HostSessionEvent;
}
export interface HostApiProxy {
    workspace: {
        create(request: RpcRequest<{
            path: string;
        }>): Promise<RpcResponse<{
            workspace: {
                workspaceId: string;
                title: string;
            };
            created: boolean;
        }>>;
        rename(request: RpcRequest<{
            workspaceId: string;
            title: string;
        }>): Promise<RpcResponse<{
            workspace: {
                workspaceId: string;
                title: string;
            };
        }>>;
    };
    sessions: {
        create(request: RpcRequest<{
            sessionId: string;
            workspaceId?: string;
            agentPreset?: string;
        }>): Promise<RpcResponse<{
            sessionId: string;
            agentPreset?: string;
        }>>;
        history(request: RpcRequest<{
            sessionId: string;
            beforeSeq?: number;
            maxMessages?: number;
        }>): Promise<RpcResponse<{
            events: HistoryEntry[];
            hasMore: boolean;
        }>>;
        prompt(request: RpcRequest<{
            sessionId: string;
            mode: 'continue';
            content: [{
                type: 'text';
                text: string;
            }];
        }>): Promise<RpcResponse<{
            accepted: true;
            disposition: 'next-turn' | 'next-step';
            command?: {
                kind: 'success';
                text?: string;
            };
        }>>;
        models(request: RpcRequest<{
            sessionId: string;
        }>): Promise<RpcResponse<{
            current: {
                provider: string;
                model: string;
                reasoningEffort?: string;
            };
            groups: Array<{
                id: string;
                name: string;
                models: Array<{
                    id: string;
                    name: string;
                    reasoning?: {
                        efforts: Array<{
                            id: string;
                            name: string;
                        }>;
                        defaultEffort?: string;
                    };
                }>;
            }>;
        }>>;
        selectModel(request: RpcRequest<{
            sessionId: string;
            provider: string;
            model: string;
            reasoningEffort?: string;
        }>): Promise<RpcResponse<{
            selected: {
                provider: string;
                model: string;
                reasoningEffort?: string;
            };
        }>>;
    };
    events: {
        mux(request: RpcRequest<Record<string, never>>, signal: AbortSignal): AsyncIterable<RpcRequest<HostMuxFrame>>;
    };
}
/** Host business error retaining its stable RPC code for recovery decisions. */
export declare class HostApiError extends Error {
    readonly code: string;
    constructor(code: string, message: string);
}
/** Return a successful unary value or raise the Host's business error. */
export declare function unwrap<T>(response: RpcResponse<T>): T;
