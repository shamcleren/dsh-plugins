/** Self-contained desktop-pet settings card contributed through `plugins.bundle.config`. */
import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { DesktopPetCardFace } from './controller.js';
export type DesktopPetCardProps = PropsRuntime<'plugins.bundle.config'> & PropsLocale<'settings.desktop-pet'> & InjectFace<DesktopPetCardFace>;
export declare function DesktopPetCard(props: DesktopPetCardProps): import("react").JSX.Element;
