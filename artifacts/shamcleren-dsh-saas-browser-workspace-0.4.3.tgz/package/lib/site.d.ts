import { z } from 'zod';
export declare const ExecutionRule: z.ZodObject<{
    mode: z.ZodEnum<{
        debug: "debug";
        use: "use";
    }>;
    origin: z.ZodString;
    paths: z.ZodArray<z.ZodString>;
    scope: z.ZodString;
    input: z.ZodString;
    submit: z.ZodString;
    output: z.ZodString;
    busy: z.ZodString;
    error: z.ZodString;
}, z.core.$strict>;
export type ExecutionRule = z.infer<typeof ExecutionRule>;
export declare const Site: z.ZodObject<{
    name: z.ZodString;
    url: z.ZodString;
    allowedOrigins: z.ZodArray<z.ZodString>;
    blockedHosts: z.ZodDefault<z.ZodArray<z.ZodString>>;
    loginPaths: z.ZodDefault<z.ZodArray<z.ZodString>>;
    navigationPaths: z.ZodDefault<z.ZodArray<z.ZodString>>;
    navigationQueryKeys: z.ZodDefault<z.ZodArray<z.ZodString>>;
    execution: z.ZodDefault<z.ZodArray<z.ZodObject<{
        mode: z.ZodEnum<{
            debug: "debug";
            use: "use";
        }>;
        origin: z.ZodString;
        paths: z.ZodArray<z.ZodString>;
        scope: z.ZodString;
        input: z.ZodString;
        submit: z.ZodString;
        output: z.ZodString;
        busy: z.ZodString;
        error: z.ZodString;
    }, z.core.$strict>>>;
    selectors: z.ZodDefault<z.ZodObject<{
        search: z.ZodString;
        results: z.ZodString;
        card: z.ZodString;
        name: z.ZodString;
        type: z.ZodString;
        version: z.ZodString;
        tags: z.ZodString;
        description: z.ZodString;
    }, z.core.$strict>>;
    emptyText: z.ZodDefault<z.ZodString>;
    screenshotMasks: z.ZodDefault<z.ZodArray<z.ZodString>>;
}, z.core.$strict>;
export type Site = z.infer<typeof Site>;
/** Self-contained so the isolated MCP page setup uses the same policy as the native service. */
export declare function createRequestPolicy(site: Pick<Site, 'allowedOrigins' | 'blockedHosts'>): {
    permits: (value: string) => boolean;
    upgrade: (value: string) => string | undefined;
};
export declare function isAllowed(site: Pick<Site, 'allowedOrigins' | 'blockedHosts'>, value: string): boolean;
export declare function navigationUrl(site: Site, value?: string): string;
export declare function loadSite(path: string): Promise<Site>;
