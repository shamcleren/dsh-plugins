import type { Site, ExecutionRule } from './site.js';
/** Runs in the page's main frame. Read only DOM/ARIA, with shared masking and bounded output. */
export declare function observePage({ selectors, readLabels, rule, emptyText, masks }: {
    selectors: Site['selectors'];
    readLabels: string[];
    rule: ExecutionRule | undefined;
    emptyText: string;
    masks: string[];
}): {
    title: string;
    text: string;
    controls: {
        ref: string;
        selector: string;
        label: string;
        role: string;
        value: string;
        canFill: boolean;
        canClick: boolean;
        sensitive: boolean;
        purpose: "message" | "submit" | "readonly" | "search" | "navigation";
    }[];
    records: {
        id: string;
        name: string;
        type: string;
        version: string;
        description: string;
        tags: string[];
        actions: {
            ref: string;
            label: string;
        }[];
    }[];
    recordsState: "empty" | "unavailable" | "loading" | "ready";
    document: {
        blocks: ({
            kind: "fields";
            title: string;
            fields: {
                label: string;
                kind: "number" | "text" | "multiline" | "choice" | "toggle";
                state: "value" | "empty" | "unread" | "redacted";
                value: string;
                checked?: "on" | "off" | "mixed" | undefined;
            }[];
        } | {
            kind: "table";
            title: string;
            columns: string[];
            rows: string[][];
        } | {
            kind: "list";
            title: string;
            items: string[];
        } | {
            kind: "text";
            title: string;
            text: string;
        })[];
        gaps: {
            kind: "unread" | "collapsed" | "graphic" | "embedded" | "editor" | "unstructured" | "limit";
            label: string;
        }[];
        truncated: boolean;
    };
    truncated: boolean;
};
