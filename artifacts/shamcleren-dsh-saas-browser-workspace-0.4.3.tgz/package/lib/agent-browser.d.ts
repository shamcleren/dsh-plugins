import type { BrowserService } from '@anweat/dsh-browser';
import type { Site } from './site.js';
import { BrowserArgs, type PageObservation, type Control, type HumanInput } from './agent-contract.js';
import { Executions } from './agent-execution.js';
export interface LocatedControl extends Control {
    selector: string;
}
/** Adds bounded site navigation and explicitly registered chat actions to the public browser service. */
export declare class AgentBrowser {
    private service;
    readonly sessionId: string;
    readonly site: Site;
    private page?;
    private context?;
    private cdps;
    private pages;
    private allowPopup;
    private popupAdmitted;
    private popupRequests;
    readonly executions: Executions;
    private controls;
    private observation?;
    private stopped;
    blockedOrigin?: string;
    constructor(service: BrowserService, sessionId: string, site: Site, journalPath?: string);
    get ready(): boolean;
    get url(): string;
    get login(): boolean;
    initialize(): Promise<void>;
    private attach;
    act(raw: BrowserArgs, signal: AbortSignal): Promise<PageObservation | undefined>;
    private validateInput;
    resolve(observationId?: string, ref?: string): LocatedControl;
    observe(): Promise<PageObservation>;
    frame(): Promise<Buffer>;
    input(input: HumanInput): Promise<void>;
    close(): Promise<void>;
}
