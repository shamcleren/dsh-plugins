import type { Readable, Writable } from 'node:stream';
export interface CodexChild {
    stdin?: Writable;
    stdout?: Readable;
    stderr?: Readable;
    done: Promise<{
        exitCode: number | null;
        signal: NodeJS.Signals | null;
    }>;
    terminate(): void;
    waitForExit(signal?: AbortSignal): Promise<boolean>;
}
export interface CodexSpawn {
    (spec: {
        argv: readonly string[];
        cwd: string;
        graceMs: number;
        env?: NodeJS.ProcessEnv;
    }): CodexChild;
}
export interface TurnEnd {
    status: 'completed' | 'interrupted' | 'failed';
    error?: string;
}
/** Owns handshake, thread resume, one in-flight turn, and process-tree teardown. */
export declare class CodexConnection {
    private readonly child;
    private readonly onServerRequest;
    private readonly onNotification;
    readonly notifications: Array<{
        method: string;
        params: Record<string, unknown>;
    }>;
    private readonly transport;
    private readonly fatal;
    private threadId;
    private turnId;
    private appliedModel;
    private appliedEffort;
    private waiter;
    private closed;
    constructor(child: CodexChild, onServerRequest: (method: string, params: Record<string, unknown>) => Promise<unknown>, onNotification: (method: string, params: Record<string, unknown>) => void);
    start(): void;
    matches(model: string | undefined, effort: string | undefined): boolean;
    initialize(signal: AbortSignal): Promise<void>;
    rateLimits(signal: AbortSignal): Promise<Record<string, unknown> | undefined>;
    openThread(cwd: string, model: string | undefined, existing: string | undefined, signal: AbortSignal, effort?: string): Promise<string>;
    turn(text: string, signal: AbortSignal): Promise<TurnEnd>;
    interrupt(): void;
    dispose(): Promise<void>;
    private observe;
    private request;
    private fail;
}
