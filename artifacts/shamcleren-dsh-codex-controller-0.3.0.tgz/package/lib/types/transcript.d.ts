/** Session-log markers and human-prompt selection for a Codex-backed conversation. */
import type { Message } from '@deepseek-ai/dsh-llm';
import type { Session } from '@deepseek-ai/dsh-session';
export declare const PLUGIN = "codex-controller";
export declare const THREAD_MARKER = "codex-thread:";
/** The newest direct human text. Plugin notices and tool results are not Codex turns. */
export declare function latestHumanText(messages: readonly Message[]): string;
/**
 * Human text plus user-invoked skill and plugin-instruction bodies from the same request.
 * Those bodies are DSH pre-step context, not DSH tool calls, so Codex receives them as text.
 */
export declare function turnText(messages: readonly Message[]): string;
/**
 * The question behind a title request. The title service sends its own plugin message
 * holding the human messages as JSON, so the ordinary human-text selection finds nothing.
 */
export declare function titleText(messages: readonly Message[]): string;
/** A short list title taken from the question. Codex identity is not written into the title. */
export declare function localTitle(text: string): string;
/** Recover a thread id previously written into this session's notices. */
export declare function threadIdFromSession(session: Pick<Session, 'snapshotEvents'>): string | undefined;
export declare function threadNotice(threadId: string): {
    summary: string;
    text: string;
};
export declare function bound(summary: string): string;
