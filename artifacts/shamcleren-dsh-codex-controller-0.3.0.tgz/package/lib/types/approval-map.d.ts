/** Map DSH's one-shot approval vocabulary onto Codex app-server decisions. */
export type CodexDecision = 'accept' | 'decline' | 'cancel';
export type DshOutcome = 'allowed-once' | 'rejected' | 'cancelled' | 'unavailable';
/** Never synthesize a session-wide or policy-amendment grant. */
export declare function decisionFor(outcome: DshOutcome): CodexDecision;
export declare function approvalPrompt(method: string, params: Record<string, unknown>): {
    toolName: string;
    reason: string;
};
export declare function approvalResponse(method: string, params: Record<string, unknown>, decision: CodexDecision): Record<string, unknown>;
