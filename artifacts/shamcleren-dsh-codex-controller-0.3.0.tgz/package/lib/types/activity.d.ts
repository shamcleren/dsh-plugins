/** User-visible Codex activity. Unknown protocol events degrade instead of disappearing. */
export interface CodexActivity {
    id: string;
    kind: string;
    status: string;
    title: string;
    detail: string;
}
export interface CodexQuestion {
    id: string;
    kind: 'user-input' | 'elicitation';
    prompt: string;
    fields: Array<{
        id: string;
        label: string;
    }>;
}
/** Context fill from `thread/tokenUsage/updated`. Absent window means no percentage. */
export interface ContextUsage {
    used: number;
    window: number;
    percent: number;
}
/** Account window from `account/rateLimits/updated`. Missing used percent means no bar. */
export interface QuotaUsage {
    remaining: number;
    resetsAt?: number;
    windowMinutes?: number;
}
export declare function contextUsage(params: Record<string, unknown>): ContextUsage | undefined;
export declare function quotaUsage(params: Record<string, unknown>): QuotaUsage | undefined;
export declare function projectItem(method: string, params: Record<string, unknown>): CodexActivity | undefined;
export declare function projectTurn(method: string, params: Record<string, unknown>): CodexActivity | undefined;
export declare function questionFrom(method: string, id: string, params: Record<string, unknown>): CodexQuestion | undefined;
export declare function safeJson(value: unknown): string;
export declare function bound(value: string): string;
