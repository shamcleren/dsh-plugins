import type { SharedBatch } from './transport.js';
import type { LocaleKey } from './locales.js';
/** Pin to the window, not `shell.overlay`: that layer is a full-frame absolute box whose
 *  static children start at the title-bar origin (traffic lights / top-left). */
export declare const panelPlacement: {
    position: "fixed";
    top: number;
    right: number;
    left: string;
    zIndex: number;
};
export interface DraftChoice {
    id: string;
    name: string;
    status?: 'uploading' | 'ready' | 'error' | undefined;
}
export interface PanelProps {
    t: (key: LocaleKey) => string;
    pending: SharedBatch[];
    drafts: DraftChoice[];
    currentTitle?: string | undefined;
    busy: boolean;
    locked: boolean;
    notice: string;
    onAdd: (batch: SharedBatch) => void;
    onDismiss: (batch: SharedBatch) => void;
    onRemove: (id: string) => void;
    onRetry: (id: string) => void;
    onRefresh: () => void;
    onReveal: () => void;
    onClearNotice: () => void;
}
export declare function SharePanel(p: PanelProps): import("react").ReactPortal;
export declare const panelCSS = "\n.dsh-share{--share-line:#e5e7eb;--share-bg:#fff;--share-soft:#f6f7f9;--share-text:#252a34;--share-muted:#727985;position:fixed;top:60px;right:16px;left:auto;z-index:100;width:min(300px,calc(100vw - 32px));color:var(--share-text);background:var(--share-bg);border:1px solid var(--share-line);border-radius:12px;font:12px/1.45 -apple-system,BlinkMacSystemFont,sans-serif;overflow:hidden;text-align:left;box-shadow:0 4px 18px #00000012}\nbody[data-ds-dark-theme] .dsh-share{--share-line:#35383e;--share-bg:#202226;--share-soft:#292c31;--share-text:#e5e7eb;--share-muted:#a1a8b5}\n.dsh-share *{box-sizing:border-box}.dsh-share button{font:inherit;cursor:pointer;border:0;background:none;color:inherit;line-height:1.45}.dsh-share button:disabled{cursor:default;opacity:.5}.dsh-share button:focus-visible{outline:2px solid #4b76f8;outline-offset:-2px}.dsh-share button:hover:not(:disabled){background:var(--share-soft)}\n.dsh-share header{display:flex;align-items:center;justify-content:space-between;padding:5px 8px 3px 10px}.dsh-share-heading{padding:2px 0;font-weight:500!important;color:var(--share-muted)!important}.dsh-share-heading span{font-size:10px;margin:0 4px}.dsh-share .dsh-share-tool{padding:3px 5px;color:var(--share-muted);font-size:11px;border-radius:5px}.dsh-share-body{max-height:min(230px,40vh);overflow-y:auto;padding:0 5px 5px}.dsh-share-row{display:flex;align-items:center;gap:4px;border-radius:7px}.dsh-share-add,.dsh-share-file{display:flex;flex-direction:column;align-items:flex-start;min-width:0;flex:1;text-align:left;padding:6px 7px;border-radius:7px}.dsh-share-name{display:block;max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.dsh-share small{font-size:10px;color:var(--share-muted);margin-top:2px}.dsh-share-add small{color:#4775ee}.dsh-share .dsh-share-remove{font-size:18px;color:var(--share-muted);width:25px;height:25px;flex-shrink:0;border-radius:6px;padding:0}.dsh-share-notice{display:flex;align-items:center;gap:4px;padding:5px 7px;font-size:11px;color:var(--share-muted)}.dsh-share-notice>span{flex:1}\n";
