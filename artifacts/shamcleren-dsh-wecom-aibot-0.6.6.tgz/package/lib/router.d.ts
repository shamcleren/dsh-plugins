import type { Logger } from '@deepseek-ai/cordis';
import type { ImageAttachmentRef } from '@deepseek-ai/dsh-attachment';
import type { ApprovalOutcome } from '@deepseek-ai/dsh-user-approval';
import type { EventMessageWith, TemplateCard, TemplateCardEventData, WsFrame, WsFrameHeaders } from '@wecom/aibot-node-sdk';
import type { HostApiProxy, HostWorkspace } from './host-api.js';
import type { WeComTextFrame } from './inbound.js';
import type { ConversationBindings } from './bindings.js';
import type { WeComSettingsPatch } from './config.js';
export interface WeComReplyClient {
    replyStream(frame: WsFrameHeaders, streamId: string, content: string, finish?: boolean): Promise<WsFrame>;
    replyStreamNonBlocking(frame: WsFrameHeaders, streamId: string, content: string, finish?: boolean): Promise<WsFrame | 'skipped'>;
    sendMessage(targetId: string, body: {
        msgtype: 'template_card';
        template_card: TemplateCard;
    } | {
        msgtype: 'markdown';
        markdown: {
            content: string;
        };
    }): Promise<WsFrame>;
    uploadMedia(fileBuffer: Buffer, options: {
        type: 'image';
        filename: string;
    }): Promise<{
        media_id: string;
    }>;
    sendMediaMessage(targetId: string, mediaType: 'image', mediaId: string): Promise<WsFrame>;
    updateTemplateCard(frame: WsFrameHeaders, templateCard: TemplateCard, userids?: string[]): Promise<WsFrame>;
}
export type WeComTemplateCardEventFrame = WsFrame<EventMessageWith<TemplateCardEventData>>;
export interface RouterConfig {
    allowedUsers: readonly string[];
    adminUsers: readonly string[];
    agentPreset?: string;
    thinkingText: string;
    turnTimeoutMs: number;
}
export interface RouterRuntimeContext {
    bindings: Pick<ConversationBindings, 'current' | 'set'>;
    defaultWorkspace: HostWorkspace;
    /** Durable image bytes, absent when the deployment has no attachment store. */
    readImage?: (ref: ImageAttachmentRef) => Promise<Uint8Array>;
}
export interface ChannelApprovalRequest {
    id: string;
    sessionId: string;
    toolName: string;
    callId?: string;
    reason?: string;
    signal?: AbortSignal;
    resolved: Promise<{
        outcome: ApprovalOutcome;
    }>;
}
export interface ChannelApprovalAnswer {
    outcome: 'allowed-once' | 'rejected';
    actorRef: string;
}
/** Route WeCom text frames through the Host API and project durable turn output back to WeCom. */
export declare class WeComConversationRouter {
    private readonly api;
    private readonly replies;
    private readonly logger;
    private readonly config;
    private readonly runtime;
    private readonly writeSettings;
    private readonly allowedUsers;
    private readonly adminUsers;
    private readonly listeners;
    private readonly admissions;
    private readonly tasks;
    private readonly sessionStates;
    private readonly activeTurns;
    private readonly pendingApprovals;
    private readonly pendingQuestions;
    private readonly settledCards;
    private readonly turnAborts;
    private muxAbort;
    private muxTask;
    private muxFailure;
    private stopping;
    /** Live channel preset; `/preset` moves it without reopening the socket. */
    private agentPreset;
    constructor(api: HostApiProxy, replies: WeComReplyClient, logger: Logger, config: RouterConfig, runtime: RouterRuntimeContext, writeSettings?: (section: WeComSettingsPatch) => Promise<void>);
    /** Adopt a settings-side preset change without disturbing live conversations. */
    setAgentPreset(next: string | undefined): void;
    /** Begin the one Host event stream shared by every WeCom conversation. */
    start(): void;
    /** Accept one SDK callback without allowing its promise to escape EventEmitter. */
    accept(frame: WeComTextFrame): void;
    /** Accept one template-card click without allowing its promise to escape EventEmitter. */
    acceptTemplateCardEvent(frame: WeComTemplateCardEventFrame): void;
    private track;
    /** Stop callbacks and the Host stream, then settle every router-owned task. */
    stop(): Promise<void>;
    /** Whether this channel owns the exact live session turn. */
    /** Route questions and events only while this channel owns the active turn. */
    routesSession(sessionId: string): boolean;
    /**
     * Whether this channel is waiting on the session's events. This opens when the
     * turn subscribes, which is earlier than `routesSession`: the agent emits
     * `turn/start` and the admitting `user/message` while the prompt submission is
     * still in flight, and those are the only events that attribute a turn to this
     * channel. Dropping them at the source leaves the turn unattributable, so it
     * never completes and can only end by timing out.
     */
    observesSession(sessionId: string): boolean;
    ownsSession(sessionId: string): boolean;
    /** Offer one DSH approval only when its agent turn is currently owned by this channel. */
    requestApproval(request: ChannelApprovalRequest): Promise<ChannelApprovalAnswer | undefined>;
    private consumeMux;
    private consumeMuxFrame;
    private presentQuestion;
    private resolveQuestion;
    private publish;
    private subscribe;
    private routeFrame;
    private routeTemplateCardEvent;
    private answerApprovalCard;
    private answerQuestionCard;
    private cardSelection;
    private admitFrame;
    private completeTurn;
    private handleQuestionCommand;
    private acceptQuestionAnswer;
    private submitQuestionAnswers;
    private respondQuestionAnswers;
    private parseQuestionAnswer;
    private questionTarget;
    private matchQuestionOptions;
    private answerUsage;
    private formatQuestions;
    private approvalCard;
    private questionCard;
    private currentQuestion;
    private currentQuestionIndex;
    private resolvedCard;
    private limitCardText;
    private rememberSettledCard;
    private interactiveUpdate;
    private removePendingQuestion;
    private handleApprovalCommand;
    private settleApproval;
    private withdrawApproval;
    private removePendingApproval;
    private actorRef;
    private withNotice;
    private segmentText;
    private rotateProactive;
    private sendProactiveText;
    /**
     * Deliver durable images as their own WeCom messages. Each one is uploaded as
     * temporary media and pushed through the active-send channel, which stays
     * usable after the stream reply has already finished. Anything that cannot be
     * delivered is named in a single notice instead of disappearing.
     */
    private sendImages;
    private ensureSession;
    private createSession;
    private runManagementCommand;
    private status;
    private newSession;
    private workspace;
    /**
     * Move the channel's agent preset.
     *
     * Unlike `/model`, this stays inside WeCom: the preset lives in this plugin's
     * own settings section, and a session names its preset at creation, so the
     * switch persists for the channel and takes effect on a rebuilt session
     * instead of leaking into any deployment-wide default.
     */
    private preset;
    private selectWorkspace;
    private workspaceIdForSession;
    private listWorkspaces;
    private model;
    private effort;
    private sessionState;
    private loadSessionState;
    private findApprovalCommand;
    private waitForTurn;
    private update;
    private reliableUpdate;
    private finish;
}
