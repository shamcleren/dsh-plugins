import type { Context } from '@deepseek-ai/cordis';
import type { RemoteResult } from '@deepseek-ai/dsh-typert-protocol';
import type { CredentialInfo } from '@deepseek-ai/dsh-credentials/types';
export interface CardApi {
    credentials: {
        describe(request: {
            refs: string[];
        }): Promise<{
            result: RemoteResult<{
                credentials: Record<string, CredentialInfo>;
            }>;
        }>;
        set(request: {
            ref: string;
            value: string;
        }): Promise<{
            result: RemoteResult<void>;
        }>;
    };
    workspace: {
        list(request: object): Promise<{
            result: RemoteResult<{
                items: readonly {
                    workspaceId: string;
                    path: string;
                    title: string;
                }[];
            }>;
        }>;
    };
    presets: {
        list(request: object): Promise<{
            result: RemoteResult<{
                items: readonly PresetOption[];
                defaultId?: string;
            }>;
        }>;
    };
}
export interface PresetOption {
    id: string;
    name?: string;
    broken?: string;
}
export declare function cardApi(ctx: Context): CardApi;
