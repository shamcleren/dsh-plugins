/** WeCom settings scope and write-only credential projection for the browser card. */
import type { CardApi as IApiClient, PresetOption } from './api.js';
import type { SettingsScope } from '@deepseek-ai/dsh-client-ui-settings/client';
type SnapshotStore<T> = {
    getSnapshot(): T;
    subscribe(listener: () => void): () => void;
    set(value: T): void;
    update(mutator: (value: T) => void): void;
};
import type { Config } from '../config.js';
import { type FieldState, type FormActions, type FormState } from './form.js';
/**
 * Why one credential write did not leave the reference configured. A `message`
 * carries the deployment's own refusal text; its absence means the deployment
 * accepted the write and still reports the reference unconfigured.
 */
export interface CredentialFailure {
    ref: string;
    message?: string;
}
export interface WeComCardState extends FormState {
    botId: FieldState;
    secret: FieldState;
    allowedUsers: FieldState;
    adminUsers: FieldState;
    workspaceId: FieldState;
    workspaceOptions: readonly WorkspaceOption[];
    workspacesLoading: boolean;
    workspacesFailed: boolean;
    presetOptions: readonly PresetOption[];
    presetsLoading: boolean;
    presetsFailed: boolean;
    presetDefaultId?: string;
    preventIdleSleep: FieldState;
    agentPreset: FieldState;
    thinkingText: FieldState;
    turnTimeoutMs: FieldState;
    botIdConfigured: boolean;
    botIdWritable: boolean;
    secretConfigured: boolean;
    secretWritable: boolean;
    credentialFailure?: CredentialFailure;
}
export type { PresetOption } from './api.js';
export interface WorkspaceOption {
    id: string;
    title: string;
    path: string;
}
export interface WeComCardFace extends FormActions {
    hooks: {
        weComCard: SnapshotStore<WeComCardState>;
    };
}
/** Synchronizes one WeCom card with settings and credential stores. */
export declare class WeComCardController {
    private readonly scope;
    private readonly api;
    private readonly form;
    private readonly store;
    private botId;
    private secret;
    private workspaceOptions;
    private workspacesLoading;
    private workspacesFailed;
    private presetOptions;
    private presetsLoading;
    private presetsFailed;
    private presetDefaultId;
    private credentialFailure;
    constructor(scope: SettingsScope<Config>, api: Pick<IApiClient, 'credentials' | 'workspace' | 'presets'>);
    refreshCredential(ref: string): void;
    inject(): WeComCardFace;
    private projection;
    private readWorkspaces;
    private readPresets;
    private readCredentials;
    private writeCredential;
}
