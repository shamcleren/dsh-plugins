/** Channel-owned approval presentation over the upstream approval waterfall. */
import type { Context } from '@deepseek-ai/cordis';
import type { ApprovalOutcome } from '@deepseek-ai/dsh-user-approval';
export interface ChannelApproval {
    id: string;
    sessionId: string;
    toolName: string;
    callId?: string;
    reason?: string;
    signal: AbortSignal;
    resolved: Promise<{
        outcome: ApprovalOutcome;
    }>;
}
/** Route owned requests to the channel; unrelated sessions delegate to the Host. */
export declare function installChannelApproval(ctx: Context, owns: (sessionId: string) => boolean, present: (request: ChannelApproval) => Promise<{
    outcome: 'allowed-once' | 'rejected';
} | undefined>): void;
