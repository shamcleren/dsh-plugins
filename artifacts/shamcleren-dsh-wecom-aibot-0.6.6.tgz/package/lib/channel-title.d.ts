import type { Context } from '@deepseek-ai/cordis';
export { CHANNEL_SESSION_PREFIX, CHANNEL_TITLE_MARK, channelTitle, isChannelSession } from './channel-id.js';
/**
 * Keep channel Sessions marked after DSH writes an automatic title.
 * `sessionController.rename` pins the result, so this waits for a real title
 * instead of naming a blank Session `【企业微信】新会话` and blocking later titles.
 */
export declare function installChannelTitle(ctx: Context, logger: {
    warn(message: string): void;
}): void;
