import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { WeChatCardFace } from './controller.js';
export type WeChatCardProps = PropsRuntime<'plugins.bundle.config'> & PropsLocale<'settings.wechat'> & InjectFace<WeChatCardFace>;
/** Render personal WeChat settings on this plugin's page in the official plugin manager. */
export declare function WeChatCard(props: WeChatCardProps): import("react").JSX.Element;
