/** Browser half of the WeChat plugin: contributes its own settings card. */
import type { Context as ClientContext } from '@deepseek-ai/cordis';
import { createElement } from 'react';
import { type LocaleKey } from './locales.js';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** Copy owned by the external WeChat settings card. */
        'settings.wechat': LocaleKey;
    }
}
export declare const inject: string[];
/** Register the WeChat card when the generic plugin-settings slot exists. */
export declare function apply(ctx: ClientContext): Promise<() => Promise<void>>;
/** Header mark for the open personal WeChat Session. */
export declare function ChannelBadge(props: {
    sessionId: string | undefined;
    t: (key: LocaleKey) => string;
}): ReturnType<typeof createElement> | null;
