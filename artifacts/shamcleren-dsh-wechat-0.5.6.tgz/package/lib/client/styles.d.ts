/** Inline styles keep the external client bundle independent of repository CSS tooling. */
/** Mirrors the official plugin-manager config pages: flat sections, no wrapping card. */
export declare const styles: {
    form: {
        display: "flex";
        flexDirection: "column";
        gap: number;
        minWidth: number;
    };
    section: {
        display: "flex";
        flexDirection: "column";
        gap: number;
        minWidth: number;
        padding: string;
    };
    sectionHeading: {
        flex: number;
        margin: number;
        fontSize: number;
        fontWeight: number;
        lineHeight: number;
        color: "var(--dsw-alias-label-primary)";
    };
    hiddenLabel: {
        position: "absolute";
        width: number;
        height: number;
        overflow: "hidden";
        clip: "rect(0 0 0 0)";
    };
    badge: {
        borderRadius: number;
        padding: string;
        fontSize: number;
        lineHeight: string;
        background: string;
        color: "var(--dsw-alias-label-secondary)";
    };
    mutedBadge: {
        borderRadius: number;
        padding: string;
        fontSize: number;
        color: "var(--dsw-alias-label-tertiary)";
    };
    field: {
        display: "flex";
        flexDirection: "column";
        gap: number;
        padding: string;
    };
    fieldHead: {
        display: "flex";
        alignItems: "center";
        gap: number;
    };
    label: {
        flex: number;
        fontSize: number;
        fontWeight: number;
        color: "var(--dsw-alias-label-primary)";
    };
    input: {
        height: number;
        padding: string;
        border: string;
        borderRadius: number;
        background: string;
        color: "var(--dsw-alias-label-primary)";
        fontSize: number;
    };
    hint: {
        margin: number;
        fontSize: number;
        lineHeight: number;
        color: "var(--dsw-alias-label-tertiary)";
    };
    error: {
        margin: number;
        fontSize: number;
        lineHeight: number;
        color: "var(--dsw-alias-label-error)";
    };
    reset: {
        border: number;
        background: string;
        color: "var(--dsw-alias-label-secondary)";
        cursor: "pointer";
    };
    toggle: {
        display: "inline-flex";
        alignItems: "center";
        gap: number;
        fontSize: number;
    };
    qr: {
        alignSelf: "center";
        borderRadius: number;
        background: string;
    };
    loginActions: {
        display: "flex";
        alignItems: "center";
        gap: number;
        flexWrap: "wrap";
    };
    footer: {
        display: "flex";
        alignItems: "center";
        gap: number;
        flexWrap: "wrap";
        paddingTop: number;
    };
    button: {
        border: string;
        borderRadius: number;
        padding: string;
        background: string;
        color: "var(--dsw-alias-label-secondary)";
        cursor: "pointer";
    };
    save: {
        border: string;
        borderRadius: number;
        padding: string;
        fontSize: number;
        background: string;
        color: "var(--dsw-alias-bg-layer-3)";
        cursor: "pointer";
    };
    disabled: {
        opacity: number;
        cursor: "default";
    };
};
