import z from '@deepseek-ai/schemastery';
export declare const DEFAULT_BASE_URL = "https://ilinkai.weixin.qq.com";
export declare const DEFAULT_CDN_BASE_URL = "https://novac2c.cdn.weixin.qq.com/c2c";
export declare const DEFAULT_THINKING_TEXT = "\u6B63\u5728\u601D\u8003\u2026";
export declare const DEFAULT_TURN_TIMEOUT_MS = 300000;
export declare const DEFAULT_WORKSPACE_NAME = "\u5FAE\u4FE1\u673A\u5668\u4EBA";
export declare const DEFAULT_MEDIA_MAX_BYTES: number;
/** Settings for Tencent iLink-backed personal WeChat accounts. */
export interface Config {
    workspaceName?: string;
    workspaceId?: string;
    preventIdleSleep?: boolean;
    agentPreset?: string;
    thinkingText?: string;
    turnTimeoutMs?: number;
    mediaMaxBytes?: number;
    sendTyping?: boolean;
}
export declare const Config: z<Config>;
/**
 * Channel policy a chat command may persist into this plugin's settings section.
 * An explicit `undefined` clears the field so it falls back to the deployment's
 * own default, which a merge-only patch cannot express.
 */
export interface WeChatSettingsPatch {
    agentPreset?: string | undefined;
}
export interface WeChatRuntimeConfig {
    adminUsers: readonly string[];
    agentPreset?: string;
    thinkingText: string;
    turnTimeoutMs: number;
    mediaMaxBytes: number;
    sendTyping: boolean;
}
/** Resolve validated settings for an active account runtime. */
export declare function resolveRuntimeConfig(config: Config, ownerId?: string): WeChatRuntimeConfig;
