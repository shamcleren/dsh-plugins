import type { Config as PlainConfig } from './config.js';
import { type Volatile, type Context } from '@deepseek-ai/cordis';
export declare const Config: import("@deepseek-ai/schemastery").default<NoInfer<PlainConfig>, NoInfer<PlainConfig>, "volatile">;
export { DEFAULT_BASE_URL, DEFAULT_CDN_BASE_URL, DEFAULT_MEDIA_MAX_BYTES, DEFAULT_THINKING_TEXT, DEFAULT_TURN_TIMEOUT_MS, DEFAULT_WORKSPACE_NAME } from './config.js';
export type { Config as WeChatConfig } from './config.js';
export declare const name = "wechat";
export declare const inject: string[];
export declare const WECHAT_SETTINGS_NAMESPACE = "wechat";
/** Mount the personal WeChat account runtime and its settings namespace. */
export declare function apply(ctx: Context, config: PlainConfig | Volatile<PlainConfig>): void;
