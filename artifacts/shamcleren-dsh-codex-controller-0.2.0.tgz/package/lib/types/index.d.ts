/** Usage policy for the Codex app-server delegation bundle. */
import type { Context } from '@deepseek-ai/cordis';
export declare const name = "codex-controller-policy";
export declare const inject: string[];
/** Stable model-visible policy attached beside the composed delegation tool. */
export declare const POLICY = "Use codex_delegate only when the direct human asks to delegate work to Codex, compare Codex output, or operate an independent Codex worker. Give it a self-contained task and the exact expected outcome. The worker uses the current project directory but does not inherit this conversation. Its default permission mode rejects unattended escalation requests; report a resulting sandbox limitation instead of retrying with broader permissions. Use run_in_background only when the task can proceed independently and collect it through the job tools.";
/** Register the narrow policy for the externally composed Codex tool. */
export declare function apply(ctx: Context): void;
