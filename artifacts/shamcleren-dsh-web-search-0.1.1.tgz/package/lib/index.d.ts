import type { Context } from '@deepseek-ai/cordis';
export declare const name = "web-search";
export declare const inject: string[];
export declare const SEARCH_TOOL = "mcp__exa_free__web_search_exa";
export declare const FETCH_TOOL = "mcp__exa_free__web_fetch_exa";
export declare const EXA_URL = "https://mcp.exa.ai/mcp?tools=web_search_exa,web_fetch_exa";
export declare function apply(ctx: Context): Promise<void>;
