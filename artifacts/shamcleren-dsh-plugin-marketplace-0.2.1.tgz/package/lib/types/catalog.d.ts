/** Validation for untrusted Marketplace repository data. */
import type { MarketplaceCatalogView } from './types.ts';
/** Inputs needed to validate and project one Catalog. */
export interface MarketplaceCatalogParseRequest {
    readonly text: string;
    readonly repository: string;
    readonly ref: string;
    readonly dshVersion: string;
    readonly maxArtifactBytes: number;
}
/**
 * Parse and detach one Catalog while deriving Host-version compatibility.
 * @param request Untrusted text plus trusted source and Host limits.
 * @returns An immutable validated Catalog view.
 */
export declare function parseMarketplaceCatalog(request: MarketplaceCatalogParseRequest): MarketplaceCatalogView;
