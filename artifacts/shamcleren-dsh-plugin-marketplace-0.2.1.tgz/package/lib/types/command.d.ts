/** Contained subprocess execution for the Marketplace installer. */
/** Result bytes and diagnostics from one bounded child command. */
export interface CommandResult {
    readonly stdout: Buffer;
    readonly stderr: string;
}
/**
 * Run one non-interactive command with bounded output and no inherited stdin.
 * @param executable Absolute path or command name to spawn.
 * @param args Command arguments passed without shell interpretation.
 * @param environment Child-process environment.
 * @param maxBytes Maximum combined stdout and stderr bytes.
 * @returns Captured stdout and decoded stderr after a successful exit.
 */
export declare function runCommand(executable: string, args: readonly string[], environment: NodeJS.ProcessEnv, maxBytes: number): Promise<CommandResult>;
