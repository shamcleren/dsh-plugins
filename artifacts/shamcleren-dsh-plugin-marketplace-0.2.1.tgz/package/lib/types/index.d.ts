/** Trusted Marketplace plugin using the upstream Connection RPC extension. */
import type { Context } from '@deepseek-ai/cordis';
export { parseMarketplaceCatalog } from './catalog.ts';
export type Config = import('./service.ts').Config;
export declare const name = "trusted-marketplace";
export declare const Config: import("@deepseek-ai/schemastery").default<import("./service.ts").Config>;
export declare const inject: string[];
/** Mount the service and browser RPC with Host-enforced loopback authorization. */
export declare function apply(ctx: Context, config: import('./service.ts').Config): void;
