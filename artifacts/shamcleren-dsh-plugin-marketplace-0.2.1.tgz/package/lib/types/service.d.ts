/** Trusted single-source plugin Marketplace and profile mutation service. */
import { Service, type Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import type { MarketplaceCatalogView, MarketplaceConfigureRequest, MarketplaceMutationResult, MarketplaceOAuthRequest, MarketplaceOAuthStart, MarketplaceOAuthStatus, MarketplaceRepository, MarketplaceState } from './types.ts';
export type * from './types.ts';
export { parseMarketplaceCatalog } from './catalog.ts';
/** Stable Cordis service name. */
export declare const name = "trusted-marketplace";
/** Marketplace source and installer policy. */
export interface Config {
    /** Gongfeng API base URL. */
    baseUrl?: string;
    /** Single trusted namespace/repository source. */
    repository?: string;
    /** Branch, tag, or commit used for the catalog and artifacts. */
    ref?: string;
    /** Catalog path inside the repository. */
    catalogPath?: string;
    /** Credential reference containing the Gongfeng private token. */
    tokenRef?: string;
    /** Public Gongfeng OAuth application id used for PKCE. */
    oauthClientId?: string;
    /** Credential reference containing the OAuth access token. */
    oauthAccessTokenRef?: string;
    /** Credential reference containing the OAuth refresh token. */
    oauthRefreshTokenRef?: string;
    /** Epoch milliseconds when the current OAuth access token expires. */
    oauthExpiresAt?: number;
    /** Profile mutated by install, update, and removal operations. */
    profile?: string;
    /** Maximum decoded tarball bytes. */
    maxArtifactBytes?: number;
    /** Gongfeng binary path; defaults to DSH_GONGFENG_PATH or PATH lookup. */
    gongfengPath?: string;
}
/** Remote Marketplace service backed by Gongfeng and the canonical profile CLI. */
export declare class MarketplaceService extends Service {
    static inject: string[];
    static Config: z<Config>;
    private readonly entry;
    private current;
    private settingsScope;
    private mutationTail;
    private readonly oauth;
    constructor(ctx: Context, config?: Config);
    /**
     * Read safe source, credential, native bridge, and installed-package state.
     * @returns Browser-safe Marketplace state without credential values.
     */
    state(): Promise<MarketplaceState>;
    /**
     * Start a Gongfeng OAuth authorization using PKCE and the loopback callback.
     * @param request Public OAuth origin and application id.
     * @returns Authorization URL and polling identity.
     */
    beginOAuth(request: MarketplaceOAuthRequest): Promise<MarketplaceOAuthStart>;
    /**
     * Poll one Gongfeng OAuth authorization.
     * @param flowId Identity returned from {@link beginOAuth}.
     * @returns Current flow status without authorization secrets.
     */
    oauthStatus(flowId: string): Promise<MarketplaceOAuthStatus>;
    /**
     * List repositories visible to the authorized Gongfeng user.
     * @returns Repository identities and default branches for source selection.
     */
    repositories(): Promise<MarketplaceRepository[]>;
    /**
     * Persist the single Gongfeng source and an optional write-only token.
     * @param request Validated source fields and an optional replacement token.
     * @returns Updated browser-safe Marketplace state.
     */
    configure(request: MarketplaceConfigureRequest): Promise<MarketplaceState>;
    /**
     * Read the validated local Catalog cache, fetching it only on a cache miss.
     * @returns Compatible and incompatible entries from the current cached or remote Catalog.
     */
    catalog(): Promise<MarketplaceCatalogView>;
    /**
     * Fetch the configured Catalog from its trusted source and atomically refresh the local cache.
     * @returns Compatible and incompatible entries from the refreshed Catalog.
     */
    refreshCatalog(): Promise<MarketplaceCatalogView>;
    /**
     * Install or update one compatible Catalog package into the configured profile.
     * @param packageName Exact package identity present in the current Catalog.
     * @returns Mutation identity and restart requirement.
     */
    add(packageName: string): Promise<MarketplaceMutationResult>;
    /**
     * Remove one installed Catalog package from the configured profile.
     * @param packageName Exact package identity present in the current Catalog.
     * @returns Mutation identity and restart requirement.
     */
    deletePackage(packageName: string): Promise<MarketplaceMutationResult>;
    private repositoryFile;
    private catalogCacheRequest;
    private fetchCatalog;
    private oauthConfig;
    private cacheArtifact;
    private matchesArtifact;
    private verifyPackageManifest;
    private installed;
    private mutateProfile;
    private placeBeforeWebApp;
    private restoreFile;
    private serializeMutation;
}
export default MarketplaceService;
