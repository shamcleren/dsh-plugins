/** Validation for Gongfeng repository file metadata used by raw downloads. */
/** Validated commit identity and optional byte size for one raw file. */
export interface RepositoryFilePointer {
    readonly commitId: string;
    readonly size?: number;
}
/**
 * Parse one Gongfeng repository-file response with an explicit byte bound.
 * @param output Raw JSON response bytes.
 * @param maxBytes Maximum raw file bytes.
 * @returns A validated raw-file pointer.
 */
export declare function parseRepositoryFilePointer(output: Buffer, maxBytes: number): RepositoryFilePointer;
