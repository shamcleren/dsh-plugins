import type { Logger } from '@deepseek-ai/cordis';
import type { ApprovalOutcome } from '@deepseek-ai/dsh-user-approval';
import type { ConversationBindings } from './bindings.js';
import type { HostApiProxy, HostWorkspace } from './host-api.js';
import type { WeChatInboundMessage } from './inbound.js';
import type { WeChatRuntimeConfig } from './config.js';
interface WeChatReplies {
    sendText(userId: string, text: string, contextToken?: string): Promise<void>;
    typing(userId: string, status: 1 | 2, contextToken?: string): Promise<void>;
}
export interface RouterRuntimeContext {
    bindings: Pick<ConversationBindings, 'current' | 'set'>;
    defaultWorkspace: HostWorkspace;
}
export interface ChannelApprovalRequest {
    id: string;
    sessionId: string;
    toolName: string;
    callId?: string;
    reason?: string;
    signal?: AbortSignal;
    resolved: Promise<{
        outcome: ApprovalOutcome;
    }>;
}
export interface ChannelApprovalAnswer {
    outcome: 'allowed-once' | 'rejected';
    actorRef: string;
}
/** Route iLink messages through durable Host sessions and return turn output to WeChat. */
export declare class WeChatConversationRouter {
    private readonly api;
    private readonly replies;
    private readonly logger;
    private readonly config;
    private readonly runtime;
    private readonly adminUsers;
    private readonly listeners;
    private readonly admissionTails;
    private readonly tasks;
    private readonly activeTurns;
    private readonly pendingApprovals;
    private readonly pendingQuestions;
    private readonly turnAborts;
    private muxAbort;
    private muxTask;
    private stopping;
    constructor(api: HostApiProxy, replies: WeChatReplies, logger: Logger, config: WeChatRuntimeConfig, runtime: RouterRuntimeContext);
    start(): void;
    accept(message: WeChatInboundMessage): Promise<void>;
    private track;
    stop(): Promise<void>;
    /** Route questions and events only while this channel owns the active turn. */
    routesSession(sessionId: string): boolean;
    ownsSession(sessionId: string): boolean;
    requestApproval(request: ChannelApprovalRequest): Promise<ChannelApprovalAnswer | undefined>;
    private consumeMux;
    private consumeMuxFrame;
    private presentQuestion;
    private resolveQuestion;
    private route;
    private admit;
    private runManagementCommand;
    private status;
    private newSession;
    private workspace;
    private selectWorkspace;
    private workspaceIdForSession;
    private listWorkspaces;
    private model;
    private effort;
    private ensureSession;
    private createSession;
    private submitPrompt;
    private baselineSeqUnlessDuplicate;
    private turnOutcome;
    private observeTurn;
    private answerInteraction;
    private answerApproval;
    private answerQuestion;
    private parseQuestionAnswer;
    private numberedAnswer;
    private formatQuestions;
    private addListener;
    private removeListener;
    private cancelTurnOutcome;
    private withdrawApproval;
    private removeApproval;
}
export {};
