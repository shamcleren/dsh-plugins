import type { WeChatReceiverView } from './login.js';
import type { Logger } from '@deepseek-ai/cordis';
import type { Config } from './config.js';
import type { HostApiProxy } from './host-api.js';
import type { ChannelApprovalAnswer, ChannelApprovalRequest, RouterRuntimeContext } from './router.js';
import type { WeChatAccountStore } from './storage.js';
export interface WeChatRuntimeOptions {
    api: HostApiProxy;
    logger: Logger;
    store: WeChatAccountStore;
    prepareContext(config: Config): Promise<RouterRuntimeContext>;
}
/** Keep all selected iLink accounts synchronized with live settings. */
export declare class WeChatRuntimeController {
    private readonly options;
    private failed;
    private desired;
    private generation;
    private stopped;
    private active;
    private tail;
    constructor(options: WeChatRuntimeOptions);
    update(config: Config): void;
    /** QR completion waits until settings have produced an active account runtime. */
    ready(): Promise<void>;
    state(): WeChatReceiverView;
    routesSession(sessionId: string): boolean;
    ownsSession(sessionId: string): boolean;
    requestApproval(request: ChannelApprovalRequest): Promise<ChannelApprovalAnswer | undefined>;
    stop(): Promise<void>;
    private reconcile;
    private startActive;
    private stopActive;
}
