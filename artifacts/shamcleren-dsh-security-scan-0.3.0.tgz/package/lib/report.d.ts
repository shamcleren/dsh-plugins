import { z } from 'zod';
export declare const ReviewSchema: z.ZodObject<{
    findingId: z.ZodString;
    status: z.ZodEnum<{
        "needs-review": "needs-review";
        confirmed: "confirmed";
        dismissed: "dismissed";
    }>;
    severity: z.ZodEnum<{
        critical: "critical";
        high: "high";
        medium: "medium";
        low: "low";
        info: "info";
    }>;
    evidence: z.ZodString;
    recommendation: z.ZodString;
    verification: z.ZodString;
    reviewer: z.ZodString;
}, z.core.$strict>;
export declare const FindingSchema: z.ZodObject<{
    id: z.ZodString;
    fingerprint: z.ZodString;
    engine: z.ZodString;
    rule: z.ZodString;
    file: z.ZodString;
    line: z.ZodNumber;
    title: z.ZodString;
    cwe: z.ZodString;
    severity: z.ZodEnum<{
        critical: "critical";
        high: "high";
        medium: "medium";
        low: "low";
        info: "info";
    }>;
    status: z.ZodEnum<{
        "needs-review": "needs-review";
        confirmed: "confirmed";
        dismissed: "dismissed";
    }>;
    change: z.ZodEnum<{
        new: "new";
        existing: "existing";
        unknown: "unknown";
        "not-observed": "not-observed";
    }>;
    evidence: z.ZodString;
    recommendation: z.ZodString;
    verification: z.ZodString;
}, z.core.$strict>;
export declare const ReportSchema: z.ZodObject<{
    schemaVersion: z.ZodLiteral<1>;
    pluginVersion: z.ZodEnum<{
        "0.2.0": "0.2.0";
        "0.3.0": "0.3.0";
    }>;
    id: z.ZodString;
    createdAt: z.ZodString;
    source: z.ZodObject<{
        identity: z.ZodString;
        label: z.ZodString;
        revision: z.ZodEnum<{
            index: "index";
            commit: "commit";
            "working-tree": "working-tree";
        }>;
        scope: z.ZodEnum<{
            full: "full";
            diff: "diff";
            staged: "staged";
        }>;
        commit: z.ZodOptional<z.ZodString>;
        baseCommit: z.ZodOptional<z.ZodString>;
        digest: z.ZodString;
        files: z.ZodRecord<z.ZodString, z.ZodString>;
        changed: z.ZodArray<z.ZodString>;
        skipped: z.ZodNumber;
    }, z.core.$strict>;
    policy: z.ZodObject<{
        engine: z.ZodString;
        rulesDigest: z.ZodString;
        dependencies: z.ZodBoolean;
        secrets: z.ZodBoolean;
        view: z.ZodEnum<{
            new: "new";
            all: "all";
        }>;
        failOn: z.ZodEnum<{
            high: "high";
            medium: "medium";
            none: "none";
        }>;
    }, z.core.$strict>;
    engines: z.ZodArray<z.ZodObject<{
        name: z.ZodString;
        version: z.ZodString;
        status: z.ZodEnum<{
            partial: "partial";
            completed: "completed";
            skipped: "skipped";
            unavailable: "unavailable";
            failed: "failed";
        }>;
        detail: z.ZodString;
    }, z.core.$strict>>;
    coverage: z.ZodObject<{
        files: z.ZodNumber;
        scannedFiles: z.ZodNumber;
        omittedFindings: z.ZodNumber;
        detail: z.ZodString;
    }, z.core.$strict>;
    findings: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        fingerprint: z.ZodString;
        engine: z.ZodString;
        rule: z.ZodString;
        file: z.ZodString;
        line: z.ZodNumber;
        title: z.ZodString;
        cwe: z.ZodString;
        severity: z.ZodEnum<{
            critical: "critical";
            high: "high";
            medium: "medium";
            low: "low";
            info: "info";
        }>;
        status: z.ZodEnum<{
            "needs-review": "needs-review";
            confirmed: "confirmed";
            dismissed: "dismissed";
        }>;
        change: z.ZodEnum<{
            new: "new";
            existing: "existing";
            unknown: "unknown";
            "not-observed": "not-observed";
        }>;
        evidence: z.ZodString;
        recommendation: z.ZodString;
        verification: z.ZodString;
    }, z.core.$strict>>;
    baseline: z.ZodOptional<z.ZodObject<{
        id: z.ZodString;
        comparable: z.ZodBoolean;
        reason: z.ZodString;
        notObserved: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            fingerprint: z.ZodString;
            engine: z.ZodString;
            rule: z.ZodString;
            file: z.ZodString;
            line: z.ZodNumber;
            title: z.ZodString;
            cwe: z.ZodString;
            severity: z.ZodEnum<{
                critical: "critical";
                high: "high";
                medium: "medium";
                low: "low";
                info: "info";
            }>;
            status: z.ZodEnum<{
                "needs-review": "needs-review";
                confirmed: "confirmed";
                dismissed: "dismissed";
            }>;
            change: z.ZodEnum<{
                new: "new";
                existing: "existing";
                unknown: "unknown";
                "not-observed": "not-observed";
            }>;
            evidence: z.ZodString;
            recommendation: z.ZodString;
            verification: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strip>>;
    reviews: z.ZodArray<z.ZodObject<{
        findingId: z.ZodString;
        status: z.ZodEnum<{
            "needs-review": "needs-review";
            confirmed: "confirmed";
            dismissed: "dismissed";
        }>;
        severity: z.ZodEnum<{
            critical: "critical";
            high: "high";
            medium: "medium";
            low: "low";
            info: "info";
        }>;
        evidence: z.ZodString;
        recommendation: z.ZodString;
        verification: z.ZodString;
        reviewer: z.ZodString;
    }, z.core.$strict>>;
    notes: z.ZodArray<z.ZodString>;
    parentReport: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export type Report = z.infer<typeof ReportSchema>;
export type Finding = z.infer<typeof FindingSchema>;
export declare const AdditionalFindingSchema: z.ZodObject<{
    cwe: z.ZodString;
    line: z.ZodNumber;
    status: z.ZodEnum<{
        "needs-review": "needs-review";
        confirmed: "confirmed";
        dismissed: "dismissed";
    }>;
    severity: z.ZodEnum<{
        critical: "critical";
        high: "high";
        medium: "medium";
        low: "low";
        info: "info";
    }>;
    file: z.ZodString;
    title: z.ZodString;
    evidence: z.ZodString;
    recommendation: z.ZodString;
    verification: z.ZodString;
}, z.core.$strict>;
export type AdditionalFinding = z.infer<typeof AdditionalFindingSchema>;
export type Review = z.infer<typeof ReviewSchema>;
export declare const defaultReportsRoot: () => string;
export declare function readReport(file: string): Promise<Report>;
export declare function writeReport(root: string, value: Report): Promise<{
    json: string;
    html: string;
}>;
/** Reviews create another immutable JSON/HTML pair, preserving original scanner evidence. */
export declare function reviewReport(file: string, reviews: Review[], root: string, additional?: AdditionalFinding[]): Promise<{
    json: string;
    html: string;
}>;
export declare function exitCode(report: Report): number;
export declare function reportFile(root: string, id: string): string;
export declare function listReports(root: string, source?: string): Promise<Array<{
    id: string;
    createdAt: string;
    source: string;
    scope: string;
    findings: number;
    json: string;
    html: string;
}>>;
export declare function renderReport(input: Report): string;
export declare function sarif(report: Report): unknown;
