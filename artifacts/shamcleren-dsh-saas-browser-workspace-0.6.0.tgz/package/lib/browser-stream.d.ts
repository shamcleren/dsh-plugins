import type { ServerResponse } from 'node:http';
import type { CDPSession, Page } from 'playwright';
/** The active page produces frames only while the owner has a viewer. */
export declare class BrowserStream {
    private viewers;
    private source;
    private last;
    private interval;
    private timer;
    private next;
    private sentAt;
    private active;
    private transition;
    private disposed;
    private validSince;
    epoch: number;
    setPage(page?: Page, cdp?: CDPSession): void;
    invalidate(): void;
    connect(response: ServerResponse): void;
    private header;
    private write;
    private broadcast;
    private readonly frame;
    private reconcile;
    close(): Promise<void>;
}
