export declare const LIVE_PATH = "/api/saas-agent/live";
export declare const LIVE_TYPE = "application/octet-stream";
export declare const FRAME_HEADER_BYTES = 16;
export declare const MAX_FRAME_BYTES: number;
export declare const INITIAL_VIEWPORT: {
    width: number;
    height: number;
};
export interface LiveSurface {
    width: number;
    height: number;
    epoch: number;
}
export interface LiveFrame extends LiveSurface {
    jpeg: Uint8Array<ArrayBuffer>;
}
