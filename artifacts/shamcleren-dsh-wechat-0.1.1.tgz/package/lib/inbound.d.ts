import type { WeixinMessage } from './protocol.js';
export type PromptContentPart = {
    type: 'text';
    text: string;
} | {
    type: 'image';
    mediaType: 'image/png' | 'image/jpeg' | 'image/webp' | 'image/gif';
    data: string;
    name?: string;
};
export interface WeChatInboundMessage {
    accountId: string;
    messageId: string;
    userId: string;
    contextToken?: string;
    content: PromptContentPart[];
}
/** Normalize one iLink update into the Host prompt representation. */
export declare function normalizeInboundMessage(accountId: string, message: WeixinMessage, mediaMaxBytes: number): Promise<WeChatInboundMessage>;
/** Stable non-PII key for one account and WeChat peer. */
export declare function conversationKeyFor(message: WeChatInboundMessage): string;
/** Stable fallback Harness session id for one WeChat conversation. */
export declare function sessionIdFor(message: WeChatInboundMessage): string;
/** Durable Host prompt identity used for restart-safe deduplication. */
export declare function promptRpcIdFor(message: WeChatInboundMessage): string;
