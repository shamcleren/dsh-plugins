import type { CdnMedia } from './protocol.js';
/** Download and decrypt one iLink CDN object with AES-128-ECB. */
export declare function downloadMedia(media: CdnMedia, key: string | undefined, cdnBaseUrl: string, maxBytes: number): Promise<Buffer>;
