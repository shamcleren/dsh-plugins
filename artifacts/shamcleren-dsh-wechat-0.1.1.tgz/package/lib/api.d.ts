import type { GetUpdatesResponse, MessageItem, QrCodeResponse, QrStatusResponse } from './protocol.js';
/** Start one official WeChat QR authorization. */
export declare function requestQrCode(baseUrl: string, localTokens: readonly string[]): Promise<QrCodeResponse>;
/** Poll an authorization status. */
export declare function requestQrStatus(baseUrl: string, qrCode: string, verifyCode?: string, signal?: AbortSignal): Promise<QrStatusResponse>;
/** Wait for new messages using the persisted opaque cursor. */
export declare function getUpdates(request: {
    baseUrl: string;
    token: string;
    cursor: string;
    timeoutMs: number;
    signal: AbortSignal;
}): Promise<GetUpdatesResponse>;
/** Send one completed iLink message. */
export declare function sendMessage(request: {
    baseUrl: string;
    token: string;
    userId: string;
    contextToken?: string;
    item: MessageItem;
}): Promise<void>;
/** Resolve and publish a typing state for one peer. */
export declare function sendTyping(request: {
    baseUrl: string;
    token: string;
    userId: string;
    contextToken?: string;
    status: 1 | 2;
}): Promise<void>;
/** Notify iLink that one account monitor started or stopped. */
export declare function notifyLifecycle(account: {
    baseUrl: string;
    token: string;
}, state: 'start' | 'stop'): Promise<void>;
