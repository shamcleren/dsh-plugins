/** macOS idle-sleep assertion owned by one active Bot connection. */
/** Managed `/usr/bin/caffeinate` assertion; absent on non-macOS deployments. */
export declare class IdleSleepAssertion {
    private readonly child;
    private constructor();
    static start(enabled: boolean): Promise<IdleSleepAssertion | undefined>;
    stop(): Promise<void>;
}
