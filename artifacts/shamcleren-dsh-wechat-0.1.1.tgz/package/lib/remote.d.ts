import type { RemoteResult, TypertRemoteContribution } from '@deepseek-ai/dsh-typert-protocol';
import type { WeChatLoginView } from './login.js';
declare module '@deepseek-ai/dsh-typert-protocol' {
    interface WeChatLoginRemoteNamespace {
        state: () => Promise<RemoteResult<WeChatLoginView>>;
        begin: () => Promise<RemoteResult<WeChatLoginView>>;
        verify: (code: string) => Promise<RemoteResult<WeChatLoginView>>;
        cancel: () => Promise<RemoteResult<WeChatLoginView>>;
    }
    interface TypertRemoteMap {
        'wechatLogin/state': WeChatLoginRemoteNamespace['state'];
        'wechatLogin/begin': WeChatLoginRemoteNamespace['begin'];
        'wechatLogin/verify': WeChatLoginRemoteNamespace['verify'];
        'wechatLogin/cancel': WeChatLoginRemoteNamespace['cancel'];
    }
    interface TypertRemoteNamespaceMap {
        wechatLogin: WeChatLoginRemoteNamespace;
    }
}
/** Client contribution for the WeChat login Remote namespace. */
export declare const WECHAT_LOGIN_REMOTE: TypertRemoteContribution;
export default WECHAT_LOGIN_REMOTE;
