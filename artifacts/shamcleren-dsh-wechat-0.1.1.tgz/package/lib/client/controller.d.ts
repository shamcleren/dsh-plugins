import type { SettingsScope, SnapshotStore } from '@deepseek-ai/dsh-client-runtime/client';
import type { TypertRemoteNamespaceMap } from '@deepseek-ai/dsh-typert-protocol';
import type { Config } from '../config.js';
import type { WeChatLoginView } from '../login.js';
import type { FieldState, FormActions, FormState } from './form.js';
type LoginRemote = TypertRemoteNamespaceMap['wechatLogin'];
export interface WeChatCardState extends FormState {
    enabled: FieldState;
    accountIds: FieldState;
    allowedUsers: FieldState;
    adminUsers: FieldState;
    workspaceId: FieldState;
    preventIdleSleep: FieldState;
    agentPreset: FieldState;
    thinkingText: FieldState;
    turnTimeoutMs: FieldState;
    mediaMaxBytes: FieldState;
    sendTyping: FieldState;
    login: WeChatLoginView;
    qrDataUrl?: string;
    qrRenderError?: string;
    loginBusy: boolean;
    verificationCode: string;
}
export interface WeChatCardFace extends FormActions {
    hooks: {
        weChatCard: SnapshotStore<WeChatCardState>;
    };
    beginLogin(): void;
    cancelLogin(): void;
    refreshLogin(): void;
    setVerificationCode(code: string): void;
    submitVerification(): void;
}
/** Browser settings and QR login state for the WeChat card. */
export declare class WeChatCardController {
    private readonly remote;
    private readonly form;
    private readonly state;
    private login;
    private qrDataUrl;
    private qrRenderError;
    private qrSource;
    private loginBusy;
    private verificationCode;
    private pollTimer;
    private disposed;
    constructor(scope: SettingsScope<Config>, remote: LoginRemote);
    inject(): WeChatCardFace;
    dispose(): void;
    private refreshLogin;
    private mutate;
    private applyLogin;
    private renderQr;
    private schedulePoll;
    private snapshot;
    private publish;
}
export {};
