import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { WeChatCardFace } from './controller.js';
export type WeChatCardProps = PropsRuntime<'settings.plugin.item'> & PropsLocale<'settings.wechat'> & InjectFace<WeChatCardFace>;
/** Render personal WeChat settings in the generic plugin section. */
export declare function WeChatCard(props: WeChatCardProps): import("react").JSX.Element;
