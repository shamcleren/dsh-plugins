/** Inline styles keep the external client bundle independent of repository CSS tooling. */
export declare const styles: {
    card: {
        listStyle: "none";
        border: string;
        borderRadius: number;
        background: string;
        overflow: "hidden";
    };
    summary: {
        cursor: "pointer";
        padding: string;
        color: "var(--dsw-alias-label-primary)";
    };
    heading: {
        display: "flex";
        alignItems: "center";
        gap: number;
    };
    headText: {
        flex: number;
        display: "flex";
        flexDirection: "column";
        gap: number;
    };
    title: {
        fontSize: number;
        fontWeight: number;
        lineHeight: number;
    };
    description: {
        fontSize: number;
        lineHeight: number;
        color: "var(--dsw-alias-label-tertiary)";
    };
    badge: {
        borderRadius: number;
        padding: string;
        fontSize: number;
        lineHeight: string;
        background: string;
        color: "var(--dsw-alias-label-secondary)";
    };
    mutedBadge: {
        borderRadius: number;
        padding: string;
        fontSize: number;
        color: "var(--dsw-alias-label-tertiary)";
    };
    body: {
        borderTop: string;
        margin: string;
        paddingBottom: number;
    };
    field: {
        display: "flex";
        flexDirection: "column";
        gap: number;
        padding: string;
    };
    fieldHead: {
        display: "flex";
        alignItems: "center";
        gap: number;
    };
    label: {
        flex: number;
        fontSize: number;
        fontWeight: number;
        color: "var(--dsw-alias-label-primary)";
    };
    input: {
        height: number;
        padding: string;
        border: string;
        borderRadius: number;
        background: string;
        color: "var(--dsw-alias-label-primary)";
        fontSize: number;
    };
    hint: {
        margin: number;
        fontSize: number;
        lineHeight: number;
        color: "var(--dsw-alias-label-tertiary)";
    };
    error: {
        margin: number;
        fontSize: number;
        lineHeight: number;
        color: "var(--dsw-alias-label-error)";
    };
    reset: {
        border: number;
        background: string;
        color: "var(--dsw-alias-label-secondary)";
        cursor: "pointer";
    };
    toggle: {
        display: "inline-flex";
        alignItems: "center";
        gap: number;
        fontSize: number;
    };
    qr: {
        alignSelf: "center";
        borderRadius: number;
        background: string;
    };
    loginActions: {
        display: "flex";
        alignItems: "center";
        gap: number;
        flexWrap: "wrap";
    };
    footer: {
        display: "flex";
        justifyContent: "flex-end";
        alignItems: "center";
        gap: number;
        padding: string;
        borderTop: string;
    };
    button: {
        border: string;
        borderRadius: number;
        padding: string;
        background: string;
        color: "var(--dsw-alias-label-secondary)";
        cursor: "pointer";
    };
    save: {
        border: number;
        borderRadius: number;
        padding: string;
        background: string;
        color: "var(--dsw-alias-bg-layer-3)";
        cursor: "pointer";
    };
};
