import type { WeChatAccountCredentials } from './protocol.js';
/** Owner-only account, cursor, and reply-context persistence. */
export declare class WeChatAccountStore {
    private readonly filename;
    private readonly document;
    private writeTail;
    private constructor();
    static open(channelHome: string): Promise<WeChatAccountStore>;
    accounts(selected: readonly string[]): WeChatAccountCredentials[];
    tokens(): string[];
    cursor(accountId: string): string;
    contextToken(accountId: string, userId: string): string | undefined;
    saveAccount(account: WeChatAccountCredentials): Promise<void>;
    saveCursor(accountId: string, cursor: string): Promise<void>;
    saveContextToken(accountId: string, userId: string, token: string): Promise<void>;
    drain(): Promise<void>;
    private persist;
}
