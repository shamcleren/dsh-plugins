import type { Account, Change, Preview, Project, ProjectStatus, TaskPhase } from './types.js';
import type { CommandOptions, Execute, Result } from './process.js';
import type { EncryptionSupport } from './encryption.js';
export declare function allowedPath(path: string): boolean;
export declare function changesFromPorcelain(text: string): Change[];
export declare class Git {
    private readonly run;
    private readonly options;
    private readonly hooks;
    private readonly encryption?;
    constructor(run: Execute, options: () => CommandOptions, hooks: string, encryption?: EncryptionSupport | undefined);
    command(cwd: string, args: string[], extra?: CommandOptions): Promise<Result>;
    checked(cwd: string, args: string[], extra?: CommandOptions): Promise<string>;
    clone(parent: string, fullName: string, target: string, report?: (phase: TaskPhase, progress?: number) => void): Promise<void>;
    hasStaged(project: Project): Promise<boolean>;
    verify(project: Project): Promise<void>;
    status(project: Project): Promise<ProjectStatus>;
    fetch(project: Project): Promise<ProjectStatus>;
    pull(project: Project): Promise<ProjectStatus>;
    stage(project: Project, paths: string[], scratch: string): Promise<{
        tree: string;
        index: string;
        diff: string;
    }>;
    private assertWorkflow;
    /** Commit the reviewed immutable tree, preserving unrelated staged entries.
     * The native index lock blocks concurrent staging; update-ref compares HEAD.
     * No working-tree files or repository hooks are executed by this operation.
     */
    commit(project: Project, preview: Preview, message: string, account: Account, scratch: string, automatic?: boolean): Promise<ProjectStatus>;
    push(project: Project, head: string): Promise<ProjectStatus>;
}
