import type { HostApiProxy, HostWorkspace } from './host-api.js';
export interface ChannelCommandContext {
    readonly api: HostApiProxy;
    readonly rpcPrefix: string;
    readonly sessionPrefix: string;
    readonly localModelNotice: string;
    readonly defaultWorkspace: () => HostWorkspace;
    readonly getAgentPreset: () => string | undefined;
    readonly setAgentPreset: (next: string | undefined) => void;
    readonly writeAgentPreset: (next: string | undefined) => Promise<void>;
    readonly createSession: (sessionId: string, workspaceId: string) => Promise<string>;
    readonly bindSession: (conversationKey: string, sessionId: string, previousSessionId?: string) => Promise<void>;
}
export declare function selectWorkspace(workspaces: readonly HostWorkspace[], selector: string): HostWorkspace | undefined;
export declare function listHostWorkspaces(api: HostApiProxy, rpcPrefix: string): Promise<HostWorkspace[]>;
export declare function workspaceIdForSession(api: HostApiProxy, rpcPrefix: string, sessionId: string): Promise<string | undefined>;
export declare function statusCommand(ctx: ChannelCommandContext, sessionId: string): Promise<string>;
export declare function newSessionCommand(ctx: ChannelCommandContext, conversationKey: string, currentSessionId: string, replyMessage: string): Promise<string>;
/**
 * Move the channel's agent preset. The channel-local preset lives in its own
 * settings section and takes effect on a rebuilt session instead of leaking
 * into deployment-wide defaults.
 */
export declare function presetCommand(ctx: ChannelCommandContext, conversationKey: string, currentSessionId: string, args: readonly string[]): Promise<string>;
export declare function modelCommand(ctx: ChannelCommandContext, sessionId: string, args: readonly string[]): Promise<string>;
export declare function effortCommand(ctx: ChannelCommandContext, sessionId: string, args: readonly string[]): Promise<string>;
