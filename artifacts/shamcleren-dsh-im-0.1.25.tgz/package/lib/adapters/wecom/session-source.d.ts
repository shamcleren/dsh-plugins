import { type WeComInboundText } from './inbound.js';
import type { WeComGroupDirectory } from './group-directory.js';
/** Local aliases are scoped to the Bot and the exact group or sender. */
export declare class WeComSessionSources {
    private readonly root;
    constructor(root?: string);
    private groupPath;
    private speakerPath;
    nameSelf(message: WeComInboundText, name: string): Promise<void>;
    questionNames(message: WeComInboundText, directory?: WeComGroupDirectory): Promise<{
        speaker: string | undefined;
        group?: never;
    } | {
        speaker: string | undefined;
        group: string | undefined;
    }>;
    nameGroup(key: string, name: string): Promise<void>;
    rememberDirectoryName(key: string, name: string): Promise<void>;
}
