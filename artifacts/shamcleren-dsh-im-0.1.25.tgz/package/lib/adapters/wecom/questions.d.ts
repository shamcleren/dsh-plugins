/** Pure WeCom /answer prompt formatting and user answer parsing. */
import type { AskUserQuestionAnswerItem, AskUserQuestionItem } from './host-api.js';
export declare function currentQuestionIndex(questions: readonly AskUserQuestionItem[], answers: ReadonlyMap<string, AskUserQuestionAnswerItem>): number;
export declare function answerUsage(questions: readonly AskUserQuestionItem[]): string;
export declare function formatWeComQuestions(questions: readonly AskUserQuestionItem[]): string;
export declare function parseWeComQuestionAnswer(questions: readonly AskUserQuestionItem[], input: string): AskUserQuestionAnswerItem | string;
