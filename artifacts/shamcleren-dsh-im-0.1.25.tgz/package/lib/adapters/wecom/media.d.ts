import type { WeComInboundText } from './inbound.js';
import type { PromptContentPart } from './host-api.js';
export interface QuestionNames {
    speaker?: string | undefined;
    group?: string | undefined;
}
/** Bound untrusted downloads before decryption and preserve the SDK's per-file key behavior. */
export declare function inboundContent(message: WeComInboundText, maxBytes: number, signal: AbortSignal, names?: QuestionNames): Promise<PromptContentPart[]>;
