declare function listRecent(): Promise<unknown>;
/** Resolve display names only within the matching recent-chat type and identifier. */
export declare class WeComGroupDirectory {
    private readonly list;
    private cached;
    constructor(list?: typeof listRecent);
    name(chatId: string, type?: 'single' | 'group'): Promise<string | undefined>;
}
export {};
