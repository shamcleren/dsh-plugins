/** Outbound image, file, and video delivery helpers for WeCom turns. */
import type { Logger } from '@deepseek-ai/cordis';
import type { FileAttachmentRef, ImageAttachmentRef } from '@deepseek-ai/dsh-attachment';
import type { WsFrame } from '@wecom/aibot-node-sdk';
import { type OutboundFileBytes } from './files.js';
import type { TurnOutcome } from './reply.js';
/**
 * Images travel as their own WeCom messages after the text, so a turn that
 * produced only images still needs the text reply suppressed rather than filled
 * with the "no text" fallback.
 */
export declare const IMAGE_LEAD_IN = "\u56FE\u7247\u5982\u4E0B\uFF1A";
export declare function undeliveredImageNotice(failed: number, total: number): string;
/** A display name WeCom accepts, keeping the stored extension meaningful. */
export declare function imageFilename(ref: ImageAttachmentRef, index: number): string;
export interface WeComMediaDeliveryContext {
    readonly logger: Logger;
    readonly mediaMaxBytes: number;
    readonly isStopping: () => boolean;
    readonly signal: () => AbortSignal;
    readonly readImage?: (ref: ImageAttachmentRef) => Promise<Uint8Array>;
    readonly readFile?: (ref: FileAttachmentRef, signal: AbortSignal) => AsyncIterable<Uint8Array>;
    readonly readPresentedFile?: (sessionId: string, path: string, maxBytes: number, signal: AbortSignal) => Promise<OutboundFileBytes>;
    readonly uploadMedia: (fileBuffer: Buffer, options: {
        type: 'image' | 'file' | 'video';
        filename: string;
    }) => Promise<{
        media_id: string;
    }>;
    readonly sendMediaMessage: (targetId: string, mediaType: 'image' | 'file' | 'video', mediaId: string) => Promise<WsFrame>;
    readonly sendNotice: (targetId: string, text: string) => Promise<WsFrame>;
}
/**
 * Deliver durable images as their own WeCom messages. Each one is uploaded as
 * temporary media and pushed through the active-send channel, which stays
 * usable after the stream reply has already finished. Anything that cannot be
 * delivered is named in a single notice instead of disappearing.
 */
export declare function sendWeComImages(ctx: WeComMediaDeliveryContext, targetId: string, images: readonly ImageAttachmentRef[]): Promise<void>;
export declare function sendWeComFiles(ctx: WeComMediaDeliveryContext, sessionId: string, targetId: string, files: TurnOutcome['files']): Promise<void>;
