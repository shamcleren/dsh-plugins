/** Pure WeCom template-card builders, text width limits, and settled-card cache. */
import type { TemplateCard } from '@wecom/aibot-node-sdk';
import type { AskUserQuestionAnswerItem, AskUserQuestionItem } from './host-api.js';
export interface ResolvedTemplateCard extends TemplateCard {
    replace_text: string;
}
export interface SettledCard {
    userId: string;
    title: string;
}
/** Budget two units for non-ASCII characters to leave room on narrow clients. */
export declare function fitsQuestionCardLine(text: string, limit: number): boolean;
export declare function limitCardText(text: string, characters: number): string;
export declare function parseCardSelection(eventKey: string): {
    questionIndex: number;
    optionIndex: number;
} | undefined;
export declare function buildApprovalCard(taskId: string, toolName: string, reason?: string, command?: string): TemplateCard;
export declare function buildQuestionCard(taskId: string, questions: readonly AskUserQuestionItem[], answers: ReadonlyMap<string, AskUserQuestionAnswerItem>): TemplateCard | undefined;
export declare function buildResolvedCard(taskId: string, title: string, description?: string): ResolvedTemplateCard;
/** Bounded FIFO cache remembering recently settled cards so late button clicks update cleanly. */
export declare class SettledCardStore {
    private readonly items;
    remember(taskId: string, userId: string, title: string): void;
    take(taskId: string, userId: string): SettledCard | undefined;
    clear(): void;
}
