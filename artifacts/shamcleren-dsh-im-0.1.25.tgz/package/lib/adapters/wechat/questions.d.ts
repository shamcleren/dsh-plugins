/** Pure WeChat /answer prompt formatting and user answer parsing. */
import type { AskUserQuestionAnswerItem, AskUserQuestionItem } from './host-api.js';
export declare function parseWeChatQuestionAnswer(questions: readonly AskUserQuestionItem[], input: string): AskUserQuestionAnswerItem | string;
export declare function formatWeChatQuestions(questions: readonly AskUserQuestionItem[]): string;
