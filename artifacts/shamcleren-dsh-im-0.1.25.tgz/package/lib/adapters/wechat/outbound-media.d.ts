/** Outbound reply formatting and image/file/video delivery helpers for WeChat turns. */
import type { Logger } from '@deepseek-ai/cordis';
import type { FileAttachmentRef, ImageAttachmentRef } from '@deepseek-ai/dsh-attachment';
import { type OutboundFileBytes } from './files.js';
import { type TurnOutcome } from './reply.js';
/** Announce images that follow as their own messages, so no reply arrives empty. */
export declare const IMAGE_LEAD_IN = "\u56FE\u7247\u5982\u4E0B\uFF1A";
export declare function undeliveredImageNotice(failed: number, total: number): string;
export declare function finalWeChatReply(completed: TurnOutcome): string;
export interface WeChatMediaDeliveryContext {
    readonly logger: Logger;
    readonly mediaMaxBytes: number;
    readonly isStopping: () => boolean;
    readonly signal: () => AbortSignal;
    readonly readImage?: (ref: ImageAttachmentRef) => Promise<Uint8Array>;
    readonly readFile?: (ref: FileAttachmentRef, signal: AbortSignal) => AsyncIterable<Uint8Array>;
    readonly readPresentedFile?: (sessionId: string, path: string, maxBytes: number, signal: AbortSignal) => Promise<OutboundFileBytes>;
    readonly sendText: (userId: string, text: string, contextToken?: string) => Promise<void>;
    readonly sendImage: (userId: string, bytes: Buffer, contextToken?: string) => Promise<void>;
    readonly sendFile: (userId: string, bytes: Buffer, name: string, contextToken?: string) => Promise<void>;
    readonly sendVideo: (userId: string, bytes: Buffer, contextToken?: string) => Promise<void>;
}
/**
 * Upload each image and send it as its own iLink message. A failure names the
 * images that stayed behind rather than dropping them silently.
 */
export declare function sendWeChatImages(ctx: WeChatMediaDeliveryContext, target: {
    userId: string;
    contextToken?: string;
}, images: readonly ImageAttachmentRef[]): Promise<void>;
export declare function sendWeChatFiles(ctx: WeChatMediaDeliveryContext, target: {
    sessionId: string;
    userId: string;
    contextToken?: string;
}, files: TurnOutcome['files']): Promise<void>;
