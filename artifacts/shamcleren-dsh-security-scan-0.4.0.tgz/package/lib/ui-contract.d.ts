/** Browser-safe configuration and wire contracts. No filesystem or scanner imports. */
import { z } from 'zod';
export declare const SECURITY_CHANNEL = "/security-scan";
export declare const TaskConfigSchema: z.ZodObject<{
    name: z.ZodString;
    kind: z.ZodEnum<{
        local: "local";
        remote: "remote";
    }>;
    target: z.ZodString;
    ref: z.ZodDefault<z.ZodString>;
    scope: z.ZodEnum<{
        full: "full";
        diff: "diff";
        staged: "staged";
    }>;
    baseline: z.ZodEnum<{
        none: "none";
        git: "git";
        report: "report";
    }>;
    base: z.ZodDefault<z.ZodString>;
    baselineId: z.ZodDefault<z.ZodUnion<readonly [z.ZodLiteral<"">, z.ZodString]>>;
    engine: z.ZodEnum<{
        auto: "auto";
        inventory: "inventory";
    }>;
    dependencies: z.ZodDefault<z.ZodBoolean>;
    secrets: z.ZodDefault<z.ZodBoolean>;
    view: z.ZodDefault<z.ZodEnum<{
        new: "new";
        all: "all";
    }>>;
    autoScan: z.ZodDefault<z.ZodBoolean>;
    agent: z.ZodDefault<z.ZodObject<{
        enabled: z.ZodDefault<z.ZodBoolean>;
        provider: z.ZodDefault<z.ZodString>;
        model: z.ZodDefault<z.ZodString>;
        maxSteps: z.ZodDefault<z.ZodNumber>;
        maxMinutes: z.ZodDefault<z.ZodNumber>;
        maxTokens: z.ZodDefault<z.ZodNumber>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type TaskConfig = z.infer<typeof TaskConfigSchema>;
export declare const TaskSchema: z.ZodObject<{
    id: z.ZodString;
    revision: z.ZodNumber;
    updatedAt: z.ZodString;
    config: z.ZodObject<{
        name: z.ZodString;
        kind: z.ZodEnum<{
            local: "local";
            remote: "remote";
        }>;
        target: z.ZodString;
        ref: z.ZodDefault<z.ZodString>;
        scope: z.ZodEnum<{
            full: "full";
            diff: "diff";
            staged: "staged";
        }>;
        baseline: z.ZodEnum<{
            none: "none";
            git: "git";
            report: "report";
        }>;
        base: z.ZodDefault<z.ZodString>;
        baselineId: z.ZodDefault<z.ZodUnion<readonly [z.ZodLiteral<"">, z.ZodString]>>;
        engine: z.ZodEnum<{
            auto: "auto";
            inventory: "inventory";
        }>;
        dependencies: z.ZodDefault<z.ZodBoolean>;
        secrets: z.ZodDefault<z.ZodBoolean>;
        view: z.ZodDefault<z.ZodEnum<{
            new: "new";
            all: "all";
        }>>;
        autoScan: z.ZodDefault<z.ZodBoolean>;
        agent: z.ZodDefault<z.ZodObject<{
            enabled: z.ZodDefault<z.ZodBoolean>;
            provider: z.ZodDefault<z.ZodString>;
            model: z.ZodDefault<z.ZodString>;
            maxSteps: z.ZodDefault<z.ZodNumber>;
            maxMinutes: z.ZodDefault<z.ZodNumber>;
            maxTokens: z.ZodDefault<z.ZodNumber>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
}, z.core.$strict>;
export type Task = z.infer<typeof TaskSchema>;
export declare const RunSchema: z.ZodObject<{
    id: z.ZodString;
    taskId: z.ZodString;
    config: z.ZodObject<{
        name: z.ZodString;
        kind: z.ZodEnum<{
            local: "local";
            remote: "remote";
        }>;
        target: z.ZodString;
        ref: z.ZodDefault<z.ZodString>;
        scope: z.ZodEnum<{
            full: "full";
            diff: "diff";
            staged: "staged";
        }>;
        baseline: z.ZodEnum<{
            none: "none";
            git: "git";
            report: "report";
        }>;
        base: z.ZodDefault<z.ZodString>;
        baselineId: z.ZodDefault<z.ZodUnion<readonly [z.ZodLiteral<"">, z.ZodString]>>;
        engine: z.ZodEnum<{
            auto: "auto";
            inventory: "inventory";
        }>;
        dependencies: z.ZodDefault<z.ZodBoolean>;
        secrets: z.ZodDefault<z.ZodBoolean>;
        view: z.ZodDefault<z.ZodEnum<{
            new: "new";
            all: "all";
        }>>;
        autoScan: z.ZodDefault<z.ZodBoolean>;
        agent: z.ZodDefault<z.ZodObject<{
            enabled: z.ZodDefault<z.ZodBoolean>;
            provider: z.ZodDefault<z.ZodString>;
            model: z.ZodDefault<z.ZodString>;
            maxSteps: z.ZodDefault<z.ZodNumber>;
            maxMinutes: z.ZodDefault<z.ZodNumber>;
            maxTokens: z.ZodDefault<z.ZodNumber>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    status: z.ZodEnum<{
        cancelled: "cancelled";
        partial: "partial";
        failed: "failed";
        queued: "queued";
        running: "running";
        cancelling: "cancelling";
        succeeded: "succeeded";
        interrupted: "interrupted";
    }>;
    phase: z.ZodEnum<{
        finished: "finished";
        baseline: "baseline";
        agent: "agent";
        preparing: "preparing";
        scanning: "scanning";
        report: "report";
        queued: "queued";
    }>;
    trigger: z.ZodEnum<{
        manual: "manual";
        edit: "edit";
    }>;
    createdAt: z.ZodString;
    finishedAt: z.ZodOptional<z.ZodString>;
    reportId: z.ZodOptional<z.ZodString>;
    rulesReportId: z.ZodOptional<z.ZodString>;
    reportRoot: z.ZodOptional<z.ZodString>;
    error: z.ZodOptional<z.ZodString>;
    findings: z.ZodOptional<z.ZodNumber>;
    agent: z.ZodOptional<z.ZodObject<{
        status: z.ZodEnum<{
            completed: "completed";
            incomplete: "incomplete";
        }>;
        reason: z.ZodEnum<{
            completed: "completed";
            "step-limit": "step-limit";
            "time-limit": "time-limit";
            "context-limit": "context-limit";
            "model-unavailable": "model-unavailable";
            "model-failed": "model-failed";
            "invalid-response": "invalid-response";
            "evidence-unavailable": "evidence-unavailable";
            cancelled: "cancelled";
        }>;
        provider: z.ZodString;
        model: z.ZodString;
        steps: z.ZodNumber;
        areas: z.ZodArray<z.ZodEnum<{
            "entry-points": "entry-points";
            authentication: "authentication";
            authorization: "authorization";
            injection: "injection";
            "data-exposure": "data-exposure";
            "business-logic": "business-logic";
        }>>;
        files: z.ZodArray<z.ZodString>;
        reviewedFindings: z.ZodNumber;
        additionalFindings: z.ZodDefault<z.ZodNumber>;
        inputTokens: z.ZodNumber;
        outputTokens: z.ZodNumber;
        usageAvailable: z.ZodBoolean;
        events: z.ZodArray<z.ZodObject<{
            step: z.ZodNumber;
            kind: z.ZodEnum<{
                planning: "planning";
                listing: "listing";
                reading: "reading";
                reviewing: "reviewing";
                rejected: "rejected";
                finished: "finished";
            }>;
            files: z.ZodDefault<z.ZodArray<z.ZodString>>;
            count: z.ZodDefault<z.ZodNumber>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type Run = z.infer<typeof RunSchema>;
export declare const SettingsSchema: z.ZodObject<{
    semgrepPath: z.ZodString;
    gitleaksPath: z.ZodString;
    reportDirectory: z.ZodString;
    autoScan: z.ZodBoolean;
    hookTools: z.ZodArray<z.ZodString>;
}, z.core.$strict>;
export type ScanSettings = z.infer<typeof SettingsSchema>;
export declare const ReportItemSchema: z.ZodObject<{
    id: z.ZodString;
    createdAt: z.ZodString;
    source: z.ZodString;
    scope: z.ZodString;
    findings: z.ZodNumber;
    json: z.ZodString;
    html: z.ZodString;
}, z.core.$strip>;
export type ReportItem = z.infer<typeof ReportItemSchema>;
export declare const UiStateSchema: z.ZodObject<{
    tasks: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        revision: z.ZodNumber;
        updatedAt: z.ZodString;
        config: z.ZodObject<{
            name: z.ZodString;
            kind: z.ZodEnum<{
                local: "local";
                remote: "remote";
            }>;
            target: z.ZodString;
            ref: z.ZodDefault<z.ZodString>;
            scope: z.ZodEnum<{
                full: "full";
                diff: "diff";
                staged: "staged";
            }>;
            baseline: z.ZodEnum<{
                none: "none";
                git: "git";
                report: "report";
            }>;
            base: z.ZodDefault<z.ZodString>;
            baselineId: z.ZodDefault<z.ZodUnion<readonly [z.ZodLiteral<"">, z.ZodString]>>;
            engine: z.ZodEnum<{
                auto: "auto";
                inventory: "inventory";
            }>;
            dependencies: z.ZodDefault<z.ZodBoolean>;
            secrets: z.ZodDefault<z.ZodBoolean>;
            view: z.ZodDefault<z.ZodEnum<{
                new: "new";
                all: "all";
            }>>;
            autoScan: z.ZodDefault<z.ZodBoolean>;
            agent: z.ZodDefault<z.ZodObject<{
                enabled: z.ZodDefault<z.ZodBoolean>;
                provider: z.ZodDefault<z.ZodString>;
                model: z.ZodDefault<z.ZodString>;
                maxSteps: z.ZodDefault<z.ZodNumber>;
                maxMinutes: z.ZodDefault<z.ZodNumber>;
                maxTokens: z.ZodDefault<z.ZodNumber>;
            }, z.core.$strict>>;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    runs: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        taskId: z.ZodString;
        config: z.ZodObject<{
            name: z.ZodString;
            kind: z.ZodEnum<{
                local: "local";
                remote: "remote";
            }>;
            target: z.ZodString;
            ref: z.ZodDefault<z.ZodString>;
            scope: z.ZodEnum<{
                full: "full";
                diff: "diff";
                staged: "staged";
            }>;
            baseline: z.ZodEnum<{
                none: "none";
                git: "git";
                report: "report";
            }>;
            base: z.ZodDefault<z.ZodString>;
            baselineId: z.ZodDefault<z.ZodUnion<readonly [z.ZodLiteral<"">, z.ZodString]>>;
            engine: z.ZodEnum<{
                auto: "auto";
                inventory: "inventory";
            }>;
            dependencies: z.ZodDefault<z.ZodBoolean>;
            secrets: z.ZodDefault<z.ZodBoolean>;
            view: z.ZodDefault<z.ZodEnum<{
                new: "new";
                all: "all";
            }>>;
            autoScan: z.ZodDefault<z.ZodBoolean>;
            agent: z.ZodDefault<z.ZodObject<{
                enabled: z.ZodDefault<z.ZodBoolean>;
                provider: z.ZodDefault<z.ZodString>;
                model: z.ZodDefault<z.ZodString>;
                maxSteps: z.ZodDefault<z.ZodNumber>;
                maxMinutes: z.ZodDefault<z.ZodNumber>;
                maxTokens: z.ZodDefault<z.ZodNumber>;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        status: z.ZodEnum<{
            cancelled: "cancelled";
            partial: "partial";
            failed: "failed";
            queued: "queued";
            running: "running";
            cancelling: "cancelling";
            succeeded: "succeeded";
            interrupted: "interrupted";
        }>;
        phase: z.ZodEnum<{
            finished: "finished";
            baseline: "baseline";
            agent: "agent";
            preparing: "preparing";
            scanning: "scanning";
            report: "report";
            queued: "queued";
        }>;
        trigger: z.ZodEnum<{
            manual: "manual";
            edit: "edit";
        }>;
        createdAt: z.ZodString;
        finishedAt: z.ZodOptional<z.ZodString>;
        reportId: z.ZodOptional<z.ZodString>;
        rulesReportId: z.ZodOptional<z.ZodString>;
        reportRoot: z.ZodOptional<z.ZodString>;
        error: z.ZodOptional<z.ZodString>;
        findings: z.ZodOptional<z.ZodNumber>;
        agent: z.ZodOptional<z.ZodObject<{
            status: z.ZodEnum<{
                completed: "completed";
                incomplete: "incomplete";
            }>;
            reason: z.ZodEnum<{
                completed: "completed";
                "step-limit": "step-limit";
                "time-limit": "time-limit";
                "context-limit": "context-limit";
                "model-unavailable": "model-unavailable";
                "model-failed": "model-failed";
                "invalid-response": "invalid-response";
                "evidence-unavailable": "evidence-unavailable";
                cancelled: "cancelled";
            }>;
            provider: z.ZodString;
            model: z.ZodString;
            steps: z.ZodNumber;
            areas: z.ZodArray<z.ZodEnum<{
                "entry-points": "entry-points";
                authentication: "authentication";
                authorization: "authorization";
                injection: "injection";
                "data-exposure": "data-exposure";
                "business-logic": "business-logic";
            }>>;
            files: z.ZodArray<z.ZodString>;
            reviewedFindings: z.ZodNumber;
            additionalFindings: z.ZodDefault<z.ZodNumber>;
            inputTokens: z.ZodNumber;
            outputTokens: z.ZodNumber;
            usageAvailable: z.ZodBoolean;
            events: z.ZodArray<z.ZodObject<{
                step: z.ZodNumber;
                kind: z.ZodEnum<{
                    planning: "planning";
                    listing: "listing";
                    reading: "reading";
                    reviewing: "reviewing";
                    rejected: "rejected";
                    finished: "finished";
                }>;
                files: z.ZodDefault<z.ZodArray<z.ZodString>>;
                count: z.ZodDefault<z.ZodNumber>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    reports: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        createdAt: z.ZodString;
        source: z.ZodString;
        scope: z.ZodString;
        findings: z.ZodNumber;
        json: z.ZodString;
        html: z.ZodString;
    }, z.core.$strip>>;
    settings: z.ZodObject<{
        semgrepPath: z.ZodString;
        gitleaksPath: z.ZodString;
        reportDirectory: z.ZodString;
        autoScan: z.ZodBoolean;
        hookTools: z.ZodArray<z.ZodString>;
    }, z.core.$strict>;
    settingsWritable: z.ZodBoolean;
    agentDefault: z.ZodDefault<z.ZodNullable<z.ZodObject<{
        provider: z.ZodString;
        model: z.ZodString;
    }, z.core.$strip>>>;
    warnings: z.ZodDefault<z.ZodArray<z.ZodString>>;
}, z.core.$strip>;
export type UiState = z.infer<typeof UiStateSchema>;
export declare const HookRequestSchema: z.ZodObject<{
    taskId: z.ZodString;
    revision: z.ZodNumber;
    event: z.ZodEnum<{
        "pre-commit": "pre-commit";
        "pre-push": "pre-push";
    }>;
    action: z.ZodEnum<{
        install: "install";
        remove: "remove";
    }>;
    enforce: z.ZodBoolean;
    base: z.ZodDefault<z.ZodString>;
    confirm: z.ZodLiteral<true>;
}, z.core.$strict>;
export type HookRequest = z.infer<typeof HookRequestSchema>;
export type UiRemote = {
    state(): Promise<UiState>;
    save(config: TaskConfig, id?: string, revision?: number): Promise<Task>;
    remove(id: string, revision: number): Promise<void>;
    run(id: string, revision: number): Promise<Run>;
    cancel(id: string): Promise<void>;
    settings(value: ScanSettings): Promise<void>;
    hook(request: HookRequest): Promise<void>;
    report(id: string, format: 'html' | 'json'): Promise<string>;
};
export declare const newTask: () => TaskConfig;
