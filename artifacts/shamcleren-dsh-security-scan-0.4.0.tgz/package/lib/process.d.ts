/** Own the scanner process, bounded output, deadline, and descendant cleanup. */
export declare function runScanner(binary: string, args: string[], cwd: string, signal: AbortSignal, environment?: Record<string, string>): Promise<{
    code: number;
    stdout: string;
}>;
