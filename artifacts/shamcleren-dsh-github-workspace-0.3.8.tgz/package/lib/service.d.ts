import { type Execute } from './process.js';
export interface WorkspaceRegistry {
    create(path: string, title?: string): Promise<{
        id: string;
    }>;
}
export declare class WorkspaceService {
    private readonly registry;
    private readonly scratch;
    private readonly run;
    private readonly https;
    private readonly lifetime;
    private readonly scopes;
    private readonly jobs;
    private readonly previews;
    private readonly tasks;
    private readonly nextSync;
    private timer;
    private readonly github;
    private readonly git;
    private readonly httpsGit;
    private readonly tools;
    private readonly encryption;
    private readonly encryptionFile;
    private root;
    private init;
    private stopped;
    private constructor();
    static create(home: string, registry: WorkspaceRegistry, run?: Execute): Promise<WorkspaceService>;
    stop(): Promise<void>;
    /** The human-operated page is the only mutation entry point. */
    request(method: string, payload: unknown, signal?: AbortSignal): Promise<unknown>;
    private startOpen;
    private gitFor;
    private projectCommand;
    private path;
    private encryptionFor;
    private readEncryption;
    private readStore;
    private ensureRoot;
    private writeProjects;
    private exclusive;
    private state;
    private project;
    private openProject;
    private withScratch;
    private preview;
    private localIdentity;
    private commit;
    private activity;
    private configureEncryption;
    private configureSync;
    private startSync;
    /** The timer only dispatches opted-in projects; failed policies stay paused. */
    tick(now?: number): Promise<void>;
    private schedule;
}
