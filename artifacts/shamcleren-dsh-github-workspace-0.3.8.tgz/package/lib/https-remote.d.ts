import { z } from 'zod';
declare const settingsSchema: z.ZodObject<{
    host: z.ZodString;
    credentialHelper: z.ZodEnum<{
        osxkeychain: "osxkeychain";
        libsecret: "libsecret";
        manager: "manager";
    }>;
}, z.core.$strict>;
export type HttpsSettings = z.infer<typeof settingsSchema>;
export declare const httpsRepository: z.ZodPipe<z.ZodString, z.ZodTransform<string, string>>;
export declare function httpsRepositoryPath(url: string): string;
export declare function readHttpsSettings(file: string): Promise<HttpsSettings | undefined>;
export {};
