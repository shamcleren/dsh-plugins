import type { Logger } from '@deepseek-ai/cordis';
import type { ApprovalOutcome } from '@deepseek-ai/dsh-user-approval';
import type { Config, WeComCredentials } from './config.js';
import type { WeComBotClient } from './account.js';
import type { HostApiProxy } from './host-api.js';
import type { WeComReplyClient } from './router.js';
import type { ChannelApprovalRequest, RouterRuntimeContext } from './router.js';
type RuntimeClient = WeComBotClient & WeComReplyClient;
export interface WeComRuntimeOptions {
    api: HostApiProxy;
    logger: Logger;
    resolveCredentials(config: Config): Promise<WeComCredentials | undefined>;
    createClient(credentials: WeComCredentials): RuntimeClient;
    prepareContext(config: Config): Promise<RouterRuntimeContext>;
}
/** Keep the Bot connection synchronized with live settings and credentials. */
export declare class WeComRuntimeController {
    private readonly options;
    private desired;
    private generation;
    private stopped;
    private active;
    private tail;
    constructor(options: WeComRuntimeOptions);
    update(config: Config): void;
    /** Delegate non-WeCom agents while answering approvals for the active channel router. */
    requestApproval(request: ChannelApprovalRequest, next: () => Promise<ApprovalOutcome>): Promise<ApprovalOutcome>;
    stop(): Promise<void>;
    private reconcile;
    private startActive;
    private stopActive;
}
export {};
