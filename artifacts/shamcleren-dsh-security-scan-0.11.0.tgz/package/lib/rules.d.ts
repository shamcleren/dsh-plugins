export declare const RULES: Record<string, {
    title: string;
    cwe: string;
}>;
