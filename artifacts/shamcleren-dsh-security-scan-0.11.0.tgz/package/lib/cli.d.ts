#!/usr/bin/env node
export declare function main(argv: string[]): Promise<number>;
