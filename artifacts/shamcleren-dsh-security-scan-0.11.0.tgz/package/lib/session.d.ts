import type { SessionController } from '@deepseek-ai/dsh-api-session-controller';
import type { WorkspaceRegistry } from '@deepseek-ai/dsh-workspace';
import { type SessionStore } from '@deepseek-ai/dsh-session';
import type { Run } from './ui-contract.js';
export interface ScanSession {
    start(run: Run, cwd: string): Promise<string>;
    publish(id: string, run: Run): Promise<void>;
}
/** Host-owned ordinary sessions; progress is plugin context, never a second model prompt. */
export declare function scanSession(api: Pick<SessionController, 'create' | 'rename'>, workspaces: Pick<WorkspaceRegistry, 'create'>, sessions: SessionStore): ScanSession;
