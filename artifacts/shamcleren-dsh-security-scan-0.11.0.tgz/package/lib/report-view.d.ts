import type { Report } from './report.js';
export declare function linkText(value: string): string;
export { groupFindings } from './report-groups.js';
export declare function renderReportView(report: Report): string;
