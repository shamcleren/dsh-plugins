import { type UiRemote } from '../ui-contract.js';
import { type LocaleKey } from './locales.js';
type Translate = (key: LocaleKey) => string;
export declare function Workbench({ remote, t, close, openSession, requestedReport }: {
    remote: UiRemote;
    requestedReport?: string;
    t: Translate;
    close(): void;
    openSession(id: string): void;
}): import("react").JSX.Element;
export {};
