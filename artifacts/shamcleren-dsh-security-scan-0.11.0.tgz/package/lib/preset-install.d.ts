import type { PresetRoot } from '@deepseek-ai/dsh-agent-presets';
export declare const SECURITY_PRESET = "dsh-security-audit";
export declare function ensureSecurityPreset(roots: readonly PresetRoot[]): Promise<void>;
