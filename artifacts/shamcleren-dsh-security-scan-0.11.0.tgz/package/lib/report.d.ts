import { type EvidenceArchive } from './report-evidence.js';
import { z } from 'zod';
import { type AgentAudit } from './agent-contract.js';
export declare const ReviewSchema: z.ZodObject<{
    findingId: z.ZodString;
    status: z.ZodEnum<{
        confirmed: "confirmed";
        dismissed: "dismissed";
        "needs-review": "needs-review";
    }>;
    severity: z.ZodEnum<{
        critical: "critical";
        high: "high";
        info: "info";
        low: "low";
        medium: "medium";
    }>;
    evidence: z.ZodString;
    recommendation: z.ZodString;
    verification: z.ZodString;
    reviewer: z.ZodString;
    citations: z.ZodOptional<z.ZodArray<z.ZodObject<{
        file: z.ZodString;
        start: z.ZodNumber;
        end: z.ZodNumber;
    }, z.core.$strict>>>;
}, z.core.$strict>;
export declare const FindingSchema: z.ZodObject<{
    id: z.ZodString;
    fingerprint: z.ZodString;
    engine: z.ZodString;
    rule: z.ZodString;
    file: z.ZodString;
    line: z.ZodNumber;
    title: z.ZodString;
    cwe: z.ZodString;
    severity: z.ZodEnum<{
        critical: "critical";
        high: "high";
        info: "info";
        low: "low";
        medium: "medium";
    }>;
    status: z.ZodEnum<{
        confirmed: "confirmed";
        dismissed: "dismissed";
        "needs-review": "needs-review";
    }>;
    change: z.ZodEnum<{
        existing: "existing";
        new: "new";
        "not-observed": "not-observed";
        unknown: "unknown";
    }>;
    evidence: z.ZodString;
    recommendation: z.ZodString;
    verification: z.ZodString;
    citations: z.ZodOptional<z.ZodArray<z.ZodObject<{
        file: z.ZodString;
        start: z.ZodNumber;
        end: z.ZodNumber;
    }, z.core.$strict>>>;
    dependency: z.ZodOptional<z.ZodObject<{
        name: z.ZodString;
        version: z.ZodString;
        ecosystem: z.ZodString;
        advisoryId: z.ZodString;
        aliases: z.ZodArray<z.ZodString>;
        fixedVersions: z.ZodArray<z.ZodString>;
        summary: z.ZodString;
        references: z.ZodArray<z.ZodString>;
        metadataAvailable: z.ZodBoolean;
        locationExact: z.ZodBoolean;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const PLUGIN_VERSION: '0.11.0';
export declare const ReportSchema: z.ZodObject<{
    schemaVersion: z.ZodLiteral<1>;
    pluginVersion: z.ZodEnum<{
        "0.10.0": "0.10.0";
        "0.10.1": "0.10.1";
        "0.10.2": "0.10.2";
        "0.10.3": "0.10.3";
        "0.11.0": "0.11.0";
        "0.2.0": "0.2.0";
        "0.3.0": "0.3.0";
        "0.4.0": "0.4.0";
        "0.5.0": "0.5.0";
        "0.6.0": "0.6.0";
        "0.7.0": "0.7.0";
        "0.8.0": "0.8.0";
        "0.8.1": "0.8.1";
        "0.8.2": "0.8.2";
        "0.9.0": "0.9.0";
        "0.9.1": "0.9.1";
    }>;
    id: z.ZodString;
    createdAt: z.ZodString;
    source: z.ZodObject<{
        identity: z.ZodString;
        label: z.ZodString;
        revision: z.ZodEnum<{
            commit: "commit";
            index: "index";
            "working-tree": "working-tree";
        }>;
        scope: z.ZodEnum<{
            diff: "diff";
            full: "full";
            staged: "staged";
        }>;
        commit: z.ZodOptional<z.ZodString>;
        baseCommit: z.ZodOptional<z.ZodString>;
        digest: z.ZodString;
        files: z.ZodRecord<z.ZodString, z.ZodString>;
        changed: z.ZodArray<z.ZodString>;
        skipped: z.ZodNumber;
    }, z.core.$strict>;
    policy: z.ZodObject<{
        engine: z.ZodString;
        rulesDigest: z.ZodString;
        dependencies: z.ZodBoolean;
        secrets: z.ZodBoolean;
        view: z.ZodEnum<{
            all: "all";
            new: "new";
        }>;
        failOn: z.ZodEnum<{
            high: "high";
            medium: "medium";
            none: "none";
        }>;
    }, z.core.$strict>;
    engines: z.ZodArray<z.ZodObject<{
        name: z.ZodString;
        version: z.ZodString;
        status: z.ZodEnum<{
            completed: "completed";
            failed: "failed";
            partial: "partial";
            skipped: "skipped";
            unavailable: "unavailable";
        }>;
        detail: z.ZodString;
    }, z.core.$strict>>;
    coverage: z.ZodObject<{
        files: z.ZodNumber;
        scannedFiles: z.ZodNumber;
        omittedFindings: z.ZodNumber;
        detail: z.ZodString;
    }, z.core.$strict>;
    findings: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        fingerprint: z.ZodString;
        engine: z.ZodString;
        rule: z.ZodString;
        file: z.ZodString;
        line: z.ZodNumber;
        title: z.ZodString;
        cwe: z.ZodString;
        severity: z.ZodEnum<{
            critical: "critical";
            high: "high";
            info: "info";
            low: "low";
            medium: "medium";
        }>;
        status: z.ZodEnum<{
            confirmed: "confirmed";
            dismissed: "dismissed";
            "needs-review": "needs-review";
        }>;
        change: z.ZodEnum<{
            existing: "existing";
            new: "new";
            "not-observed": "not-observed";
            unknown: "unknown";
        }>;
        evidence: z.ZodString;
        recommendation: z.ZodString;
        verification: z.ZodString;
        citations: z.ZodOptional<z.ZodArray<z.ZodObject<{
            file: z.ZodString;
            start: z.ZodNumber;
            end: z.ZodNumber;
        }, z.core.$strict>>>;
        dependency: z.ZodOptional<z.ZodObject<{
            name: z.ZodString;
            version: z.ZodString;
            ecosystem: z.ZodString;
            advisoryId: z.ZodString;
            aliases: z.ZodArray<z.ZodString>;
            fixedVersions: z.ZodArray<z.ZodString>;
            summary: z.ZodString;
            references: z.ZodArray<z.ZodString>;
            metadataAvailable: z.ZodBoolean;
            locationExact: z.ZodBoolean;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    baseline: z.ZodOptional<z.ZodObject<{
        id: z.ZodString;
        comparable: z.ZodBoolean;
        reason: z.ZodString;
        notObserved: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            fingerprint: z.ZodString;
            engine: z.ZodString;
            rule: z.ZodString;
            file: z.ZodString;
            line: z.ZodNumber;
            title: z.ZodString;
            cwe: z.ZodString;
            severity: z.ZodEnum<{
                critical: "critical";
                high: "high";
                info: "info";
                low: "low";
                medium: "medium";
            }>;
            status: z.ZodEnum<{
                confirmed: "confirmed";
                dismissed: "dismissed";
                "needs-review": "needs-review";
            }>;
            change: z.ZodEnum<{
                existing: "existing";
                new: "new";
                "not-observed": "not-observed";
                unknown: "unknown";
            }>;
            evidence: z.ZodString;
            recommendation: z.ZodString;
            verification: z.ZodString;
            citations: z.ZodOptional<z.ZodArray<z.ZodObject<{
                file: z.ZodString;
                start: z.ZodNumber;
                end: z.ZodNumber;
            }, z.core.$strict>>>;
            dependency: z.ZodOptional<z.ZodObject<{
                name: z.ZodString;
                version: z.ZodString;
                ecosystem: z.ZodString;
                advisoryId: z.ZodString;
                aliases: z.ZodArray<z.ZodString>;
                fixedVersions: z.ZodArray<z.ZodString>;
                summary: z.ZodString;
                references: z.ZodArray<z.ZodString>;
                metadataAvailable: z.ZodBoolean;
                locationExact: z.ZodBoolean;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
    }, z.core.$strip>>;
    evidenceArchive: z.ZodOptional<z.ZodObject<{
        snippets: z.ZodArray<z.ZodObject<{
            file: z.ZodString;
            start: z.ZodNumber;
            lines: z.ZodArray<z.ZodString>;
            sourceHash: z.ZodString;
            redacted: z.ZodBoolean;
        }, z.core.$strict>>;
        omitted: z.ZodNumber;
    }, z.core.$strict>>;
    reviews: z.ZodArray<z.ZodObject<{
        findingId: z.ZodString;
        status: z.ZodEnum<{
            confirmed: "confirmed";
            dismissed: "dismissed";
            "needs-review": "needs-review";
        }>;
        severity: z.ZodEnum<{
            critical: "critical";
            high: "high";
            info: "info";
            low: "low";
            medium: "medium";
        }>;
        evidence: z.ZodString;
        recommendation: z.ZodString;
        verification: z.ZodString;
        reviewer: z.ZodString;
        citations: z.ZodOptional<z.ZodArray<z.ZodObject<{
            file: z.ZodString;
            start: z.ZodNumber;
            end: z.ZodNumber;
        }, z.core.$strict>>>;
    }, z.core.$strict>>;
    notes: z.ZodArray<z.ZodString>;
    parentReport: z.ZodOptional<z.ZodString>;
    agent: z.ZodOptional<z.ZodObject<{
        status: z.ZodEnum<{
            completed: "completed";
            incomplete: "incomplete";
        }>;
        reason: z.ZodEnum<{
            cancelled: "cancelled";
            completed: "completed";
            "context-limit": "context-limit";
            "evidence-unavailable": "evidence-unavailable";
            "invalid-response": "invalid-response";
            "model-failed": "model-failed";
            "model-unavailable": "model-unavailable";
            "output-limit": "output-limit";
            "preset-unavailable": "preset-unavailable";
            "step-limit": "step-limit";
            "time-limit": "time-limit";
        }>;
        preset: z.ZodOptional<z.ZodString>;
        nativeEnd: z.ZodOptional<z.ZodString>;
        nativeErrorCode: z.ZodOptional<z.ZodString>;
        provider: z.ZodString;
        model: z.ZodString;
        steps: z.ZodNumber;
        areas: z.ZodArray<z.ZodEnum<{
            authentication: "authentication";
            authorization: "authorization";
            "business-logic": "business-logic";
            "data-exposure": "data-exposure";
            "entry-points": "entry-points";
            injection: "injection";
        }>>;
        files: z.ZodArray<z.ZodString>;
        eligibleCandidates: z.ZodOptional<z.ZodNumber>;
        excludedCandidates: z.ZodOptional<z.ZodNumber>;
        reviewedFindings: z.ZodNumber;
        additionalFindings: z.ZodDefault<z.ZodNumber>;
        inputTokens: z.ZodNumber;
        outputTokens: z.ZodNumber;
        usageAvailable: z.ZodBoolean;
        events: z.ZodArray<z.ZodObject<{
            step: z.ZodNumber;
            kind: z.ZodEnum<{
                finished: "finished";
                listing: "listing";
                planning: "planning";
                reading: "reading";
                rejected: "rejected";
                reviewing: "reviewing";
            }>;
            files: z.ZodDefault<z.ZodArray<z.ZodString>>;
            code: z.ZodOptional<z.ZodString>;
            count: z.ZodDefault<z.ZodNumber>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type Report = z.infer<typeof ReportSchema>;
export type Finding = z.infer<typeof FindingSchema>;
export declare const AdditionalFindingSchema: z.ZodObject<{
    file: z.ZodString;
    line: z.ZodNumber;
    title: z.ZodString;
    cwe: z.ZodString;
    severity: z.ZodEnum<{
        critical: "critical";
        high: "high";
        info: "info";
        low: "low";
        medium: "medium";
    }>;
    status: z.ZodEnum<{
        confirmed: "confirmed";
        dismissed: "dismissed";
        "needs-review": "needs-review";
    }>;
    citations: z.ZodOptional<z.ZodArray<z.ZodObject<{
        file: z.ZodString;
        start: z.ZodNumber;
        end: z.ZodNumber;
    }, z.core.$strict>>>;
    evidence: z.ZodString;
    recommendation: z.ZodString;
    verification: z.ZodString;
}, z.core.$strict>;
export type AdditionalFinding = z.infer<typeof AdditionalFindingSchema>;
export type Review = z.infer<typeof ReviewSchema>;
export declare const defaultReportsRoot: () => string;
export declare function readReport(file: string): Promise<Report>;
export declare function writeReport(root: string, value: Report, draft?: boolean): Promise<{
    json: string;
    html: string;
}>;
/** Reviews create another immutable JSON/HTML pair, preserving original scanner evidence. */
export declare function reviewReport(file: string, reviews: Review[], root: string, additional?: AdditionalFinding[], agent?: AgentAudit, retainParent?: boolean, reportId?: `${string}-${string}-${string}-${string}-${string}`, evidenceArchive?: EvidenceArchive): Promise<{
    json: string;
    html: string;
}>;
export declare function exitCode(report: Report): number;
export declare function reportFile(root: string, id: string): string;
/** Quarantine an owned report pair before changing history; never recursively remove user content. */
export declare function stageReportDeletion(file: string, id: string): Promise<{
    restore(): Promise<void>;
    finish(): Promise<void>;
}>;
export declare function listReports(root: string, source?: string): Promise<Array<{
    id: string;
    createdAt: string;
    source: string;
    scope: string;
    findings: number;
    json: string;
    html: string;
}>>;
export declare function renderReport(input: Report): string;
export declare function sarif(report: Report): unknown;
