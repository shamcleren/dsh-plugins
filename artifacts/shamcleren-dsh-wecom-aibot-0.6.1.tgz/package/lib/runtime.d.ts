import type { Logger } from '@deepseek-ai/cordis';
import type { Config, WeComCredentials } from './config.js';
import type { WeComBotClient } from './account.js';
import type { HostApiProxy } from './host-api.js';
import type { WeComReplyClient } from './router.js';
import type { ChannelApprovalAnswer, ChannelApprovalRequest, RouterRuntimeContext } from './router.js';
type RuntimeClient = WeComBotClient & WeComReplyClient;
export interface WeComRuntimeOptions {
    api: HostApiProxy;
    logger: Logger;
    resolveCredentials(config: Config): Promise<WeComCredentials | undefined>;
    createClient(credentials: WeComCredentials): RuntimeClient;
    prepareContext(config: Config): Promise<RouterRuntimeContext>;
}
/** Keep the Bot connection synchronized with live settings and credentials. */
export declare class WeComRuntimeController {
    private readonly options;
    private desired;
    private generation;
    private stopped;
    private active;
    private tail;
    /** Keeps one unconfigured streak from repeating the same warning on every reconcile. */
    private warnedUnconfigured;
    constructor(options: WeComRuntimeOptions);
    update(config: Config): void;
    /** Whether the live channel router owns this exact session turn. */
    routesSession(sessionId: string): boolean;
    ownsSession(sessionId: string): boolean;
    /** Present an approval through the live channel router. */
    requestApproval(request: ChannelApprovalRequest): Promise<ChannelApprovalAnswer | undefined>;
    stop(): Promise<void>;
    private reconcile;
    private startActive;
    private stopActive;
}
export {};
