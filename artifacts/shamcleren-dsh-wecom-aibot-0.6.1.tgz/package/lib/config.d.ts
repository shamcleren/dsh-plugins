import z from '@deepseek-ai/schemastery';
export declare const DEFAULT_BOT_ID_ENV = "WECOM_BOT_ID";
export declare const DEFAULT_SECRET_ENV = "WECOM_BOT_SECRET";
export declare const DEFAULT_THINKING_TEXT = "\u6B63\u5728\u601D\u8003\u2026";
export declare const DEFAULT_TURN_TIMEOUT_MS = 300000;
export declare const DEFAULT_WORKSPACE_NAME = "\u4F01\u4E1A\u5FAE\u4FE1\u673A\u5668\u4EBA";
/** Settings used to authenticate and run one WeCom Bot account. */
export interface Config {
    /** Credential reference containing the WeCom Bot ID. */
    botIdEnv?: string;
    /** Credential reference containing the WeCom Bot secret. */
    secretEnv?: string;
    /** Optional userid allowlist; empty accepts every user visible to the Bot. */
    allowedUsers?: string[];
    /** Userids allowed to run channel management commands. */
    adminUsers?: string[];
    /** Title of the managed fallback Workspace created when workspaceId is omitted. */
    workspaceName?: string;
    /** Existing Harness Workspace selected as the default for new conversations. */
    workspaceId?: string;
    /** Prevent idle system sleep while the Bot runtime is active on macOS. */
    preventIdleSleep?: boolean;
    /** Optional Harness agent preset selected for new WeCom conversations. */
    agentPreset?: string;
    /** Initial stream content sent while the Harness turn starts. */
    thinkingText?: string;
    /** Maximum time to observe one admitted Harness turn. */
    turnTimeoutMs?: number;
}
export declare const Config: z<Config>;
/** Resolved credentials detached from the ambient environment. */
export interface WeComCredentials {
    botId: string;
    secret: string;
}
/** Runtime policy resolved from the validated plugin configuration. */
export interface WeComRuntimeConfig {
    allowedUsers: readonly string[];
    adminUsers: readonly string[];
    agentPreset?: string;
    thinkingText: string;
    turnTimeoutMs: number;
}
/** Resolve optional channel policy defaults for direct programmatic callers. */
export declare function resolveRuntimeConfig(config: Config): WeComRuntimeConfig;
