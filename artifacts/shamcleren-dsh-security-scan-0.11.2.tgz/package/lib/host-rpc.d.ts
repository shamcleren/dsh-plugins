import type { Context } from '@deepseek-ai/cordis';
type RpcHandler = (method: string, payload: unknown, signal: AbortSignal) => unknown | Promise<unknown>;
/** Register a custom Connection-compatible channel on the consuming plugin fiber. */
export declare function registerHostRpc(ctx: Context, channel: string, handler: RpcHandler): void;
export {};
