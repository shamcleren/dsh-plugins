/** Workspace bootstrap for channel-owned Sessions. */
import type { HostApiProxy, HostWorkspace } from './host-api.js';
/** Create or reuse the plugin's private directory-backed Workspace. */
export declare function ensureWeComWorkspace(api: HostApiProxy, dshHome: string, title: string, botId?: string): Promise<string>;
/** Resolve an explicit default Workspace or create the channel fallback. */
export declare function resolveDefaultWorkspace(api: HostApiProxy, dshHome: string, workspaceId: string | undefined, fallbackTitle: string, botId?: string): Promise<HostWorkspace>;
