# `@shamcleren/dsh-wecom-aibot`

WeCom AI Bot channel package for DeepSeek Harness.

## Current milestone

The package connects the official WeCom AI Bot WebSocket SDK to the same-process DeepSeek Harness Host API. It accepts text callbacks, creates or resumes a deterministic durable session for each direct or group conversation, suppresses a previously admitted `msgid`, and submits each message with atomic `continue` admission. An idle session starts a new turn; a running session receives the message as next-step guidance while the new callback is acknowledged immediately. The original WeCom stream remains the main output and accumulates assistant text across model steps.

The bundle row always mounts so the plugin remains visible and configurable. Its `enabled` setting defaults to `false`; the SDK connects only after the setting is enabled and both credential references resolve. The same package exports a dynamic `./client` bundle that contributes its card to the generic Plugins settings section, so `dsh plugin --profile web add <package>` installs the Host channel and its UI together without modifying or rebuilding DeepSeek Harness. Environment variables remain a fallback for headless deployments. The implementation has automated Host/SDK boundary coverage; a live Bot credential smoke remains before a production rollout. See the repository-level [design document](../../docs/plugins/wecom-aibot.md).

## Configuration

| Field | Default | Meaning |
| --- | --- | --- |
| `enabled` | `false` | Whether the SDK connects and accepts messages. |
| `botIdEnv` | `WECOM_BOT_ID` | Credential reference containing the WeCom Bot ID. |
| `secretEnv` | `WECOM_BOT_SECRET` | Credential reference containing the WeCom Bot secret. |
| `allowedUsers` | `[]` | WeCom userids allowed to send messages. An empty list accepts every user visible to the Bot. |
| `adminUsers` | `[]` | WeCom userids allowed to run `/help`, `/status`, `/new`, `/workspace`, `/model`, `/effort`, and `/compact`. |
| `workspaceId` | omitted | Existing Harness Workspace used by new conversations. The settings card lists the current Workspace registry. |
| `workspaceName` | `企业微信机器人` | Title of the managed fallback Workspace created when `workspaceId` is omitted. |
| `preventIdleSleep` | `false` | On macOS, run a managed idle-sleep assertion while the Bot is active. |
| `agentPreset` | omitted | Harness agent preset used when a new WeCom session is created. |
| `thinkingText` | `正在思考…` | Initial content of the WeCom stream while the Harness turn starts. |
| `turnTimeoutMs` | `300000` | Maximum observation time for one admitted Harness turn. |

The reference fields are names, not credential literals. The plugin resolves the Host credentials service first and then the process environment. Enabling the plugin without both values keeps it disconnected and emits a warning; writing either referenced credential or changing settings reconciles the connection without remounting the plugin.

The UI stores Bot ID and Secret through the Host credentials API, never in the settings document or a browser response. Ordinary settings and credentials remain under the Harness home and survive application restarts.

Conversation and prompt identities are SHA-256-derived from the Bot and WeCom identifiers. Raw userids and chatids do not appear in Harness session ids. Deduplication reads the Host's durable `rpcId` admission receipt, so replaying a callback after restart does not enqueue another turn.

When a deterministic conversation id already belongs to a pre-Workspace release with another cwd, the plugin creates a new channel-Workspace Session, persists that active binding, and retains the legacy Session unchanged.

The plugin persists only the hashed conversation key and current opaque Session id under the Harness home. The Session's Workspace account preserves each conversation's selection across restarts. `/workspace` reports the current and default Workspaces; `/workspace <name-or-id>` creates a Session in the selected Workspace and switches the conversation only after creation succeeds, while `/workspace reset` returns it to the configured default. Duplicate display names require the stable Workspace id. `/new` creates the replacement Session in the conversation's current Workspace. Prior Sessions remain available in the App. Management commands are an explicit allowlist and never expand when Harness adds another command.

When an active WeCom turn requests approval, the plugin registers an independent `wecom` answerer and sends an Allow/Reject template card as a standalone message alongside the existing reply stream. The card presents the tool, the approval reason within WeCom's template limits, and the command recovered from the request's exact `callId`; command visibility follows the same Session ownership as the surrounding WeCom conversation and is not additionally redacted. Clicking a button first replaces the actions with a disabled result selector and an `已允许` or `已拒绝` title, then resumes or rejects the Host operation. `/approve` and `/reject` remain text fallbacks. Web and WeCom can present the same approval concurrently; the first valid answer wins. A later click on a card already settled through Web updates that card to the resolved state. Only the user who started the WeCom turn can decide, and the durable audit receives a hashed actor reference rather than the raw userid. Approval prompts, resolution notices, continuation acknowledgements, and final replies use the SDK's ordered reliable path; high-frequency text updates use its best-effort non-blocking path.

An interaction ends the current stream before waiting for the human. A text `/approve`, `/reject`, or final `/answer` receives a completed acknowledgement on that reply callback. After either a text answer or template-card click, the plugin buffers the remaining turn and sends its final text as a new proactive Markdown message. Earlier assistant text remains in the earlier bubble instead of being copied or reordered around the user's decision.

`ask_user_question` requests from an active WeCom turn are shown in the same stream with numbered questions, choices, descriptions, supporting detail, and multi-select guidance. A single-select question with one to six options also gets native buttons; the first option is primary and the remaining options are secondary. Consecutive eligible questions reuse and update the same card, and the final choice replaces its buttons with a resolved notice. Multi-select, free-text, and larger option sets retain the text flow. For one question, reply `/answer <choice number, label, or custom text>`. For a batch, reply to each item with `/answer <question number or id> <answer>`; comma-separated values select multiple choices. Answers retain the caller's stable question ids and are submitted as one Host response after the batch is complete. Web and WeCom share the Host request, so the first valid response wins.

## Known limitations

- User messages are limited to text; template-card click events are handled. Images, voice, files, video, mixed messages, and proactive sends are deferred.
- Group management commands accept the callback's leading Bot mention, such as `@dsh /help`; non-command text remains unchanged when sent to the Harness.
- Unloading the plugin stops its listeners, timers, and reply observation. A turn already admitted through the Host API remains Host-owned and may finish without sending another WeCom frame.

## Development

```sh
pnpm install
pnpm test
pnpm typecheck
pnpm build
```
