/** Inline styles keep the external client bundle independent of repository CSS tooling. */
/** Mirrors the official plugin-manager config pages: flat sections, no wrapping card. */
export declare const styles: {
    form: {
        display: "flex";
        flexDirection: "column";
        minWidth: number;
    };
    section: {
        minWidth: number;
        padding: string;
    };
    sectionHeading: {
        margin: number;
        fontSize: number;
        fontWeight: number;
        lineHeight: number;
        color: "var(--dsw-alias-label-primary)";
    };
    field: {
        display: "flex";
        flexDirection: "column";
        gap: number;
        padding: string;
    };
    fieldHead: {
        display: "flex";
        alignItems: "center";
        gap: number;
    };
    label: {
        flex: number;
        fontSize: number;
        fontWeight: number;
        color: "var(--dsw-alias-label-primary)";
    };
    input: {
        height: number;
        padding: string;
        border: string;
        borderRadius: number;
        background: string;
        color: "var(--dsw-alias-label-primary)";
        fontSize: number;
    };
    hint: {
        margin: number;
        fontSize: number;
        lineHeight: number;
        color: "var(--dsw-alias-label-tertiary)";
    };
    error: {
        margin: number;
        fontSize: number;
        lineHeight: number;
        color: "var(--dsw-alias-label-error)";
    };
    toggle: {
        display: "inline-flex";
        alignItems: "center";
        gap: number;
        fontSize: number;
    };
    grid: {
        display: "flex";
        flexWrap: "wrap";
        gap: number;
        marginTop: number;
    };
    thumb: {
        display: "flex";
        flexDirection: "column";
        alignItems: "center";
        gap: number;
        width: number;
        padding: number;
        border: string;
        borderRadius: number;
        background: string;
        cursor: "pointer";
        boxSizing: "border-box";
    };
    thumbSelected: {
        borderColor: "var(--dsw-alias-accent)";
    };
    thumbName: {
        fontSize: number;
        lineHeight: number;
        color: "var(--dsw-alias-label-secondary)";
        maxWidth: string;
        overflow: "hidden";
        textOverflow: "ellipsis";
        whiteSpace: "nowrap";
    };
};
