/**
 * desktop-pet — a desktop floating pet for DeepSeek Harness, reusing the
 * Codex/OpenAI pet asset packs. Host-only: reduces session events into a pet
 * state and drives a bundled native Helper (transparent always-on-top window)
 * over a stdio JSON protocol. No DSH app-shell changes are required.
 */
import z from '@deepseek-ai/schemastery';
import { type Volatile, type Context } from '@deepseek-ai/cordis';
import { PetSettings } from './config.js';
type PlainConfig = import('./config.js').Config;
type LiveConfig = Omit<PlainConfig, keyof PetSettings> & {
    [K in keyof PetSettings]: Volatile<PetSettings[K]>;
};
export declare const Config: z<Schemastery.ObjectS<NoInfer<{
    enabled: z<any, any, "volatile">;
    petId: z<any, any, "volatile">;
    petSize: z<any, any, "volatile">;
}>>, Schemastery.ObjectT<NoInfer<{
    enabled: z<any, any, "volatile">;
    petId: z<any, any, "volatile">;
    petSize: z<any, any, "volatile">;
}>>, "plain">;
export type { Config as DesktopPetConfig } from './config.js';
export { PetSettings } from './config.js';
export { MessageKind } from './protocol.js';
export { HelperProcess } from './helper-process.js';
export { PetStatusTracker } from './status.js';
export declare const name = "desktop-pet";
export declare function apply(ctx: Context, config: PlainConfig | LiveConfig): void;
