export declare const CODEX_BIN: string;
export declare function codexArgv(): string[];
