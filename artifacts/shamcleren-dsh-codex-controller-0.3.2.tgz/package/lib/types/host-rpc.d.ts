import type { Context } from '@deepseek-ai/cordis';
type RpcHandler = (method: string, payload: unknown, signal: AbortSignal) => unknown | Promise<unknown>;
export declare function registerHostRpc(ctx: Context, channel: string, handler: RpcHandler): void;
export {};
