/** Host-owned bridge shared with a later Codex preset mount. */
import type { CodexBridge } from './bridge.js';
interface Bound {
    bridge: CodexBridge;
    cwdFor(sessionId: string): string | undefined;
}
export declare function bindBridge(bound: Bound): () => void;
export declare function currentBridge(): Bound | undefined;
export {};
