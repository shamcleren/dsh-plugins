import { type QuotaUsage } from './activity.js';
import type { CodexSpawn } from './connection.js';
export declare const ACCOUNT_QUOTA_REFRESH_MS = 60000;
interface RefreshOptions {
    intervalMs?: number;
    readLive(signal: AbortSignal): Promise<Record<string, unknown> | undefined>;
    spawn(): CodexSpawn | undefined;
}
export declare class AccountQuota {
    private readonly root;
    private current;
    private epoch;
    private inflight;
    private writes;
    private child;
    private cancel;
    private options;
    constructor(root: string);
    snapshot(): QuotaUsage | undefined;
    observe(params: Record<string, unknown>): void;
    start(options: RefreshOptions): () => void;
    kick(): void;
    stop(): void;
    refresh(): Promise<void>;
    private refreshOwned;
    private remember;
    private path;
    private load;
    private persist;
    private probe;
}
export {};
