/** Shared Codex session surface. The journal is the live working set; notices remain the durable transcript. */
import type { QuotaUsage } from './activity.js';
import type { SessionRecord } from './journal.js';
export declare const CODEX_CHANNEL = "/codex-controller";
export interface CreateRequest {
    cwd?: string;
}
export interface StateRequest {
    sessionId: string;
}
export interface CodexState {
    present: boolean;
    record: SessionRecord;
    quota?: QuotaUsage;
}
export declare function isSessionId(value: unknown): value is string;
