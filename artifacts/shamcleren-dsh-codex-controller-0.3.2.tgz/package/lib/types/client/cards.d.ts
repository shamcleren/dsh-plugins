/** Visible Codex activity cards. Unknown events degrade to a labeled card instead of disappearing. */
import type { CodexActivity, CodexQuestion } from '../activity.js';
import type { LocaleKey } from './locales.js';
export interface CodexCard {
    id: string;
    kind: LocaleKey;
    title: string;
    detail: string;
    status: string;
}
export declare function activityCard(activity: CodexActivity): CodexCard;
export declare function questionCard(question: CodexQuestion): CodexCard;
