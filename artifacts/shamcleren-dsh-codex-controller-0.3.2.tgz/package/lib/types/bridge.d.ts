/** One DSH session, one Codex thread, and the visible activity that belongs to that pair. */
import { type StreamChunk } from '@deepseek-ai/dsh-llm';
import type { ImageAttachmentRef } from '@deepseek-ai/dsh-attachment';
import type { Agent } from '@deepseek-ai/dsh-agent';
import type { Session } from '@deepseek-ai/dsh-session';
import { type DshOutcome } from './approval-map.js';
import { type CodexSpawn, type CodexTurnInput, type TurnEnd } from './connection.js';
import { type SessionRecord } from './journal.js';
export interface BridgeHost {
    root: string;
    spawn: CodexSpawn;
    session(id: string): Session | undefined;
    agent(id: string): Agent | undefined;
    approve(agent: Agent, toolName: string, reason: string, signal: AbortSignal): Promise<DshOutcome>;
    saveImage(data: Uint8Array, name: string): Promise<ImageAttachmentRef>;
    imageInput(attachment: ImageAttachmentRef, signal: AbortSignal): Promise<CodexTurnInput>;
    noteQuota?(params: Record<string, unknown>): void;
    graceMs?: number;
}
interface TurnRequest {
    sessionId: string;
    cwd: string;
    text: string;
    images?: readonly ImageAttachmentRef[];
    model?: string;
    effort?: string;
    signal: AbortSignal;
    onChunk(chunk: StreamChunk): void;
}
/** Serializes turns and publishes Codex activity without synthesizing DSH tool calls. */
export declare class CodexBridge {
    private readonly host;
    private readonly connections;
    private readonly opening;
    private readonly queues;
    private readonly writes;
    private readonly turnWaiters;
    private readonly signals;
    private readonly lifetime;
    private readonly active;
    constructor(host: BridgeHost);
    run(request: TurnRequest): Promise<TurnEnd>;
    waitForTurn(sessionId: string, signal: AbortSignal): Promise<TurnEnd>;
    snapshot(sessionId: string): Promise<SessionRecord>;
    sampleRateLimits(signal: AbortSignal): Promise<Record<string, unknown> | undefined>;
    remember(sessionId: string): Promise<void>;
    release(sessionId: string): Promise<void>;
    close(): Promise<void>;
    private runOwned;
    private connection;
    private turnInput;
    private open;
    private notification;
    private serverRequest;
    private delta;
    private projectGeneratedImage;
    private waitForImages;
    private finishStream;
    private notice;
    private settle;
    private update;
}
export type { TurnEnd };
