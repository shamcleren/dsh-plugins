/** Codex is a model route. Its tools stay inside Codex and never become DSH tool calls. */
import { LlmAdapter, type GenerateOptions, type LlmModelInfo, type LlmProviderInfo, type LlmResolvedModelInfo, type StreamChunk } from '@deepseek-ai/dsh-llm';
import type { CodexBridge } from './bridge.js';
import { type CodexModel } from './models.js';
export declare const CODEX_PROVIDER = "codex";
export declare const NATIVE_MODEL = "native";
export declare class CodexAdapter extends LlmAdapter {
    private readonly bridge;
    private readonly cwdFor;
    private readonly catalog;
    constructor(bridge: CodexBridge, cwdFor: (sessionId: string) => string | undefined, catalog?: () => Promise<readonly CodexModel[]>);
    providerInfo(provider: string): LlmProviderInfo;
    listModels(provider: string): Promise<readonly LlmModelInfo[]>;
    resolveModel(provider: string, model: string): Promise<LlmResolvedModelInfo>;
    stream(options: GenerateOptions): AsyncIterable<StreamChunk>;
    private models;
}
