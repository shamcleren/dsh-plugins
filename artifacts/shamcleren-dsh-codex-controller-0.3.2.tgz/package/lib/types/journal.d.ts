import type { CodexActivity, ContextUsage, QuotaUsage } from './activity.js';
export interface SessionRecord {
    version: 1;
    sessionId: string;
    threadId?: string;
    model?: string;
    effort?: string;
    status: 'idle' | 'running' | 'failed';
    usage?: ContextUsage;
    /** Leftover field. Account quota is one process-wide snapshot, not per session. */
    quota?: QuotaUsage;
    activities: CodexActivity[];
    error?: string;
}
export declare function recordPath(root: string, sessionId: string): string | undefined;
export declare function readRecord(root: string, sessionId: string): Promise<SessionRecord | undefined>;
export declare function writeRecord(root: string, record: SessionRecord): Promise<void>;
export declare function emptyRecord(sessionId: string): SessionRecord;
export declare function upsertActivity(record: SessionRecord, activity: CodexActivity): SessionRecord;
