/** Explicit Codex delegation creates a visible session instead of a hidden one-shot. */
import type { Context } from '@deepseek-ai/cordis';
import type { CodexBridge } from './bridge.js';
export declare function registerDelegate(ctx: Context, bridge: CodexBridge, origin: () => string, sessionController: () => Context['sessionController'] | undefined): void;
