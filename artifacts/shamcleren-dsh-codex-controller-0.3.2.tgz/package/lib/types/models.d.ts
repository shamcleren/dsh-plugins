import type { CodexSpawn } from './connection.js';
export interface CodexModel {
    id: string;
    name: string;
    description?: string;
    efforts: ReadonlyArray<{
        id: string;
        description?: string;
    }>;
    defaultEffort?: string;
    inputModalities?: ReadonlyArray<'text' | 'image'>;
}
export declare function listCodexModels(spawn: CodexSpawn, now?: number): Promise<readonly CodexModel[]>;
export declare function modelById(models: readonly CodexModel[], id: string): CodexModel | undefined;
export declare function parseModels(value: unknown): CodexModel[];
