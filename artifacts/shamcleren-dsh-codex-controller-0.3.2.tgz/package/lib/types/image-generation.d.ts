export interface GeneratedImage {
    id: string;
    bytes: Uint8Array;
    name: string;
}
export declare function generatedImage(params: Record<string, unknown>): GeneratedImage | undefined;
