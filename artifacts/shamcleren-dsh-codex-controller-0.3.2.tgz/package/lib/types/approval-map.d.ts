/** Map DSH's one-shot approval vocabulary onto Codex app-server decisions. */
export type CodexDecision = 'accept' | 'decline' | 'cancel';
export type DshOutcome = 'allowed-once' | 'rejected' | 'cancelled' | 'unavailable';
/** Never synthesize a session-wide or policy-amendment grant. */
export declare function decisionFor(outcome: DshOutcome): CodexDecision;
export declare const ELICITATION = "mcpServer/elicitation/request";
/**
 * Requests DSH can answer with accept, decline, or cancel alone. An elicitation that
 * asks for field values needs text DSH approval cannot carry, so it is not one of them.
 */
export declare function nativelyApprovable(method: string, params: Record<string, unknown>): boolean;
export declare function approvalPrompt(method: string, params: Record<string, unknown>): {
    toolName: string;
    reason: string;
};
export declare function approvalResponse(method: string, params: Record<string, unknown>, decision: CodexDecision): Record<string, unknown>;
