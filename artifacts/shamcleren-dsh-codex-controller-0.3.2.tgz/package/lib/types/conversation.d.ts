/** Codex notices become conversation nodes. Chat still renders the same events as context messages. */
import type { ConversationNodeDefinition, ConversationViewDefinition, ConversationViewNode } from '@deepseek-ai/dsh-client-ui-conversation/client';
export declare const CODEX_TARGET = "codex";
export interface CodexNoticeNode {
    summary: string;
    text: string;
    seq: number;
}
type NoticeEvent = {
    type?: string;
    seq?: number;
    data?: {
        source?: {
            kind?: string;
            plugin?: string;
            summary?: string;
        };
        content?: Array<{
            type?: string;
            text?: string;
        }>;
    };
};
export declare function codexNoticeDefinition(): ConversationNodeDefinition<CodexNoticeNode>;
export declare function codexViewDefinition(): ConversationViewDefinition<ConversationViewNode, {
    nodes: readonly CodexNoticeNode[];
}>;
export declare function readNotice(event: NoticeEvent): CodexNoticeNode | undefined;
export {};
