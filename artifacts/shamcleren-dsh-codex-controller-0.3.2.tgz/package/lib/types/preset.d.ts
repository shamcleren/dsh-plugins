/** Codex sessions keep DSH's conversation shell and deliberately have no DSH tools to execute. */
import type { Context } from '@deepseek-ai/cordis';
export declare const name = "codex-session-preset";
export declare const inject: string[];
export declare function apply(ctx: Context): void;
