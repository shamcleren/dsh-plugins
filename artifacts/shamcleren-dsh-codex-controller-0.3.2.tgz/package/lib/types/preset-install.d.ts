import type { PresetRoot } from '@deepseek-ai/dsh-agent-presets';
export declare const CODEX_PRESET = "dsh-codex";
/** Remove only the preset this plugin installed, so Codex is a model and not a second mode. */
export declare function retireCodexPreset(roots: readonly PresetRoot[]): Promise<void>;
export declare function ensureCodexPreset(roots: readonly PresetRoot[]): Promise<void>;
