import type { Context } from '@deepseek-ai/cordis';
export declare const name = "codex-controller";
export declare const inject: string[];
export interface Config {
    journalDirectory?: string;
}
export declare const POLICY = "Use codex_delegate only when the direct human asks to delegate work to Codex. It creates a visible Codex session instead of a hidden worker. Give it a self-contained task and the expected outcome. Follow-up belongs in that Codex session. Codex owns its commands, files, and approvals; do not replay them as DSH tool calls. A DSH approval is one-shot and never grants a session-wide Codex permission.";
export declare function apply(ctx: Context, config?: Config): void;
