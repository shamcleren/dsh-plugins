/** Browser half of the WeChat plugin: contributes its own settings card. */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
import { type LocaleKey } from './locales.js';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** Copy owned by the external WeChat settings card. */
        'settings.wechat': LocaleKey;
    }
}
export declare const inject: string[];
/** Register the WeChat card when the generic plugin-settings slot exists. */
export declare function apply(ctx: ClientContext): void;
