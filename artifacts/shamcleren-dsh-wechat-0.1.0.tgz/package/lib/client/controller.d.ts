import type { SettingsScope, SnapshotStore } from '@deepseek-ai/dsh-client-runtime/client';
import type { Config } from '../config.js';
import type { FieldState, FormActions, FormState } from './form.js';
export interface WeChatCardState extends FormState {
    enabled: FieldState;
    accountIds: FieldState;
    loginMode: FieldState;
    allowedUsers: FieldState;
    adminUsers: FieldState;
    workspaceId: FieldState;
    preventIdleSleep: FieldState;
    agentPreset: FieldState;
    thinkingText: FieldState;
    turnTimeoutMs: FieldState;
    mediaMaxBytes: FieldState;
    sendTyping: FieldState;
}
export interface WeChatCardFace extends FormActions {
    hooks: {
        weChatCard: SnapshotStore<WeChatCardState>;
    };
}
/** Browser settings state for the WeChat card. */
export declare class WeChatCardController {
    private readonly form;
    private readonly state;
    constructor(scope: SettingsScope<Config>);
    inject(): WeChatCardFace;
    private snapshot;
}
