import type { Logger } from '@deepseek-ai/cordis';
import type { WeChatAccountCredentials } from './protocol.js';
/** Authorize one personal WeChat account through Tencent's official QR flow. */
export declare function loginWithQr(localTokens: readonly string[], logger: Logger): Promise<WeChatAccountCredentials>;
