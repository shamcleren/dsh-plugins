import z from '@deepseek-ai/schemastery';
export declare const DEFAULT_BASE_URL = "https://ilinkai.weixin.qq.com";
export declare const DEFAULT_CDN_BASE_URL = "https://novac2c.cdn.weixin.qq.com/c2c";
export declare const DEFAULT_THINKING_TEXT = "\u6B63\u5728\u601D\u8003\u2026";
export declare const DEFAULT_TURN_TIMEOUT_MS = 300000;
export declare const DEFAULT_WORKSPACE_NAME = "\u5FAE\u4FE1\u673A\u5668\u4EBA";
export declare const DEFAULT_MEDIA_MAX_BYTES: number;
/** Settings for Tencent iLink-backed personal WeChat accounts. */
export interface Config {
    enabled?: boolean;
    /** Empty means every locally authorized account. */
    accountIds?: string[];
    /** QR authorization policy; `always` is the explicit add-account flow. */
    loginMode?: 'if-empty' | 'always' | 'never';
    allowedUsers?: string[];
    adminUsers?: string[];
    workspaceName?: string;
    workspaceId?: string;
    preventIdleSleep?: boolean;
    agentPreset?: string;
    thinkingText?: string;
    turnTimeoutMs?: number;
    mediaMaxBytes?: number;
    sendTyping?: boolean;
}
export declare const Config: z<Config>;
export interface WeChatRuntimeConfig {
    allowedUsers: readonly string[];
    adminUsers: readonly string[];
    agentPreset?: string;
    thinkingText: string;
    turnTimeoutMs: number;
    mediaMaxBytes: number;
    sendTyping: boolean;
}
/** Resolve validated settings for an active account runtime. */
export declare function resolveRuntimeConfig(config: Config): WeChatRuntimeConfig;
