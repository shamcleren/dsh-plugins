# `@shamcleren/dsh-wechat`

Personal WeChat channel for DeepSeek Harness, backed by Tencent's official iLink Bot protocol.

## Capabilities

- QR-code login with local owner-only credential persistence.
- Multiple authorized accounts, optionally filtered by `accountIds`.
- Restart-safe long-poll cursors and per-peer reply context tokens.
- Direct text and image prompts; voice transcription, file names, and video notices are retained as text.
- Durable account-and-peer Session routing, callback deduplication, and atomic continuation admission.
- Final assistant output accumulated across model steps, Unicode-safe outbound chunking, and typing indicators.
- `/new`, Host slash commands, `/approve`, `/reject`, and `/answer` interaction replies.
- Concurrent Web/WeChat approval and question settlement through the Host interaction registry.

## Login

Install the plugin, enable it in Plugins settings, and watch the Host terminal or logs. If no local account exists, the plugin prints a QR code and its fallback URL. Scan it in WeChat and confirm the connection. If WeChat requests a numeric verification code, enter it in the Host terminal.

Credentials, poll cursors, and peer context tokens are stored under `<dsh-home>/channels/wechat/accounts.json` with owner-only permissions. They are never written to Cordis composition or browser settings. Leaving `accountIds` empty runs every locally authorized account. To add an account, set `loginMode` to `always`, complete QR authorization, then return it to `if-empty`.

## Configuration

| Field | Default | Meaning |
| --- | --- | --- |
| `enabled` | `false` | Start selected accounts; initiates QR login if none exist. |
| `accountIds` | `[]` | Local accounts to run; empty selects all. |
| `loginMode` | `if-empty` | `always` adds an account; `never` disables automatic QR authorization. |
| `allowedUsers` | `[]` | Allowed iLink peer ids; empty accepts all visible peers. |
| `adminUsers` | `[]` | Peers allowed to submit Host slash commands. |
| `workspaceId` | omitted | Existing default Workspace for new conversations. |
| `workspaceName` | `微信机器人` | Managed fallback Workspace title. |
| `agentPreset` | omitted | Agent preset for newly created Sessions. |
| `thinkingText` | `正在思考…` | Progress message emitted before the final answer. |
| `turnTimeoutMs` | `300000` | Maximum durable-turn observation time. |
| `mediaMaxBytes` | `20971520` | Maximum encrypted or decrypted inbound image size. |
| `sendTyping` | `true` | Publish and cancel WeChat typing state around a turn. |
| `preventIdleSleep` | `false` | Prevent idle macOS sleep while connected. |

## Protocol limits

Tencent iLink currently exposes direct-chat semantics to this plugin. Group behavior is not advertised. Harness prompt transport accepts text and image bytes, so voice uses Tencent's transcript when available; files and videos retain descriptive metadata instead of injecting unsupported binary prompt blocks. Assistant replies are text-only because durable assistant messages currently expose text content to external channels.

## Development

```sh
pnpm --filter @shamcleren/dsh-wechat test
pnpm --filter @shamcleren/dsh-wechat typecheck
pnpm --filter @shamcleren/dsh-wechat build
```
