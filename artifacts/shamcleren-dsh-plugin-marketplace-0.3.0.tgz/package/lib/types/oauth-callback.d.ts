import { type IncomingMessage, type ServerResponse } from 'node:http';
/** Must match the URI registered for the bundled public Gongfeng application. */
export declare const OAUTH_REDIRECT_URI = "http://127.0.0.1:3080/oauth/gongfeng/callback";
/** Own the fixed callback port only while a login is pending on a different Host port. */
export declare class OAuthCallbackListener {
    private readonly callback;
    private readonly redirectUri;
    private server;
    private timer;
    private starting;
    private disposed;
    constructor(callback: (req: IncomingMessage, res: ServerResponse) => Promise<boolean>, redirectUri?: string);
    start(): Promise<void>;
    dispose(): Promise<void>;
    private expire;
    private close;
}
