/** One repository address is enough for the built-in Gongfeng OAuth client. */
export declare const GONGFENG_ORIGIN = "https://git.woa.com/";
export declare const DEFAULT_REPOSITORY_URL = "https://git.woa.com/shamcleren/dsh-plugin";
export declare function parseRepositoryUrl(value: string): {
    baseUrl: string;
    repository: string;
    repositoryUrl: string;
};
