/** Validated public methods; installation remains restricted to the trusted catalog. */
import type { ConnectionRpcHandler } from '@deepseek-ai/dsh-client-connection';
import type MarketplaceService from './service.ts';
type BrowserService = Pick<MarketplaceService, 'state' | 'catalog' | 'refreshCatalog' | 'configure' | 'add' | 'deletePackage' | 'beginOAuth' | 'oauthStatus'>;
/** Create an allowlisted handler for the human-operated settings page. */
export declare function createMarketplaceRpcHandler(service: BrowserService, report: (error: unknown) => void): ConnectionRpcHandler;
export {};
