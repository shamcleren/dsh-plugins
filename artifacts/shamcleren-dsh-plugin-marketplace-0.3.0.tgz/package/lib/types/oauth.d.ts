/** Gongfeng OAuth 2.0 PKCE flow and authorized API access. */
import type { CredentialProvider } from '@deepseek-ai/dsh-credentials';
import type { MarketplaceOAuthStart, MarketplaceOAuthStatus, MarketplaceRepository } from './types.ts';
/** Runtime OAuth settings and credential references. */
export interface GongfengOAuthConfig {
    readonly baseUrl: string;
    readonly clientId: string;
    readonly redirectUri: string;
    readonly expiresAt?: number;
    readonly accessTokenRef: string;
    readonly refreshTokenRef: string;
}
/** One bounded OAuth repository-file read. */
export interface GongfengOAuthFileRequest {
    readonly config: GongfengOAuthConfig;
    readonly repository: string;
    readonly path: string;
    readonly ref: string;
    readonly maxBytes: number;
}
/** One bounded Gongfeng v3 raw-file read. */
export interface GongfengOAuthRawFileRequest {
    readonly config: GongfengOAuthConfig;
    readonly repository: string;
    readonly commitId: string;
    readonly path: string;
    readonly maxBytes: number;
}
/**
 * Validate a Gongfeng OAuth origin before attaching credentials.
 * @param value Candidate Gongfeng base URL.
 * @returns Parsed HTTPS origin without credentials, path, query, or fragment.
 */
export declare function validateOAuthBaseUrl(value: string): URL;
/**
 * Derive an RFC 7636 S256 challenge from a verifier.
 * @param verifier URL-safe PKCE verifier.
 * @returns URL-safe unpadded SHA-256 challenge.
 */
export declare function pkceChallenge(verifier: string): string;
/** Owns one-process PKCE state, token refresh, and Gongfeng API reads. */
export declare class GongfengOAuthController {
    private readonly credentials;
    private readonly updateExpiry;
    private readonly flows;
    private readonly stateToFlow;
    private refreshPromise;
    private readonly lifetime;
    constructor(credentials: CredentialProvider, updateExpiry: (expiresAt: number) => Promise<void>);
    /**
     * Start one OAuth authorization using fresh state and PKCE values.
     * @param config Public client and redirect configuration.
     * @returns Browser authorization URL and polling identity.
     */
    begin(config: GongfengOAuthConfig): MarketplaceOAuthStart;
    /**
     * Read one flow without exposing its verifier, state, code, or tokens.
     * @param flowId Identity returned from {@link begin}.
     * @returns Current authorization status.
     */
    status(flowId: string): MarketplaceOAuthStatus;
    /**
     * Consume one loopback callback and exchange its code through PKCE.
     * @param callbackUrl Callback request URL.
     */
    callback(callbackUrl: URL): Promise<void>;
    /**
     * Resolve a current OAuth access token, refreshing it before expiry.
     * @param config Current public OAuth and credential configuration.
     * @param forceRefresh Whether to refresh even when the recorded expiry is current.
     * @returns Access token, or `undefined` when OAuth is not configured.
     */
    accessToken(config: GongfengOAuthConfig, forceRefresh?: boolean): Promise<string | undefined>;
    /** Read the selected project only, including its default branch. */
    repository(config: GongfengOAuthConfig, repository: string): Promise<MarketplaceRepository>;
    /** Stop pending network work and invalidate callbacks when the owning plugin unloads. */
    dispose(): void;
    private request;
    /**
     * Read a repository file with the OAuth header required by Gongfeng.
     * @param request OAuth settings, repository identity, path, ref, and byte bound.
     * @returns Raw Gongfeng repository-file JSON bytes.
     */
    repositoryFile(request: GongfengOAuthFileRequest): Promise<Buffer>;
    /**
     * Read repository file bytes through Gongfeng v3's raw endpoint.
     * @param request OAuth settings, repository, commit, path, and byte bound.
     * @returns Raw file bytes.
     */
    repositoryRawFile(request: GongfengOAuthRawFileRequest): Promise<Buffer>;
    private fetch;
    private refresh;
    private exchange;
    private storeToken;
    private pruneFlows;
}
