/** Reuse the profile's installed layout even when the desktop launch environment differs from the installer. */
export declare function profilePnpmOptions(profile: string): Promise<string[]>;
