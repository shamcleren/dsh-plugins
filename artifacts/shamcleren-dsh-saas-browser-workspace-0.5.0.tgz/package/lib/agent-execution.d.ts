import type { Page } from 'playwright';
import type { ExecutionRule, Site } from './site.js';
import { ExecutionResult } from './agent-contract.js';
export declare const normalizeLabel: (label: string) => string;
export declare const forbiddenLabel: (label: string) => boolean;
export declare function executionRule(site: Site, url: string): ExecutionRule | undefined;
/** Owns submission receipts and DOM evidence; model prose never becomes execution output. */
export declare class Executions {
    private journal?;
    readonly results: ExecutionResult[];
    private pending?;
    private loaded?;
    constructor(journal?: {
        path: string;
        sessionId: string;
        siteUrl: string;
    } | undefined);
    load(): Promise<void>;
    private persist;
    hasReceipt(id: string): boolean;
    submit(page: Page, rule: ExecutionRule, id: string, selector: string): Promise<void>;
    refresh(): Promise<void>;
    wait(signal: AbortSignal): Promise<void>;
}
