import { z } from 'zod';
export declare const CHANNEL = "/saas-workspace";
export declare const TOOL = "saas_query_agents";
export declare const PROVIDER = "saas-playwright";
export declare const PREFIX = "mcp__saas-playwright__";
export declare const Id: z.ZodString;
export declare const Session: z.ZodString;
export declare const Fields: z.ZodObject<{
    keyword: z.ZodString;
    view: z.ZodDefault<z.ZodEnum<{
        table: "table";
        list: "list";
    }>>;
}, z.core.$strict>;
export type Fields = z.infer<typeof Fields>;
export declare const Row: z.ZodObject<{
    key: z.ZodString;
    name: z.ZodString;
    type: z.ZodString;
    version: z.ZodString;
    tags: z.ZodArray<z.ZodString>;
    description: z.ZodString;
}, z.core.$strict>;
export type Row = z.infer<typeof Row>;
export declare const Observation: z.ZodObject<{
    id: z.ZodString;
    capturedAt: z.ZodString;
    url: z.ZodString;
    title: z.ZodString;
    rows: z.ZodArray<z.ZodObject<{
        key: z.ZodString;
        name: z.ZodString;
        type: z.ZodString;
        version: z.ZodString;
        tags: z.ZodArray<z.ZodString>;
        description: z.ZodString;
    }, z.core.$strict>>;
    renderedCount: z.ZodNumber;
    truncated: z.ZodBoolean;
    coverage: z.ZodLiteral<"rendered-results">;
    evidenceId: z.ZodString;
    counts: z.ZodRecord<z.ZodString, z.ZodNumber>;
}, z.core.$strict>;
export type Observation = z.infer<typeof Observation>;
export declare const Run: z.ZodObject<{
    id: z.ZodString;
    sessionId: z.ZodString;
    revision: z.ZodNumber;
    siteName: z.ZodString;
    status: z.ZodEnum<{
        running: "running";
        failed: "failed";
        queued: "queued";
        awaiting_input: "awaiting_input";
        interrupted: "interrupted";
        cancelled: "cancelled";
        awaiting_login: "awaiting_login";
        succeeded: "succeeded";
        partial: "partial";
    }>;
    createdAt: z.ZodString;
    updatedAt: z.ZodString;
    input: z.ZodObject<{
        id: z.ZodString;
        fields: z.ZodObject<{
            keyword: z.ZodString;
            view: z.ZodDefault<z.ZodEnum<{
                table: "table";
                list: "list";
            }>>;
        }, z.core.$strict>;
        requestId: z.ZodOptional<z.ZodString>;
        submitted: z.ZodBoolean;
        accepted: z.ZodBoolean;
    }, z.core.$strict>;
    observation: z.ZodOptional<z.ZodObject<{
        id: z.ZodString;
        capturedAt: z.ZodString;
        url: z.ZodString;
        title: z.ZodString;
        rows: z.ZodArray<z.ZodObject<{
            key: z.ZodString;
            name: z.ZodString;
            type: z.ZodString;
            version: z.ZodString;
            tags: z.ZodArray<z.ZodString>;
            description: z.ZodString;
        }, z.core.$strict>>;
        renderedCount: z.ZodNumber;
        truncated: z.ZodBoolean;
        coverage: z.ZodLiteral<"rendered-results">;
        evidenceId: z.ZodString;
        counts: z.ZodRecord<z.ZodString, z.ZodNumber>;
    }, z.core.$strict>>;
    error: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export type Run = z.infer<typeof Run>;
export declare const NavigationBlock: z.ZodObject<{
    origin: z.ZodString;
    at: z.ZodString;
}, z.core.$strict>;
export declare const State: z.ZodObject<{
    configured: z.ZodBoolean;
    siteName: z.ZodString;
    run: z.ZodNullable<z.ZodObject<{
        id: z.ZodString;
        sessionId: z.ZodString;
        revision: z.ZodNumber;
        siteName: z.ZodString;
        status: z.ZodEnum<{
            running: "running";
            failed: "failed";
            queued: "queued";
            awaiting_input: "awaiting_input";
            interrupted: "interrupted";
            cancelled: "cancelled";
            awaiting_login: "awaiting_login";
            succeeded: "succeeded";
            partial: "partial";
        }>;
        createdAt: z.ZodString;
        updatedAt: z.ZodString;
        input: z.ZodObject<{
            id: z.ZodString;
            fields: z.ZodObject<{
                keyword: z.ZodString;
                view: z.ZodDefault<z.ZodEnum<{
                    table: "table";
                    list: "list";
                }>>;
            }, z.core.$strict>;
            requestId: z.ZodOptional<z.ZodString>;
            submitted: z.ZodBoolean;
            accepted: z.ZodBoolean;
        }, z.core.$strict>;
        observation: z.ZodOptional<z.ZodObject<{
            id: z.ZodString;
            capturedAt: z.ZodString;
            url: z.ZodString;
            title: z.ZodString;
            rows: z.ZodArray<z.ZodObject<{
                key: z.ZodString;
                name: z.ZodString;
                type: z.ZodString;
                version: z.ZodString;
                tags: z.ZodArray<z.ZodString>;
                description: z.ZodString;
            }, z.core.$strict>>;
            renderedCount: z.ZodNumber;
            truncated: z.ZodBoolean;
            coverage: z.ZodLiteral<"rendered-results">;
            evidenceId: z.ZodString;
            counts: z.ZodRecord<z.ZodString, z.ZodNumber>;
        }, z.core.$strict>>;
        error: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
    blockedOrigin: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export type State = z.infer<typeof State>;
export declare const BoundRequest: z.ZodObject<{
    sessionId: z.ZodString;
    runId: z.ZodString;
    revision: z.ZodNumber;
}, z.core.$strict>;
export declare const SubmitRequest: z.ZodObject<{
    sessionId: z.ZodString;
    runId: z.ZodString;
    revision: z.ZodNumber;
    inputId: z.ZodString;
    fields: z.ZodObject<{
        keyword: z.ZodString;
        view: z.ZodDefault<z.ZodEnum<{
            table: "table";
            list: "list";
        }>>;
    }, z.core.$strict>;
}, z.core.$strict>;
export type SubmitRequest = z.infer<typeof SubmitRequest>;
export type BoundRequest = z.infer<typeof BoundRequest>;
export interface Remote {
    state(sessionId: string, signal?: AbortSignal): Promise<State>;
    submit(request: SubmitRequest): Promise<Run>;
    edit(request: BoundRequest): Promise<Run>;
    resume(request: BoundRequest, signal?: AbortSignal): Promise<Run>;
    showLogin(request: BoundRequest, signal?: AbortSignal): Promise<Run>;
    cancel(request: BoundRequest): Promise<Run>;
    evidence(sessionId: string, runId: string, evidenceId: string, signal?: AbortSignal): Promise<Blob>;
}
export declare class WorkspaceError extends Error {
    readonly code: string;
    constructor(code: string);
}
