import { Run, Fields, type BoundRequest, type Observation, type SubmitRequest } from './contract.js';
type Enqueue = (sessionId: string, requestId: string, runId: string) => Promise<void>;
export declare class RunStore {
    private readonly directory;
    private runs;
    private durable;
    private lane;
    private stopped;
    private constructor();
    static open(directory: string): Promise<RunStore>;
    private save;
    private serial;
    private own;
    private bound;
    private available;
    private commit;
    latest(sessionId: string): Run | null;
    get(sessionId: string, runId: string): Run;
    showLogin(request: BoundRequest, show: () => Promise<void>): Promise<Run>;
    create(sessionId: string, siteName: string, fields?: Fields): Promise<Run>;
    submit(request: SubmitRequest, enqueue: Enqueue): Promise<Run>;
    edit(request: BoundRequest): Promise<Run>;
    resume(request: BoundRequest, enqueue: Enqueue): Promise<Run>;
    start(sessionId: string, runId: string): Promise<Run>;
    finish(sessionId: string, runId: string, result: Observation | 'awaiting_login' | 'failed', error?: string): Promise<Run>;
    cancel(request: BoundRequest): Promise<Run>;
    close(): Promise<void>;
}
export {};
