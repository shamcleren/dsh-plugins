import { z } from 'zod';
import type { Context } from '@deepseek-ai/cordis';
import type { ToolExecution, ToolRunContext } from '@deepseek-ai/dsh-tools';
import { Observation } from './contract.js';
import { type Site } from './site.js';
declare const PageResult: z.ZodDiscriminatedUnion<[z.ZodObject<{
    kind: z.ZodLiteral<"login">;
}, z.core.$strict>, z.ZodObject<{
    kind: z.ZodLiteral<"result">;
    url: z.ZodString;
    title: z.ZodString;
    rows: z.ZodArray<z.ZodObject<{
        key: z.ZodString;
        name: z.ZodString;
        type: z.ZodString;
        version: z.ZodString;
        tags: z.ZodArray<z.ZodString>;
        description: z.ZodString;
    }, z.core.$strict>>;
    renderedCount: z.ZodNumber;
}, z.core.$strict>], "kind">;
/** Only fixed host recipes may use this provider, including an owner-requested login handoff. */
export declare class BrowserAdapter {
    private readonly ctx;
    private readonly site;
    private readonly outputDir;
    private readonly blockedPath?;
    private permits;
    constructor(ctx: Context, site: Site, outputDir: string, blockedPath?: string | undefined);
    guard: (exec: Readonly<ToolExecution>) => string | undefined;
    showLogin(agent: NonNullable<ToolExecution['agent']>, signal: AbortSignal): Promise<void>;
    query(keyword: string, exec: ToolRunContext): Promise<Observation | 'awaiting_login'>;
}
export declare function parseResult(value: unknown): z.infer<typeof PageResult>;
/** Activate the existing task tab; opening a new tab would not transfer its login state. */
export declare function loginCode(site: Site): string;
/** Trusted, fixed recipe. User values are JSON literals, never source, selectors or file paths. */
export declare function queryCode(site: Site, keyword: string, screenshotPath: string): string;
/** Owned page setup also intercepts Chromium redirect requests; Playwright's origin option alone does not. */
export declare function pagePolicyCode(site: Site, blockedPath?: string): string;
export {};
