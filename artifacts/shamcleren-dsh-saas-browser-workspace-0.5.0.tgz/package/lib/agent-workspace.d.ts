import type { Context } from '@deepseek-ai/cordis';
import Schema from '@deepseek-ai/schemastery';
export declare const name = "saas-browser-workspace";
export declare const inject: string[];
export interface Config {
    siteFile?: string;
    executionStateDir?: string;
}
export declare const Config: Schema<Config>;
export declare function apply(ctx: Context, config: Config): Promise<void>;
