import type { Context } from '@deepseek-ai/cordis';
import type { ConnectionRpcHandler } from '@deepseek-ai/dsh-client-connection';
import type { IncomingMessage, ServerResponse } from 'node:http';
/** rc.5's RPC registry loses the caller's webServer scope; use its public Web route and admission APIs. */
export declare function registerRpc(ctx: Context, channel: string, handler: ConnectionRpcHandler): void;
export declare function registerEvidence(ctx: Context, handler: (request: IncomingMessage, response: ServerResponse) => Promise<void>): void;
