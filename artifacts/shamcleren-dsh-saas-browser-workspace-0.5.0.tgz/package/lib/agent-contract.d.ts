import { z } from 'zod';
export declare const AGENT_CHANNEL = "/saas-agent";
export declare const BROWSER_TOOL = "saas_browser";
export declare const VIEW_TOOL = "saas_present";
export declare const ASK_TOOL = "saas_ask";
export declare const AgentSession: z.ZodString;
export declare const Control: z.ZodObject<{
    ref: z.ZodString;
    label: z.ZodString;
    role: z.ZodString;
    value: z.ZodString;
    canFill: z.ZodBoolean;
    canClick: z.ZodBoolean;
    sensitive: z.ZodBoolean;
    purpose: z.ZodDefault<z.ZodEnum<{
        message: "message";
        submit: "submit";
        readonly: "readonly";
        search: "search";
        navigation: "navigation";
        disclosure: "disclosure";
    }>>;
    approval: z.ZodOptional<z.ZodArray<z.ZodEnum<{
        click: "click";
        fill: "fill";
        select: "select";
    }>>>;
    options: z.ZodOptional<z.ZodArray<z.ZodObject<{
        label: z.ZodString;
        value: z.ZodString;
    }, z.core.$strip>>>;
}, z.core.$strip>;
export type Control = z.infer<typeof Control>;
export declare const AgentRecord: z.ZodObject<{
    id: z.ZodString;
    name: z.ZodString;
    type: z.ZodString;
    version: z.ZodString;
    description: z.ZodString;
    tags: z.ZodArray<z.ZodString>;
    actions: z.ZodArray<z.ZodObject<{
        ref: z.ZodString;
        label: z.ZodString;
    }, z.core.$strip>>;
}, z.core.$strip>;
export type AgentRecord = z.infer<typeof AgentRecord>;
export declare const PageField: z.ZodObject<{
    label: z.ZodString;
    kind: z.ZodEnum<{
        number: "number";
        text: "text";
        multiline: "multiline";
        choice: "choice";
        toggle: "toggle";
    }>;
    state: z.ZodEnum<{
        value: "value";
        empty: "empty";
        unread: "unread";
        redacted: "redacted";
    }>;
    value: z.ZodString;
    checked: z.ZodOptional<z.ZodEnum<{
        on: "on";
        off: "off";
        mixed: "mixed";
    }>>;
}, z.core.$strip>;
export type PageField = z.infer<typeof PageField>;
export declare const PageBlock: z.ZodDiscriminatedUnion<[z.ZodObject<{
    kind: z.ZodLiteral<"fields">;
    title: z.ZodString;
    fields: z.ZodArray<z.ZodObject<{
        label: z.ZodString;
        kind: z.ZodEnum<{
            number: "number";
            text: "text";
            multiline: "multiline";
            choice: "choice";
            toggle: "toggle";
        }>;
        state: z.ZodEnum<{
            value: "value";
            empty: "empty";
            unread: "unread";
            redacted: "redacted";
        }>;
        value: z.ZodString;
        checked: z.ZodOptional<z.ZodEnum<{
            on: "on";
            off: "off";
            mixed: "mixed";
        }>>;
    }, z.core.$strip>>;
}, z.core.$strip>, z.ZodObject<{
    kind: z.ZodLiteral<"table">;
    title: z.ZodString;
    columns: z.ZodArray<z.ZodString>;
    rows: z.ZodArray<z.ZodArray<z.ZodString>>;
}, z.core.$strip>, z.ZodObject<{
    kind: z.ZodLiteral<"list">;
    title: z.ZodString;
    items: z.ZodArray<z.ZodString>;
}, z.core.$strip>, z.ZodObject<{
    kind: z.ZodLiteral<"text">;
    title: z.ZodString;
    text: z.ZodString;
}, z.core.$strip>], "kind">;
export type PageBlock = z.infer<typeof PageBlock>;
export declare const PageDocument: z.ZodObject<{
    blocks: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
        kind: z.ZodLiteral<"fields">;
        title: z.ZodString;
        fields: z.ZodArray<z.ZodObject<{
            label: z.ZodString;
            kind: z.ZodEnum<{
                number: "number";
                text: "text";
                multiline: "multiline";
                choice: "choice";
                toggle: "toggle";
            }>;
            state: z.ZodEnum<{
                value: "value";
                empty: "empty";
                unread: "unread";
                redacted: "redacted";
            }>;
            value: z.ZodString;
            checked: z.ZodOptional<z.ZodEnum<{
                on: "on";
                off: "off";
                mixed: "mixed";
            }>>;
        }, z.core.$strip>>;
    }, z.core.$strip>, z.ZodObject<{
        kind: z.ZodLiteral<"table">;
        title: z.ZodString;
        columns: z.ZodArray<z.ZodString>;
        rows: z.ZodArray<z.ZodArray<z.ZodString>>;
    }, z.core.$strip>, z.ZodObject<{
        kind: z.ZodLiteral<"list">;
        title: z.ZodString;
        items: z.ZodArray<z.ZodString>;
    }, z.core.$strip>, z.ZodObject<{
        kind: z.ZodLiteral<"text">;
        title: z.ZodString;
        text: z.ZodString;
    }, z.core.$strip>], "kind">>;
    gaps: z.ZodArray<z.ZodObject<{
        kind: z.ZodEnum<{
            unread: "unread";
            collapsed: "collapsed";
            graphic: "graphic";
            embedded: "embedded";
            editor: "editor";
            unstructured: "unstructured";
            limit: "limit";
        }>;
        label: z.ZodString;
    }, z.core.$strip>>;
    truncated: z.ZodBoolean;
}, z.core.$strip>;
export type PageDocument = z.infer<typeof PageDocument>;
export declare const PageObservation: z.ZodObject<{
    id: z.ZodString;
    url: z.ZodString;
    title: z.ZodString;
    text: z.ZodString;
    controls: z.ZodArray<z.ZodObject<{
        ref: z.ZodString;
        label: z.ZodString;
        role: z.ZodString;
        value: z.ZodString;
        canFill: z.ZodBoolean;
        canClick: z.ZodBoolean;
        sensitive: z.ZodBoolean;
        purpose: z.ZodDefault<z.ZodEnum<{
            message: "message";
            submit: "submit";
            readonly: "readonly";
            search: "search";
            navigation: "navigation";
            disclosure: "disclosure";
        }>>;
        approval: z.ZodOptional<z.ZodArray<z.ZodEnum<{
            click: "click";
            fill: "fill";
            select: "select";
        }>>>;
        options: z.ZodOptional<z.ZodArray<z.ZodObject<{
            label: z.ZodString;
            value: z.ZodString;
        }, z.core.$strip>>>;
    }, z.core.$strip>>;
    records: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        name: z.ZodString;
        type: z.ZodString;
        version: z.ZodString;
        description: z.ZodString;
        tags: z.ZodArray<z.ZodString>;
        actions: z.ZodArray<z.ZodObject<{
            ref: z.ZodString;
            label: z.ZodString;
        }, z.core.$strip>>;
    }, z.core.$strip>>;
    document: z.ZodOptional<z.ZodObject<{
        blocks: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"fields">;
            title: z.ZodString;
            fields: z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                kind: z.ZodEnum<{
                    number: "number";
                    text: "text";
                    multiline: "multiline";
                    choice: "choice";
                    toggle: "toggle";
                }>;
                state: z.ZodEnum<{
                    value: "value";
                    empty: "empty";
                    unread: "unread";
                    redacted: "redacted";
                }>;
                value: z.ZodString;
                checked: z.ZodOptional<z.ZodEnum<{
                    on: "on";
                    off: "off";
                    mixed: "mixed";
                }>>;
            }, z.core.$strip>>;
        }, z.core.$strip>, z.ZodObject<{
            kind: z.ZodLiteral<"table">;
            title: z.ZodString;
            columns: z.ZodArray<z.ZodString>;
            rows: z.ZodArray<z.ZodArray<z.ZodString>>;
        }, z.core.$strip>, z.ZodObject<{
            kind: z.ZodLiteral<"list">;
            title: z.ZodString;
            items: z.ZodArray<z.ZodString>;
        }, z.core.$strip>, z.ZodObject<{
            kind: z.ZodLiteral<"text">;
            title: z.ZodString;
            text: z.ZodString;
        }, z.core.$strip>], "kind">>;
        gaps: z.ZodArray<z.ZodObject<{
            kind: z.ZodEnum<{
                unread: "unread";
                collapsed: "collapsed";
                graphic: "graphic";
                embedded: "embedded";
                editor: "editor";
                unstructured: "unstructured";
                limit: "limit";
            }>;
            label: z.ZodString;
        }, z.core.$strip>>;
        truncated: z.ZodBoolean;
    }, z.core.$strip>>;
    capturedAt: z.ZodString;
    truncated: z.ZodBoolean;
    recordsState: z.ZodDefault<z.ZodEnum<{
        empty: "empty";
        unavailable: "unavailable";
        loading: "loading";
        ready: "ready";
    }>>;
}, z.core.$strip>;
export type PageObservation = z.infer<typeof PageObservation>;
export declare const Question: z.ZodObject<{
    id: z.ZodString;
    title: z.ZodString;
    fields: z.ZodArray<z.ZodObject<{
        name: z.ZodString;
        label: z.ZodString;
        required: z.ZodDefault<z.ZodBoolean>;
        type: z.ZodDefault<z.ZodEnum<{
            text: "text";
            textarea: "textarea";
        }>>;
    }, z.core.$strip>>;
}, z.core.$strip>;
export type Question = z.infer<typeof Question>;
export declare const ExecutionResult: z.ZodObject<{
    id: z.ZodString;
    mode: z.ZodEnum<{
        debug: "debug";
        use: "use";
    }>;
    status: z.ZodEnum<{
        running: "running";
        completed: "completed";
        failed: "failed";
        uncertain: "uncertain";
    }>;
    input: z.ZodString;
    output: z.ZodString;
    error: z.ZodOptional<z.ZodString>;
    url: z.ZodString;
    startedAt: z.ZodString;
    updatedAt: z.ZodString;
}, z.core.$strip>;
export type ExecutionResult = z.infer<typeof ExecutionResult>;
export declare const ActionReview: z.ZodObject<{
    id: z.ZodString;
    action: z.ZodEnum<{
        click: "click";
        fill: "fill";
        select: "select";
    }>;
    label: z.ZodString;
    url: z.ZodString;
    pageTitle: z.ZodString;
    expiresAt: z.ZodString;
    before: z.ZodOptional<z.ZodString>;
    after: z.ZodOptional<z.ZodString>;
    fields: z.ZodArray<z.ZodObject<{
        label: z.ZodString;
        kind: z.ZodEnum<{
            number: "number";
            text: "text";
            multiline: "multiline";
            choice: "choice";
            toggle: "toggle";
        }>;
        state: z.ZodEnum<{
            value: "value";
            empty: "empty";
            unread: "unread";
            redacted: "redacted";
        }>;
        value: z.ZodString;
        checked: z.ZodOptional<z.ZodEnum<{
            on: "on";
            off: "off";
            mixed: "mixed";
        }>>;
    }, z.core.$strip>>;
    fieldsLimited: z.ZodBoolean;
    target: z.ZodObject<{
        left: z.ZodNumber;
        top: z.ZodNumber;
        width: z.ZodNumber;
        height: z.ZodNumber;
    }, z.core.$strip>;
}, z.core.$strip>;
export type ActionReview = z.infer<typeof ActionReview>;
export declare const AgentState: z.ZodObject<{
    sessionId: z.ZodString;
    configured: z.ZodBoolean;
    siteName: z.ZodString;
    phase: z.ZodEnum<{
        ready: "ready";
        failed: "failed";
        queued: "queued";
        working: "working";
        awaiting_input: "awaiting_input";
        awaiting_approval: "awaiting_approval";
        human: "human";
    }>;
    operation: z.ZodString;
    view: z.ZodDefault<z.ZodEnum<{
        results: "results";
        table: "table";
        list: "list";
        summary: "summary";
        details: "details";
    }>>;
    title: z.ZodString;
    executionEnabled: z.ZodDefault<z.ZodBoolean>;
    executions: z.ZodDefault<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        mode: z.ZodEnum<{
            debug: "debug";
            use: "use";
        }>;
        status: z.ZodEnum<{
            running: "running";
            completed: "completed";
            failed: "failed";
            uncertain: "uncertain";
        }>;
        input: z.ZodString;
        output: z.ZodString;
        error: z.ZodOptional<z.ZodString>;
        url: z.ZodString;
        startedAt: z.ZodString;
        updatedAt: z.ZodString;
    }, z.core.$strip>>>;
    observation: z.ZodOptional<z.ZodObject<{
        id: z.ZodString;
        url: z.ZodString;
        title: z.ZodString;
        text: z.ZodString;
        controls: z.ZodArray<z.ZodObject<{
            ref: z.ZodString;
            label: z.ZodString;
            role: z.ZodString;
            value: z.ZodString;
            canFill: z.ZodBoolean;
            canClick: z.ZodBoolean;
            sensitive: z.ZodBoolean;
            purpose: z.ZodDefault<z.ZodEnum<{
                message: "message";
                submit: "submit";
                readonly: "readonly";
                search: "search";
                navigation: "navigation";
                disclosure: "disclosure";
            }>>;
            approval: z.ZodOptional<z.ZodArray<z.ZodEnum<{
                click: "click";
                fill: "fill";
                select: "select";
            }>>>;
            options: z.ZodOptional<z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                value: z.ZodString;
            }, z.core.$strip>>>;
        }, z.core.$strip>>;
        records: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            name: z.ZodString;
            type: z.ZodString;
            version: z.ZodString;
            description: z.ZodString;
            tags: z.ZodArray<z.ZodString>;
            actions: z.ZodArray<z.ZodObject<{
                ref: z.ZodString;
                label: z.ZodString;
            }, z.core.$strip>>;
        }, z.core.$strip>>;
        document: z.ZodOptional<z.ZodObject<{
            blocks: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
                kind: z.ZodLiteral<"fields">;
                title: z.ZodString;
                fields: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    kind: z.ZodEnum<{
                        number: "number";
                        text: "text";
                        multiline: "multiline";
                        choice: "choice";
                        toggle: "toggle";
                    }>;
                    state: z.ZodEnum<{
                        value: "value";
                        empty: "empty";
                        unread: "unread";
                        redacted: "redacted";
                    }>;
                    value: z.ZodString;
                    checked: z.ZodOptional<z.ZodEnum<{
                        on: "on";
                        off: "off";
                        mixed: "mixed";
                    }>>;
                }, z.core.$strip>>;
            }, z.core.$strip>, z.ZodObject<{
                kind: z.ZodLiteral<"table">;
                title: z.ZodString;
                columns: z.ZodArray<z.ZodString>;
                rows: z.ZodArray<z.ZodArray<z.ZodString>>;
            }, z.core.$strip>, z.ZodObject<{
                kind: z.ZodLiteral<"list">;
                title: z.ZodString;
                items: z.ZodArray<z.ZodString>;
            }, z.core.$strip>, z.ZodObject<{
                kind: z.ZodLiteral<"text">;
                title: z.ZodString;
                text: z.ZodString;
            }, z.core.$strip>], "kind">>;
            gaps: z.ZodArray<z.ZodObject<{
                kind: z.ZodEnum<{
                    unread: "unread";
                    collapsed: "collapsed";
                    graphic: "graphic";
                    embedded: "embedded";
                    editor: "editor";
                    unstructured: "unstructured";
                    limit: "limit";
                }>;
                label: z.ZodString;
            }, z.core.$strip>>;
            truncated: z.ZodBoolean;
        }, z.core.$strip>>;
        capturedAt: z.ZodString;
        truncated: z.ZodBoolean;
        recordsState: z.ZodDefault<z.ZodEnum<{
            empty: "empty";
            unavailable: "unavailable";
            loading: "loading";
            ready: "ready";
        }>>;
    }, z.core.$strip>>;
    listing: z.ZodOptional<z.ZodObject<{
        id: z.ZodString;
        url: z.ZodString;
        title: z.ZodString;
        text: z.ZodString;
        controls: z.ZodArray<z.ZodObject<{
            ref: z.ZodString;
            label: z.ZodString;
            role: z.ZodString;
            value: z.ZodString;
            canFill: z.ZodBoolean;
            canClick: z.ZodBoolean;
            sensitive: z.ZodBoolean;
            purpose: z.ZodDefault<z.ZodEnum<{
                message: "message";
                submit: "submit";
                readonly: "readonly";
                search: "search";
                navigation: "navigation";
                disclosure: "disclosure";
            }>>;
            approval: z.ZodOptional<z.ZodArray<z.ZodEnum<{
                click: "click";
                fill: "fill";
                select: "select";
            }>>>;
            options: z.ZodOptional<z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                value: z.ZodString;
            }, z.core.$strip>>>;
        }, z.core.$strip>>;
        records: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            name: z.ZodString;
            type: z.ZodString;
            version: z.ZodString;
            description: z.ZodString;
            tags: z.ZodArray<z.ZodString>;
            actions: z.ZodArray<z.ZodObject<{
                ref: z.ZodString;
                label: z.ZodString;
            }, z.core.$strip>>;
        }, z.core.$strip>>;
        document: z.ZodOptional<z.ZodObject<{
            blocks: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
                kind: z.ZodLiteral<"fields">;
                title: z.ZodString;
                fields: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    kind: z.ZodEnum<{
                        number: "number";
                        text: "text";
                        multiline: "multiline";
                        choice: "choice";
                        toggle: "toggle";
                    }>;
                    state: z.ZodEnum<{
                        value: "value";
                        empty: "empty";
                        unread: "unread";
                        redacted: "redacted";
                    }>;
                    value: z.ZodString;
                    checked: z.ZodOptional<z.ZodEnum<{
                        on: "on";
                        off: "off";
                        mixed: "mixed";
                    }>>;
                }, z.core.$strip>>;
            }, z.core.$strip>, z.ZodObject<{
                kind: z.ZodLiteral<"table">;
                title: z.ZodString;
                columns: z.ZodArray<z.ZodString>;
                rows: z.ZodArray<z.ZodArray<z.ZodString>>;
            }, z.core.$strip>, z.ZodObject<{
                kind: z.ZodLiteral<"list">;
                title: z.ZodString;
                items: z.ZodArray<z.ZodString>;
            }, z.core.$strip>, z.ZodObject<{
                kind: z.ZodLiteral<"text">;
                title: z.ZodString;
                text: z.ZodString;
            }, z.core.$strip>], "kind">>;
            gaps: z.ZodArray<z.ZodObject<{
                kind: z.ZodEnum<{
                    unread: "unread";
                    collapsed: "collapsed";
                    graphic: "graphic";
                    embedded: "embedded";
                    editor: "editor";
                    unstructured: "unstructured";
                    limit: "limit";
                }>;
                label: z.ZodString;
            }, z.core.$strip>>;
            truncated: z.ZodBoolean;
        }, z.core.$strip>>;
        capturedAt: z.ZodString;
        truncated: z.ZodBoolean;
        recordsState: z.ZodDefault<z.ZodEnum<{
            empty: "empty";
            unavailable: "unavailable";
            loading: "loading";
            ready: "ready";
        }>>;
    }, z.core.$strip>>;
    details: z.ZodOptional<z.ZodObject<{
        id: z.ZodString;
        url: z.ZodString;
        title: z.ZodString;
        text: z.ZodString;
        controls: z.ZodArray<z.ZodObject<{
            ref: z.ZodString;
            label: z.ZodString;
            role: z.ZodString;
            value: z.ZodString;
            canFill: z.ZodBoolean;
            canClick: z.ZodBoolean;
            sensitive: z.ZodBoolean;
            purpose: z.ZodDefault<z.ZodEnum<{
                message: "message";
                submit: "submit";
                readonly: "readonly";
                search: "search";
                navigation: "navigation";
                disclosure: "disclosure";
            }>>;
            approval: z.ZodOptional<z.ZodArray<z.ZodEnum<{
                click: "click";
                fill: "fill";
                select: "select";
            }>>>;
            options: z.ZodOptional<z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                value: z.ZodString;
            }, z.core.$strip>>>;
        }, z.core.$strip>>;
        records: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            name: z.ZodString;
            type: z.ZodString;
            version: z.ZodString;
            description: z.ZodString;
            tags: z.ZodArray<z.ZodString>;
            actions: z.ZodArray<z.ZodObject<{
                ref: z.ZodString;
                label: z.ZodString;
            }, z.core.$strip>>;
        }, z.core.$strip>>;
        document: z.ZodOptional<z.ZodObject<{
            blocks: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
                kind: z.ZodLiteral<"fields">;
                title: z.ZodString;
                fields: z.ZodArray<z.ZodObject<{
                    label: z.ZodString;
                    kind: z.ZodEnum<{
                        number: "number";
                        text: "text";
                        multiline: "multiline";
                        choice: "choice";
                        toggle: "toggle";
                    }>;
                    state: z.ZodEnum<{
                        value: "value";
                        empty: "empty";
                        unread: "unread";
                        redacted: "redacted";
                    }>;
                    value: z.ZodString;
                    checked: z.ZodOptional<z.ZodEnum<{
                        on: "on";
                        off: "off";
                        mixed: "mixed";
                    }>>;
                }, z.core.$strip>>;
            }, z.core.$strip>, z.ZodObject<{
                kind: z.ZodLiteral<"table">;
                title: z.ZodString;
                columns: z.ZodArray<z.ZodString>;
                rows: z.ZodArray<z.ZodArray<z.ZodString>>;
            }, z.core.$strip>, z.ZodObject<{
                kind: z.ZodLiteral<"list">;
                title: z.ZodString;
                items: z.ZodArray<z.ZodString>;
            }, z.core.$strip>, z.ZodObject<{
                kind: z.ZodLiteral<"text">;
                title: z.ZodString;
                text: z.ZodString;
            }, z.core.$strip>], "kind">>;
            gaps: z.ZodArray<z.ZodObject<{
                kind: z.ZodEnum<{
                    unread: "unread";
                    collapsed: "collapsed";
                    graphic: "graphic";
                    embedded: "embedded";
                    editor: "editor";
                    unstructured: "unstructured";
                    limit: "limit";
                }>;
                label: z.ZodString;
            }, z.core.$strip>>;
            truncated: z.ZodBoolean;
        }, z.core.$strip>>;
        capturedAt: z.ZodString;
        truncated: z.ZodBoolean;
        recordsState: z.ZodDefault<z.ZodEnum<{
            empty: "empty";
            unavailable: "unavailable";
            loading: "loading";
            ready: "ready";
        }>>;
    }, z.core.$strip>>;
    selected: z.ZodOptional<z.ZodObject<{
        id: z.ZodString;
        name: z.ZodString;
        type: z.ZodString;
        version: z.ZodString;
        description: z.ZodString;
        tags: z.ZodArray<z.ZodString>;
        actions: z.ZodArray<z.ZodObject<{
            ref: z.ZodString;
            label: z.ZodString;
        }, z.core.$strip>>;
    }, z.core.$strip>>;
    executionModes: z.ZodDefault<z.ZodArray<z.ZodEnum<{
        debug: "debug";
        use: "use";
    }>>>;
    question: z.ZodOptional<z.ZodObject<{
        id: z.ZodString;
        title: z.ZodString;
        fields: z.ZodArray<z.ZodObject<{
            name: z.ZodString;
            label: z.ZodString;
            required: z.ZodDefault<z.ZodBoolean>;
            type: z.ZodDefault<z.ZodEnum<{
                text: "text";
                textarea: "textarea";
            }>>;
        }, z.core.$strip>>;
    }, z.core.$strip>>;
    selectedId: z.ZodOptional<z.ZodString>;
    review: z.ZodOptional<z.ZodObject<{
        id: z.ZodString;
        action: z.ZodEnum<{
            click: "click";
            fill: "fill";
            select: "select";
        }>;
        label: z.ZodString;
        url: z.ZodString;
        pageTitle: z.ZodString;
        expiresAt: z.ZodString;
        before: z.ZodOptional<z.ZodString>;
        after: z.ZodOptional<z.ZodString>;
        fields: z.ZodArray<z.ZodObject<{
            label: z.ZodString;
            kind: z.ZodEnum<{
                number: "number";
                text: "text";
                multiline: "multiline";
                choice: "choice";
                toggle: "toggle";
            }>;
            state: z.ZodEnum<{
                value: "value";
                empty: "empty";
                unread: "unread";
                redacted: "redacted";
            }>;
            value: z.ZodString;
            checked: z.ZodOptional<z.ZodEnum<{
                on: "on";
                off: "off";
                mixed: "mixed";
            }>>;
        }, z.core.$strip>>;
        fieldsLimited: z.ZodBoolean;
        target: z.ZodObject<{
            left: z.ZodNumber;
            top: z.ZodNumber;
            width: z.ZodNumber;
            height: z.ZodNumber;
        }, z.core.$strip>;
    }, z.core.$strip>>;
    approvalEnabled: z.ZodOptional<z.ZodBoolean>;
    humanReason: z.ZodOptional<z.ZodEnum<{
        login: "login";
        requested: "requested";
    }>>;
    blockedOrigin: z.ZodOptional<z.ZodString>;
    error: z.ZodOptional<z.ZodString>;
    agentRunning: z.ZodDefault<z.ZodBoolean>;
    browserReady: z.ZodBoolean;
    revision: z.ZodNumber;
    generation: z.ZodOptional<z.ZodString>;
}, z.core.$strip>;
export type AgentState = z.infer<typeof AgentState>;
export declare function latestAgentState(previous: AgentState | undefined, next: AgentState): AgentState;
export declare const BrowserArgs: z.ZodObject<{
    action: z.ZodEnum<{
        submit: "submit";
        click: "click";
        fill: "fill";
        select: "select";
        open: "open";
        observe: "observe";
        press: "press";
        wait: "wait";
        back: "back";
        scroll: "scroll";
    }>;
    url: z.ZodOptional<z.ZodString>;
    observation_id: z.ZodOptional<z.ZodString>;
    ref: z.ZodOptional<z.ZodString>;
    text: z.ZodOptional<z.ZodString>;
    request_id: z.ZodOptional<z.ZodString>;
    delta: z.ZodOptional<z.ZodNumber>;
}, z.core.$strict>;
export type BrowserArgs = z.infer<typeof BrowserArgs>;
export declare const HumanInput: z.ZodDiscriminatedUnion<[z.ZodObject<{
    kind: z.ZodLiteral<"click">;
    x: z.ZodNumber;
    y: z.ZodNumber;
}, z.core.$strict>, z.ZodObject<{
    kind: z.ZodLiteral<"text">;
    text: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    kind: z.ZodLiteral<"key">;
    key: z.ZodEnum<{
        Enter: "Enter";
        Tab: "Tab";
        Backspace: "Backspace";
        Delete: "Delete";
        Escape: "Escape";
        ArrowLeft: "ArrowLeft";
        ArrowRight: "ArrowRight";
        ArrowUp: "ArrowUp";
        ArrowDown: "ArrowDown";
        Home: "Home";
        End: "End";
        "ControlOrMeta+A": "ControlOrMeta+A";
    }>;
}, z.core.$strict>, z.ZodObject<{
    kind: z.ZodLiteral<"scroll">;
    delta: z.ZodNumber;
}, z.core.$strict>], "kind">;
export type HumanInput = z.infer<typeof HumanInput>;
export interface AgentRemote {
    state(sessionId: string, signal?: AbortSignal): Promise<AgentState>;
    call(method: string, payload: unknown, signal?: AbortSignal): Promise<unknown>;
    frame(sessionId: string, signal: AbortSignal, approvalId?: string): Promise<Blob>;
}
