import type { Page } from 'playwright';
import type { ActionReview, BrowserArgs } from './agent-contract.js';
import type { observePage } from './page-observation.js';
type Snapshot = ReturnType<typeof observePage>;
type Target = Snapshot['controls'][number];
type ReviewedAction = ActionReview['action'];
/** Owns a single, transient approval. Only the owner RPC can consume it. */
export declare class Approvals {
    private pending;
    get review(): ActionReview | undefined;
    frame(id: string): Buffer;
    prepare(page: Page, target: Target, action: ReviewedAction, args: BrowserArgs, snapshot: () => Promise<Snapshot>, masks: string[]): Promise<void>;
    private evidence;
    apply(id: string, page: Page, snapshot: () => Promise<Snapshot>, signal: AbortSignal): Promise<void>;
    clear(id?: string): Promise<void>;
}
export {};
