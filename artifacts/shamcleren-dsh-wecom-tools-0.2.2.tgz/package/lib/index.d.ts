import type { Context } from '@deepseek-ai/cordis';
export declare const name = "wecom-tools";
export declare const inject: string[];
/** Mount the pinned WeCom Unified Skill as a bundled, read-only provider. */
export declare function apply(ctx: Context): void;
