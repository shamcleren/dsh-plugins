window.__ModuleLoader__.load({
	id: "@shamcleren/dsh-plugin-marketplace",
	factory: (require) => {
		var module = { exports: {} };
		var exports = module.exports;
		Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
		//#region \0rolldown/runtime.js
		var __commonJSMin = (cb, mod) => () => (mod || (cb((mod = { exports: {} }).exports, mod), cb = null), mod.exports);
		//#endregion
		let react = require("react");
		let react_jsx_runtime = require("react/jsx-runtime");
		//#region ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/internal/constants.js
		var require_constants = /* @__PURE__ */ __commonJSMin(((exports, module) => {
			module.exports = {
				MAX_LENGTH: 256,
				MAX_SAFE_COMPONENT_LENGTH: 16,
				MAX_SAFE_BUILD_LENGTH: 250,
				MAX_SAFE_INTEGER: Number.MAX_SAFE_INTEGER || 
				/* istanbul ignore next */ 9007199254740991,
				RELEASE_TYPES: [
					"major",
					"premajor",
					"minor",
					"preminor",
					"patch",
					"prepatch",
					"prerelease"
				],
				SEMVER_SPEC_VERSION: "2.0.0",
				FLAG_INCLUDE_PRERELEASE: 1,
				FLAG_LOOSE: 2
			};
		}));
		//#endregion
		//#region ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/internal/debug.js
		var require_debug = /* @__PURE__ */ __commonJSMin(((exports, module) => {
			module.exports = typeof process === "object" && process.env && process.env.NODE_DEBUG && /\bsemver\b/i.test(process.env.NODE_DEBUG) ? (...args) => console.error("SEMVER", ...args) : () => {};
		}));
		//#endregion
		//#region ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/internal/re.js
		var require_re = /* @__PURE__ */ __commonJSMin(((exports, module) => {
			const { MAX_SAFE_COMPONENT_LENGTH, MAX_SAFE_BUILD_LENGTH, MAX_LENGTH } = require_constants();
			const debug = require_debug();
			exports = module.exports = {};
			const re = exports.re = [];
			const safeRe = exports.safeRe = [];
			const src = exports.src = [];
			const safeSrc = exports.safeSrc = [];
			const t = exports.t = {};
			let R = 0;
			const LETTERDASHNUMBER = "[a-zA-Z0-9-]";
			const safeRegexReplacements = [
				["\\s", 1],
				["\\d", MAX_LENGTH],
				[LETTERDASHNUMBER, MAX_SAFE_BUILD_LENGTH]
			];
			const makeSafeRegex = (value) => {
				for (const [token, max] of safeRegexReplacements) value = value.split(`${token}*`).join(`${token}{0,${max}}`).split(`${token}+`).join(`${token}{1,${max}}`);
				return value;
			};
			const createToken = (name, value, isGlobal) => {
				const safe = makeSafeRegex(value);
				const index = R++;
				debug(name, index, value);
				t[name] = index;
				src[index] = value;
				safeSrc[index] = safe;
				re[index] = new RegExp(value, isGlobal ? "g" : void 0);
				safeRe[index] = new RegExp(safe, isGlobal ? "g" : void 0);
			};
			createToken("NUMERICIDENTIFIER", "0|[1-9]\\d*");
			createToken("NUMERICIDENTIFIERLOOSE", "\\d+");
			createToken("NONNUMERICIDENTIFIER", `\\d*[a-zA-Z-]${LETTERDASHNUMBER}*`);
			createToken("MAINVERSION", `(${src[t.NUMERICIDENTIFIER]})\\.(${src[t.NUMERICIDENTIFIER]})\\.(${src[t.NUMERICIDENTIFIER]})`);
			createToken("MAINVERSIONLOOSE", `(${src[t.NUMERICIDENTIFIERLOOSE]})\\.(${src[t.NUMERICIDENTIFIERLOOSE]})\\.(${src[t.NUMERICIDENTIFIERLOOSE]})`);
			createToken("PRERELEASEIDENTIFIER", `(?:${src[t.NONNUMERICIDENTIFIER]}|${src[t.NUMERICIDENTIFIER]})`);
			createToken("PRERELEASEIDENTIFIERLOOSE", `(?:${src[t.NONNUMERICIDENTIFIER]}|${src[t.NUMERICIDENTIFIERLOOSE]})`);
			createToken("PRERELEASE", `(?:-(${src[t.PRERELEASEIDENTIFIER]}(?:\\.${src[t.PRERELEASEIDENTIFIER]})*))`);
			createToken("PRERELEASELOOSE", `(?:-?(${src[t.PRERELEASEIDENTIFIERLOOSE]}(?:\\.${src[t.PRERELEASEIDENTIFIERLOOSE]})*))`);
			createToken("BUILDIDENTIFIER", `${LETTERDASHNUMBER}+`);
			createToken("BUILD", `(?:\\+(${src[t.BUILDIDENTIFIER]}(?:\\.${src[t.BUILDIDENTIFIER]})*))`);
			createToken("FULLPLAIN", `v?${src[t.MAINVERSION]}${src[t.PRERELEASE]}?${src[t.BUILD]}?`);
			createToken("FULL", `^${src[t.FULLPLAIN]}$`);
			createToken("LOOSEPLAIN", `[v=\\s]*${src[t.MAINVERSIONLOOSE]}${src[t.PRERELEASELOOSE]}?${src[t.BUILD]}?`);
			createToken("LOOSE", `^${src[t.LOOSEPLAIN]}$`);
			createToken("GTLT", "((?:<|>)?=?)");
			createToken("XRANGEIDENTIFIERLOOSE", `${src[t.NUMERICIDENTIFIERLOOSE]}|x|X|\\*`);
			createToken("XRANGEIDENTIFIER", `${src[t.NUMERICIDENTIFIER]}|x|X|\\*`);
			createToken("XRANGEPLAIN", `[v=\\s]*(${src[t.XRANGEIDENTIFIER]})(?:\\.(${src[t.XRANGEIDENTIFIER]})(?:\\.(${src[t.XRANGEIDENTIFIER]})(?:${src[t.PRERELEASE]})?${src[t.BUILD]}?)?)?`);
			createToken("XRANGEPLAINLOOSE", `[v=\\s]*(${src[t.XRANGEIDENTIFIERLOOSE]})(?:\\.(${src[t.XRANGEIDENTIFIERLOOSE]})(?:\\.(${src[t.XRANGEIDENTIFIERLOOSE]})(?:${src[t.PRERELEASELOOSE]})?${src[t.BUILD]}?)?)?`);
			createToken("XRANGE", `^${src[t.GTLT]}\\s*${src[t.XRANGEPLAIN]}$`);
			createToken("XRANGELOOSE", `^${src[t.GTLT]}\\s*${src[t.XRANGEPLAINLOOSE]}$`);
			createToken("COERCEPLAIN", `(^|[^\\d])(\\d{1,${MAX_SAFE_COMPONENT_LENGTH}})(?:\\.(\\d{1,${MAX_SAFE_COMPONENT_LENGTH}}))?(?:\\.(\\d{1,${MAX_SAFE_COMPONENT_LENGTH}}))?`);
			createToken("COERCE", `${src[t.COERCEPLAIN]}(?:$|[^\\d])`);
			createToken("COERCEFULL", src[t.COERCEPLAIN] + `(?:${src[t.PRERELEASE]})?(?:${src[t.BUILD]})?(?:$|[^\\d])`);
			createToken("COERCERTL", src[t.COERCE], true);
			createToken("COERCERTLFULL", src[t.COERCEFULL], true);
			createToken("LONETILDE", "(?:~>?)");
			createToken("TILDETRIM", `(\\s*)${src[t.LONETILDE]}\\s+`, true);
			exports.tildeTrimReplace = "$1~";
			createToken("TILDE", `^${src[t.LONETILDE]}${src[t.XRANGEPLAIN]}$`);
			createToken("TILDELOOSE", `^${src[t.LONETILDE]}${src[t.XRANGEPLAINLOOSE]}$`);
			createToken("LONECARET", "(?:\\^)");
			createToken("CARETTRIM", `(\\s*)${src[t.LONECARET]}\\s+`, true);
			exports.caretTrimReplace = "$1^";
			createToken("CARET", `^${src[t.LONECARET]}${src[t.XRANGEPLAIN]}$`);
			createToken("CARETLOOSE", `^${src[t.LONECARET]}${src[t.XRANGEPLAINLOOSE]}$`);
			createToken("COMPARATORLOOSE", `^${src[t.GTLT]}\\s*(${src[t.LOOSEPLAIN]})$|^$`);
			createToken("COMPARATOR", `^${src[t.GTLT]}\\s*(${src[t.FULLPLAIN]})$|^$`);
			createToken("COMPARATORTRIM", `(\\s*)${src[t.GTLT]}\\s*(${src[t.LOOSEPLAIN]}|${src[t.XRANGEPLAIN]})`, true);
			exports.comparatorTrimReplace = "$1$2$3";
			createToken("HYPHENRANGE", `^\\s*(${src[t.XRANGEPLAIN]})\\s+-\\s+(${src[t.XRANGEPLAIN]})\\s*$`);
			createToken("HYPHENRANGELOOSE", `^\\s*(${src[t.XRANGEPLAINLOOSE]})\\s+-\\s+(${src[t.XRANGEPLAINLOOSE]})\\s*$`);
			createToken("STAR", "(<|>)?=?\\s*\\*");
			createToken("GTE0", "^\\s*>=\\s*0\\.0\\.0\\s*$");
			createToken("GTE0PRE", "^\\s*>=\\s*0\\.0\\.0-0\\s*$");
		}));
		//#endregion
		//#region ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/internal/parse-options.js
		var require_parse_options = /* @__PURE__ */ __commonJSMin(((exports, module) => {
			const looseOption = Object.freeze({ loose: true });
			const emptyOpts = Object.freeze({});
			const parseOptions = (options) => {
				if (!options) return emptyOpts;
				if (typeof options !== "object") return looseOption;
				return options;
			};
			module.exports = parseOptions;
		}));
		//#endregion
		//#region ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/internal/identifiers.js
		var require_identifiers = /* @__PURE__ */ __commonJSMin(((exports, module) => {
			const numeric = /^[0-9]+$/;
			const compareIdentifiers = (a, b) => {
				if (typeof a === "number" && typeof b === "number") return a === b ? 0 : a < b ? -1 : 1;
				const anum = numeric.test(a);
				const bnum = numeric.test(b);
				if (anum && bnum) {
					a = +a;
					b = +b;
				}
				return a === b ? 0 : anum && !bnum ? -1 : bnum && !anum ? 1 : a < b ? -1 : 1;
			};
			const rcompareIdentifiers = (a, b) => compareIdentifiers(b, a);
			module.exports = {
				compareIdentifiers,
				rcompareIdentifiers
			};
		}));
		//#endregion
		//#region ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/classes/semver.js
		var require_semver$1 = /* @__PURE__ */ __commonJSMin(((exports, module) => {
			const debug = require_debug();
			const { MAX_LENGTH, MAX_SAFE_INTEGER } = require_constants();
			const { safeRe: re, t } = require_re();
			const parseOptions = require_parse_options();
			const { compareIdentifiers } = require_identifiers();
			const isPrereleaseIdentifier = (prerelease, identifier) => {
				const identifiers = identifier.split(".");
				if (identifiers.length > prerelease.length) return false;
				for (let i = 0; i < identifiers.length; i++) if (compareIdentifiers(prerelease[i], identifiers[i]) !== 0) return false;
				return true;
			};
			module.exports = class SemVer {
				constructor(version, options) {
					options = parseOptions(options);
					if (version instanceof SemVer) {
						if (version.loose === !!options.loose && version.includePrerelease === !!options.includePrerelease) return version;
						else version = version.version;
					} else if (typeof version !== "string") throw new TypeError(`Invalid version. Must be a string. Got type "${typeof version}".`);
					if (version.length > MAX_LENGTH) throw new TypeError(`version is longer than ${MAX_LENGTH} characters`);
					debug("SemVer", version, options);
					this.options = options;
					this.loose = !!options.loose;
					this.includePrerelease = !!options.includePrerelease;
					const m = version.trim().match(options.loose ? re[t.LOOSE] : re[t.FULL]);
					if (!m) throw new TypeError(`Invalid Version: ${version}`);
					this.raw = version;
					this.major = +m[1];
					this.minor = +m[2];
					this.patch = +m[3];
					if (this.major > MAX_SAFE_INTEGER || this.major < 0) throw new TypeError("Invalid major version");
					if (this.minor > MAX_SAFE_INTEGER || this.minor < 0) throw new TypeError("Invalid minor version");
					if (this.patch > MAX_SAFE_INTEGER || this.patch < 0) throw new TypeError("Invalid patch version");
					if (!m[4]) this.prerelease = [];
					else this.prerelease = m[4].split(".").map((id) => {
						if (/^[0-9]+$/.test(id)) {
							const num = +id;
							if (num >= 0 && num < MAX_SAFE_INTEGER) return num;
						}
						return id;
					});
					this.build = m[5] ? m[5].split(".") : [];
					this.format();
				}
				format() {
					this.version = `${this.major}.${this.minor}.${this.patch}`;
					if (this.prerelease.length) this.version += `-${this.prerelease.join(".")}`;
					return this.version;
				}
				toString() {
					return this.version;
				}
				compare(other) {
					debug("SemVer.compare", this.version, this.options, other);
					if (!(other instanceof SemVer)) {
						if (typeof other === "string" && other === this.version) return 0;
						other = new SemVer(other, this.options);
					}
					if (other.version === this.version) return 0;
					return this.compareMain(other) || this.comparePre(other);
				}
				compareMain(other) {
					if (!(other instanceof SemVer)) other = new SemVer(other, this.options);
					if (this.major < other.major) return -1;
					if (this.major > other.major) return 1;
					if (this.minor < other.minor) return -1;
					if (this.minor > other.minor) return 1;
					if (this.patch < other.patch) return -1;
					if (this.patch > other.patch) return 1;
					return 0;
				}
				comparePre(other) {
					if (!(other instanceof SemVer)) other = new SemVer(other, this.options);
					if (this.prerelease.length && !other.prerelease.length) return -1;
					else if (!this.prerelease.length && other.prerelease.length) return 1;
					else if (!this.prerelease.length && !other.prerelease.length) return 0;
					let i = 0;
					do {
						const a = this.prerelease[i];
						const b = other.prerelease[i];
						debug("prerelease compare", i, a, b);
						if (a === void 0 && b === void 0) return 0;
						else if (b === void 0) return 1;
						else if (a === void 0) return -1;
						else if (a === b) continue;
						else return compareIdentifiers(a, b);
					} while (++i);
				}
				compareBuild(other) {
					if (!(other instanceof SemVer)) other = new SemVer(other, this.options);
					let i = 0;
					do {
						const a = this.build[i];
						const b = other.build[i];
						debug("build compare", i, a, b);
						if (a === void 0 && b === void 0) return 0;
						else if (b === void 0) return 1;
						else if (a === void 0) return -1;
						else if (a === b) continue;
						else return compareIdentifiers(a, b);
					} while (++i);
				}
				inc(release, identifier, identifierBase) {
					if (release.startsWith("pre")) {
						if (!identifier && identifierBase === false) throw new Error("invalid increment argument: identifier is empty");
						if (identifier) {
							const match = `-${identifier}`.match(this.options.loose ? re[t.PRERELEASELOOSE] : re[t.PRERELEASE]);
							if (!match || match[1] !== identifier) throw new Error(`invalid identifier: ${identifier}`);
						}
					}
					switch (release) {
						case "premajor":
							this.prerelease.length = 0;
							this.patch = 0;
							this.minor = 0;
							this.major++;
							this.inc("pre", identifier, identifierBase);
							break;
						case "preminor":
							this.prerelease.length = 0;
							this.patch = 0;
							this.minor++;
							this.inc("pre", identifier, identifierBase);
							break;
						case "prepatch":
							this.prerelease.length = 0;
							this.inc("patch", identifier, identifierBase);
							this.inc("pre", identifier, identifierBase);
							break;
						case "prerelease":
							if (this.prerelease.length === 0) this.inc("patch", identifier, identifierBase);
							this.inc("pre", identifier, identifierBase);
							break;
						case "release":
							if (this.prerelease.length === 0) throw new Error(`version ${this.raw} is not a prerelease`);
							this.prerelease.length = 0;
							break;
						case "major":
							if (this.minor !== 0 || this.patch !== 0 || this.prerelease.length === 0) this.major++;
							this.minor = 0;
							this.patch = 0;
							this.prerelease = [];
							break;
						case "minor":
							if (this.patch !== 0 || this.prerelease.length === 0) this.minor++;
							this.patch = 0;
							this.prerelease = [];
							break;
						case "patch":
							if (this.prerelease.length === 0) this.patch++;
							this.prerelease = [];
							break;
						case "pre": {
							const base = Number(identifierBase) ? 1 : 0;
							if (this.prerelease.length === 0) this.prerelease = [base];
							else {
								let i = this.prerelease.length;
								while (--i >= 0) if (typeof this.prerelease[i] === "number") {
									this.prerelease[i]++;
									i = -2;
								}
								if (i === -1) {
									if (identifier === this.prerelease.join(".") && identifierBase === false) throw new Error("invalid increment argument: identifier already exists");
									this.prerelease.push(base);
								}
							}
							if (identifier) {
								let prerelease = [identifier, base];
								if (identifierBase === false) prerelease = [identifier];
								if (isPrereleaseIdentifier(this.prerelease, identifier)) {
									const prereleaseBase = this.prerelease[identifier.split(".").length];
									if (isNaN(prereleaseBase)) this.prerelease = prerelease;
								} else this.prerelease = prerelease;
							}
							break;
						}
						default: throw new Error(`invalid increment argument: ${release}`);
					}
					this.raw = this.format();
					if (this.build.length) this.raw += `+${this.build.join(".")}`;
					return this;
				}
			};
		}));
		//#endregion
		//#region ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/parse.js
		var require_parse = /* @__PURE__ */ __commonJSMin(((exports, module) => {
			const SemVer = require_semver$1();
			const parse = (version, options, throwErrors = false) => {
				if (version instanceof SemVer) return version;
				try {
					return new SemVer(version, options);
				} catch (er) {
					if (!throwErrors) return null;
					throw er;
				}
			};
			module.exports = parse;
		}));
		//#endregion
		//#region ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/valid.js
		var require_valid$1 = /* @__PURE__ */ __commonJSMin(((exports, module) => {
			const parse = require_parse();
			const valid = (version, options) => {
				const v = parse(version, options);
				return v ? v.version : null;
			};
			module.exports = valid;
		}));
		//#endregion
		//#region ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/clean.js
		var require_clean = /* @__PURE__ */ __commonJSMin(((exports, module) => {
			const parse = require_parse();
			const clean = (version, options) => {
				const s = parse(version.trim().replace(/^[=v]+/, ""), options);
				return s ? s.version : null;
			};
			module.exports = clean;
		}));
		//#endregion
		//#region ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/inc.js
		var require_inc = /* @__PURE__ */ __commonJSMin(((exports, module) => {
			const SemVer = require_semver$1();
			const inc = (version, release, options, identifier, identifierBase) => {
				if (typeof options === "string") {
					identifierBase = identifier;
					identifier = options;
					options = void 0;
				}
				try {
					return new SemVer(version instanceof SemVer ? version.version : version, options).inc(release, identifier, identifierBase).version;
				} catch (er) {
					return null;
				}
			};
			module.exports = inc;
		}));
		//#endregion
		//#region ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/diff.js
		var require_diff = /* @__PURE__ */ __commonJSMin(((exports, module) => {
			const parse = require_parse();
			const diff = (version1, version2) => {
				const v1 = parse(version1, null, true);
				const v2 = parse(version2, null, true);
				const comparison = v1.compare(v2);
				if (comparison === 0) return null;
				const v1Higher = comparison > 0;
				const highVersion = v1Higher ? v1 : v2;
				const lowVersion = v1Higher ? v2 : v1;
				const highHasPre = !!highVersion.prerelease.length;
				if (!!lowVersion.prerelease.length && !highHasPre) {
					if (!lowVersion.patch && !lowVersion.minor) return "major";
					if (lowVersion.compareMain(highVersion) === 0) {
						if (lowVersion.minor && !lowVersion.patch) return "minor";
						return "patch";
					}
				}
				const prefix = highHasPre ? "pre" : "";
				if (v1.major !== v2.major) return prefix + "major";
				if (v1.minor !== v2.minor) return prefix + "minor";
				if (v1.patch !== v2.patch) return prefix + "patch";
				return "prerelease";
			};
			module.exports = diff;
		}));
		//#endregion
		//#region ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/major.js
		var require_major = /* @__PURE__ */ __commonJSMin(((exports, module) => {
			const SemVer = require_semver$1();
			const major = (a, loose) => new SemVer(a, loose).major;
			module.exports = major;
		}));
		//#endregion
		//#region ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/minor.js
		var require_minor = /* @__PURE__ */ __commonJSMin(((exports, module) => {
			const SemVer = require_semver$1();
			const minor = (a, loose) => new SemVer(a, loose).minor;
			module.exports = minor;
		}));
		//#endregion
		//#region ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/patch.js
		var require_patch = /* @__PURE__ */ __commonJSMin(((exports, module) => {
			const SemVer = require_semver$1();
			const patch = (a, loose) => new SemVer(a, loose).patch;
			module.exports = patch;
		}));
		//#endregion
		//#region ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/prerelease.js
		var require_prerelease = /* @__PURE__ */ __commonJSMin(((exports, module) => {
			const parse = require_parse();
			const prerelease = (version, options) => {
				const parsed = parse(version, options);
				return parsed && parsed.prerelease.length ? parsed.prerelease : null;
			};
			module.exports = prerelease;
		}));
		//#endregion
		//#region ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/compare.js
		var require_compare = /* @__PURE__ */ __commonJSMin(((exports, module) => {
			const SemVer = require_semver$1();
			const compare = (a, b, loose) => new SemVer(a, loose).compare(new SemVer(b, loose));
			module.exports = compare;
		}));
		//#endregion
		//#region ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/rcompare.js
		var require_rcompare = /* @__PURE__ */ __commonJSMin(((exports, module) => {
			const compare = require_compare();
			const rcompare = (a, b, loose) => compare(b, a, loose);
			module.exports = rcompare;
		}));
		//#endregion
		//#region ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/compare-loose.js
		var require_compare_loose = /* @__PURE__ */ __commonJSMin(((exports, module) => {
			const compare = require_compare();
			const compareLoose = (a, b) => compare(a, b, true);
			module.exports = compareLoose;
		}));
		//#endregion
		//#region ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/compare-build.js
		var require_compare_build = /* @__PURE__ */ __commonJSMin(((exports, module) => {
			const SemVer = require_semver$1();
			const compareBuild = (a, b, loose) => {
				const versionA = new SemVer(a, loose);
				const versionB = new SemVer(b, loose);
				return versionA.compare(versionB) || versionA.compareBuild(versionB);
			};
			module.exports = compareBuild;
		}));
		//#endregion
		//#region ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/sort.js
		var require_sort = /* @__PURE__ */ __commonJSMin(((exports, module) => {
			const compareBuild = require_compare_build();
			const sort = (list, loose) => list.sort((a, b) => compareBuild(a, b, loose));
			module.exports = sort;
		}));
		//#endregion
		//#region ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/rsort.js
		var require_rsort = /* @__PURE__ */ __commonJSMin(((exports, module) => {
			const compareBuild = require_compare_build();
			const rsort = (list, loose) => list.sort((a, b) => compareBuild(b, a, loose));
			module.exports = rsort;
		}));
		//#endregion
		//#region ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/gt.js
		var require_gt = /* @__PURE__ */ __commonJSMin(((exports, module) => {
			const compare = require_compare();
			const gt = (a, b, loose) => compare(a, b, loose) > 0;
			module.exports = gt;
		}));
		//#endregion
		//#region ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/lt.js
		var require_lt = /* @__PURE__ */ __commonJSMin(((exports, module) => {
			const compare = require_compare();
			const lt = (a, b, loose) => compare(a, b, loose) < 0;
			module.exports = lt;
		}));
		//#endregion
		//#region ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/eq.js
		var require_eq = /* @__PURE__ */ __commonJSMin(((exports, module) => {
			const compare = require_compare();
			const eq = (a, b, loose) => compare(a, b, loose) === 0;
			module.exports = eq;
		}));
		//#endregion
		//#region ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/neq.js
		var require_neq = /* @__PURE__ */ __commonJSMin(((exports, module) => {
			const compare = require_compare();
			const neq = (a, b, loose) => compare(a, b, loose) !== 0;
			module.exports = neq;
		}));
		//#endregion
		//#region ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/gte.js
		var require_gte = /* @__PURE__ */ __commonJSMin(((exports, module) => {
			const compare = require_compare();
			const gte = (a, b, loose) => compare(a, b, loose) >= 0;
			module.exports = gte;
		}));
		//#endregion
		//#region ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/lte.js
		var require_lte = /* @__PURE__ */ __commonJSMin(((exports, module) => {
			const compare = require_compare();
			const lte = (a, b, loose) => compare(a, b, loose) <= 0;
			module.exports = lte;
		}));
		//#endregion
		//#region ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/cmp.js
		var require_cmp = /* @__PURE__ */ __commonJSMin(((exports, module) => {
			const eq = require_eq();
			const neq = require_neq();
			const gt = require_gt();
			const gte = require_gte();
			const lt = require_lt();
			const lte = require_lte();
			const cmp = (a, op, b, loose) => {
				switch (op) {
					case "===":
						if (typeof a === "object") a = a.version;
						if (typeof b === "object") b = b.version;
						return a === b;
					case "!==":
						if (typeof a === "object") a = a.version;
						if (typeof b === "object") b = b.version;
						return a !== b;
					case "":
					case "=":
					case "==": return eq(a, b, loose);
					case "!=": return neq(a, b, loose);
					case ">": return gt(a, b, loose);
					case ">=": return gte(a, b, loose);
					case "<": return lt(a, b, loose);
					case "<=": return lte(a, b, loose);
					default: throw new TypeError(`Invalid operator: ${op}`);
				}
			};
			module.exports = cmp;
		}));
		//#endregion
		//#region ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/coerce.js
		var require_coerce = /* @__PURE__ */ __commonJSMin(((exports, module) => {
			const SemVer = require_semver$1();
			const parse = require_parse();
			const { safeRe: re, t } = require_re();
			const coerce = (version, options) => {
				if (version instanceof SemVer) return version;
				if (typeof version === "number") version = String(version);
				if (typeof version !== "string") return null;
				options = options || {};
				let match = null;
				if (!options.rtl) match = version.match(options.includePrerelease ? re[t.COERCEFULL] : re[t.COERCE]);
				else {
					const coerceRtlRegex = options.includePrerelease ? re[t.COERCERTLFULL] : re[t.COERCERTL];
					let next;
					while ((next = coerceRtlRegex.exec(version)) && (!match || match.index + match[0].length !== version.length)) {
						if (!match || next.index + next[0].length !== match.index + match[0].length) match = next;
						coerceRtlRegex.lastIndex = next.index + next[1].length + next[2].length;
					}
					coerceRtlRegex.lastIndex = -1;
				}
				if (match === null) return null;
				const major = match[2];
				const minor = match[3] || "0";
				const patch = match[4] || "0";
				const prerelease = options.includePrerelease && match[5] ? `-${match[5]}` : "";
				const build = options.includePrerelease && match[6] ? `+${match[6]}` : "";
				return parse(`${major}.${minor}.${patch}${prerelease}${build}`, options);
			};
			module.exports = coerce;
		}));
		//#endregion
		//#region ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/truncate.js
		var require_truncate = /* @__PURE__ */ __commonJSMin(((exports, module) => {
			const parse = require_parse();
			const constants = require_constants();
			const SemVer = require_semver$1();
			const truncate = (version, truncation, options) => {
				if (!constants.RELEASE_TYPES.includes(truncation)) return null;
				const clonedVersion = cloneInputVersion(version, options);
				return clonedVersion && doTruncation(clonedVersion, truncation);
			};
			const cloneInputVersion = (version, options) => {
				const versionStringToParse = version instanceof SemVer ? version.version : version;
				return parse(versionStringToParse, options);
			};
			const doTruncation = (version, truncation) => {
				if (isPrerelease(truncation)) return version.version;
				version.prerelease = [];
				switch (truncation) {
					case "major":
						version.minor = 0;
						version.patch = 0;
						break;
					case "minor": version.patch = 0;
				}
				return version.format();
			};
			const isPrerelease = (type) => {
				return type.startsWith("pre");
			};
			module.exports = truncate;
		}));
		//#endregion
		//#region ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/internal/lrucache.js
		var require_lrucache = /* @__PURE__ */ __commonJSMin(((exports, module) => {
			var LRUCache = class {
				constructor() {
					this.max = 1e3;
					this.map = /* @__PURE__ */ new Map();
				}
				get(key) {
					const value = this.map.get(key);
					if (value === void 0) return;
					else {
						this.map.delete(key);
						this.map.set(key, value);
						return value;
					}
				}
				delete(key) {
					return this.map.delete(key);
				}
				set(key, value) {
					if (!this.delete(key) && value !== void 0) {
						if (this.map.size >= this.max) {
							const firstKey = this.map.keys().next().value;
							this.delete(firstKey);
						}
						this.map.set(key, value);
					}
					return this;
				}
			};
			module.exports = LRUCache;
		}));
		//#endregion
		//#region ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/classes/range.js
		var require_range = /* @__PURE__ */ __commonJSMin(((exports, module) => {
			const SPACE_CHARACTERS = /\s+/g;
			module.exports = class Range {
				constructor(range, options) {
					options = parseOptions(options);
					if (range instanceof Range) {
						if (range.loose === !!options.loose && range.includePrerelease === !!options.includePrerelease) return range;
						else return new Range(range.raw, options);
					}
					if (range instanceof Comparator) {
						this.raw = range.value;
						this.set = [[range]];
						this.formatted = void 0;
						return this;
					}
					this.options = options;
					this.loose = !!options.loose;
					this.includePrerelease = !!options.includePrerelease;
					this.raw = range.trim().replace(SPACE_CHARACTERS, " ");
					this.set = this.raw.split("||").map((r) => this.parseRange(r.trim())).filter((c) => c.length);
					if (!this.set.length) throw new TypeError(`Invalid SemVer Range: ${this.raw}`);
					if (this.set.length > 1) {
						const first = this.set[0];
						this.set = this.set.filter((c) => !isNullSet(c[0]));
						if (this.set.length === 0) this.set = [first];
						else if (this.set.length > 1) {
							for (const c of this.set) if (c.length === 1 && isAny(c[0])) {
								this.set = [c];
								break;
							}
						}
					}
					this.formatted = void 0;
				}
				get range() {
					if (this.formatted === void 0) {
						this.formatted = "";
						for (let i = 0; i < this.set.length; i++) {
							if (i > 0) this.formatted += "||";
							const comps = this.set[i];
							for (let k = 0; k < comps.length; k++) {
								if (k > 0) this.formatted += " ";
								this.formatted += comps[k].toString().trim();
							}
						}
					}
					return this.formatted;
				}
				format() {
					return this.range;
				}
				toString() {
					return this.range;
				}
				parseRange(range) {
					range = range.replace(BUILDSTRIPRE, "");
					const memoKey = ((this.options.includePrerelease && FLAG_INCLUDE_PRERELEASE) | (this.options.loose && FLAG_LOOSE)) + ":" + range;
					const cached = cache.get(memoKey);
					if (cached) return cached;
					const loose = this.options.loose;
					const hr = loose ? re[t.HYPHENRANGELOOSE] : re[t.HYPHENRANGE];
					range = range.replace(hr, hyphenReplace(this.options.includePrerelease));
					debug("hyphen replace", range);
					range = range.replace(re[t.COMPARATORTRIM], comparatorTrimReplace);
					debug("comparator trim", range);
					range = range.replace(re[t.TILDETRIM], tildeTrimReplace);
					debug("tilde trim", range);
					range = range.replace(re[t.CARETTRIM], caretTrimReplace);
					debug("caret trim", range);
					let rangeList = range.split(" ").map((comp) => parseComparator(comp, this.options)).join(" ").split(/\s+/).map((comp) => replaceGTE0(comp, this.options));
					if (loose) rangeList = rangeList.filter((comp) => {
						debug("loose invalid filter", comp, this.options);
						return !!comp.match(re[t.COMPARATORLOOSE]);
					});
					debug("range list", rangeList);
					const rangeMap = /* @__PURE__ */ new Map();
					const comparators = rangeList.map((comp) => new Comparator(comp, this.options));
					for (const comp of comparators) {
						if (isNullSet(comp)) return [comp];
						rangeMap.set(comp.value, comp);
					}
					if (rangeMap.size > 1 && rangeMap.has("")) rangeMap.delete("");
					const result = [...rangeMap.values()];
					cache.set(memoKey, result);
					return result;
				}
				intersects(range, options) {
					if (!(range instanceof Range)) throw new TypeError("a Range is required");
					return this.set.some((thisComparators) => {
						return isSatisfiable(thisComparators, options) && range.set.some((rangeComparators) => {
							return isSatisfiable(rangeComparators, options) && thisComparators.every((thisComparator) => {
								return rangeComparators.every((rangeComparator) => {
									return thisComparator.intersects(rangeComparator, options);
								});
							});
						});
					});
				}
				test(version) {
					if (!version) return false;
					if (typeof version === "string") try {
						version = new SemVer(version, this.options);
					} catch (er) {
						return false;
					}
					for (let i = 0; i < this.set.length; i++) if (testSet(this.set[i], version, this.options)) return true;
					return false;
				}
			};
			const cache = new (require_lrucache())();
			const parseOptions = require_parse_options();
			const Comparator = require_comparator();
			const debug = require_debug();
			const SemVer = require_semver$1();
			const { safeRe: re, src, t, comparatorTrimReplace, tildeTrimReplace, caretTrimReplace } = require_re();
			const { FLAG_INCLUDE_PRERELEASE, FLAG_LOOSE } = require_constants();
			const BUILDSTRIPRE = new RegExp(src[t.BUILD], "g");
			const isNullSet = (c) => c.value === "<0.0.0-0";
			const isAny = (c) => c.value === "";
			const isSatisfiable = (comparators, options) => {
				let result = true;
				const remainingComparators = comparators.slice();
				let testComparator = remainingComparators.pop();
				while (result && remainingComparators.length) {
					result = remainingComparators.every((otherComparator) => {
						return testComparator.intersects(otherComparator, options);
					});
					testComparator = remainingComparators.pop();
				}
				return result;
			};
			const parseComparator = (comp, options) => {
				comp = comp.replace(re[t.BUILD], "");
				debug("comp", comp, options);
				comp = replaceCarets(comp, options);
				debug("caret", comp);
				comp = replaceTildes(comp, options);
				debug("tildes", comp);
				comp = replaceXRanges(comp, options);
				debug("xrange", comp);
				comp = replaceStars(comp, options);
				debug("stars", comp);
				return comp;
			};
			const isX = (id) => !id || id.toLowerCase() === "x" || id === "*";
			const invalidXRangeOrder = (M, m, p) => isX(M) && !isX(m) || isX(m) && p && !isX(p);
			const replaceTildes = (comp, options) => {
				return comp.trim().split(/\s+/).map((c) => replaceTilde(c, options)).join(" ");
			};
			const replaceTilde = (comp, options) => {
				const r = options.loose ? re[t.TILDELOOSE] : re[t.TILDE];
				const z = options.includePrerelease ? "-0" : "";
				return comp.replace(r, (_, M, m, p, pr) => {
					debug("tilde", comp, _, M, m, p, pr);
					let ret;
					if (isX(M)) ret = "";
					else if (isX(m)) ret = `>=${M}.0.0${z} <${+M + 1}.0.0-0`;
					else if (isX(p)) ret = `>=${M}.${m}.0${z} <${M}.${+m + 1}.0-0`;
					else if (pr) {
						debug("replaceTilde pr", pr);
						ret = `>=${M}.${m}.${p}-${pr} <${M}.${+m + 1}.0-0`;
					} else ret = `>=${M}.${m}.${p} <${M}.${+m + 1}.0-0`;
					debug("tilde return", ret);
					return ret;
				});
			};
			const replaceCarets = (comp, options) => {
				return comp.trim().split(/\s+/).map((c) => replaceCaret(c, options)).join(" ");
			};
			const replaceCaret = (comp, options) => {
				debug("caret", comp, options);
				const r = options.loose ? re[t.CARETLOOSE] : re[t.CARET];
				const z = options.includePrerelease ? "-0" : "";
				return comp.replace(r, (_, M, m, p, pr) => {
					debug("caret", comp, _, M, m, p, pr);
					let ret;
					if (isX(M)) ret = "";
					else if (isX(m)) ret = `>=${M}.0.0${z} <${+M + 1}.0.0-0`;
					else if (isX(p)) {
						if (M === "0") ret = `>=${M}.${m}.0${z} <${M}.${+m + 1}.0-0`;
						else ret = `>=${M}.${m}.0${z} <${+M + 1}.0.0-0`;
					} else if (pr) {
						debug("replaceCaret pr", pr);
						if (M === "0") {
							if (m === "0") ret = `>=${M}.${m}.${p}-${pr} <${M}.${m}.${+p + 1}-0`;
							else ret = `>=${M}.${m}.${p}-${pr} <${M}.${+m + 1}.0-0`;
						} else ret = `>=${M}.${m}.${p}-${pr} <${+M + 1}.0.0-0`;
					} else {
						debug("no pr");
						if (M === "0") {
							if (m === "0") ret = `>=${M}.${m}.${p} <${M}.${m}.${+p + 1}-0`;
							else ret = `>=${M}.${m}.${p} <${M}.${+m + 1}.0-0`;
						} else ret = `>=${M}.${m}.${p} <${+M + 1}.0.0-0`;
					}
					debug("caret return", ret);
					return ret;
				});
			};
			const replaceXRanges = (comp, options) => {
				debug("replaceXRanges", comp, options);
				return comp.split(/\s+/).map((c) => replaceXRange(c, options)).join(" ");
			};
			const replaceXRange = (comp, options) => {
				comp = comp.trim();
				const r = options.loose ? re[t.XRANGELOOSE] : re[t.XRANGE];
				return comp.replace(r, (ret, gtlt, M, m, p, pr) => {
					debug("xRange", comp, ret, gtlt, M, m, p, pr);
					if (invalidXRangeOrder(M, m, p)) return comp;
					const xM = isX(M);
					const xm = xM || isX(m);
					const xp = xm || isX(p);
					const anyX = xp;
					if (gtlt === "=" && anyX) gtlt = "";
					pr = options.includePrerelease ? "-0" : "";
					if (xM) {
						if (gtlt === ">" || gtlt === "<") ret = "<0.0.0-0";
						else ret = "*";
					} else if (gtlt && anyX) {
						if (xm) m = 0;
						p = 0;
						if (gtlt === ">") {
							gtlt = ">=";
							if (xm) {
								M = +M + 1;
								m = 0;
								p = 0;
							} else {
								m = +m + 1;
								p = 0;
							}
						} else if (gtlt === "<=") {
							gtlt = "<";
							if (xm) M = +M + 1;
							else m = +m + 1;
						}
						if (gtlt === "<") pr = "-0";
						ret = `${gtlt + M}.${m}.${p}${pr}`;
					} else if (xm) ret = `>=${M}.0.0${pr} <${+M + 1}.0.0-0`;
					else if (xp) ret = `>=${M}.${m}.0${pr} <${M}.${+m + 1}.0-0`;
					debug("xRange return", ret);
					return ret;
				});
			};
			const replaceStars = (comp, options) => {
				debug("replaceStars", comp, options);
				return comp.trim().replace(re[t.STAR], "");
			};
			const replaceGTE0 = (comp, options) => {
				debug("replaceGTE0", comp, options);
				return comp.trim().replace(re[options.includePrerelease ? t.GTE0PRE : t.GTE0], "");
			};
			const hyphenReplace = (incPr) => ($0, from, fM, fm, fp, fpr, fb, to, tM, tm, tp, tpr) => {
				if (isX(fM)) from = "";
				else if (isX(fm)) from = `>=${fM}.0.0${incPr ? "-0" : ""}`;
				else if (isX(fp)) from = `>=${fM}.${fm}.0${incPr ? "-0" : ""}`;
				else if (fpr) from = `>=${from}`;
				else from = `>=${from}${incPr ? "-0" : ""}`;
				if (isX(tM)) to = "";
				else if (isX(tm)) to = `<${+tM + 1}.0.0-0`;
				else if (isX(tp)) to = `<${tM}.${+tm + 1}.0-0`;
				else if (tpr) to = `<=${tM}.${tm}.${tp}-${tpr}`;
				else if (incPr) to = `<${tM}.${tm}.${+tp + 1}-0`;
				else to = `<=${to}`;
				return `${from} ${to}`.trim();
			};
			const testSet = (set, version, options) => {
				for (let i = 0; i < set.length; i++) if (!set[i].test(version)) return false;
				if (version.prerelease.length && !options.includePrerelease) {
					for (let i = 0; i < set.length; i++) {
						debug(set[i].semver);
						if (set[i].semver === Comparator.ANY) continue;
						if (set[i].semver.prerelease.length > 0) {
							const allowed = set[i].semver;
							if (allowed.major === version.major && allowed.minor === version.minor && allowed.patch === version.patch) return true;
						}
					}
					return false;
				}
				return true;
			};
		}));
		//#endregion
		//#region ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/classes/comparator.js
		var require_comparator = /* @__PURE__ */ __commonJSMin(((exports, module) => {
			const ANY = Symbol("SemVer ANY");
			module.exports = class Comparator {
				static get ANY() {
					return ANY;
				}
				constructor(comp, options) {
					options = parseOptions(options);
					if (comp instanceof Comparator) {
						if (comp.loose === !!options.loose) return comp;
						else comp = comp.value;
					}
					comp = comp.trim().split(/\s+/).join(" ");
					debug("comparator", comp, options);
					this.options = options;
					this.loose = !!options.loose;
					this.parse(comp);
					if (this.semver === ANY) this.value = "";
					else this.value = this.operator + this.semver.version;
					debug("comp", this);
				}
				parse(comp) {
					const r = this.options.loose ? re[t.COMPARATORLOOSE] : re[t.COMPARATOR];
					const m = comp.match(r);
					if (!m) throw new TypeError(`Invalid comparator: ${comp}`);
					this.operator = m[1] !== void 0 ? m[1] : "";
					if (this.operator === "=") this.operator = "";
					if (!m[2]) this.semver = ANY;
					else this.semver = new SemVer(m[2], this.options.loose);
				}
				toString() {
					return this.value;
				}
				test(version) {
					debug("Comparator.test", version, this.options.loose);
					if (this.semver === ANY || version === ANY) return true;
					if (typeof version === "string") try {
						version = new SemVer(version, this.options);
					} catch (er) {
						return false;
					}
					return cmp(version, this.operator, this.semver, this.options);
				}
				intersects(comp, options) {
					if (!(comp instanceof Comparator)) throw new TypeError("a Comparator is required");
					if (this.operator === "") {
						if (this.value === "") return true;
						return new Range(comp.value, options).test(this.value);
					} else if (comp.operator === "") {
						if (comp.value === "") return true;
						return new Range(this.value, options).test(comp.semver);
					}
					options = parseOptions(options);
					if (options.includePrerelease && (this.value === "<0.0.0-0" || comp.value === "<0.0.0-0")) return false;
					if (!options.includePrerelease && (this.value.startsWith("<0.0.0") || comp.value.startsWith("<0.0.0"))) return false;
					if (this.operator.startsWith(">") && comp.operator.startsWith(">")) return true;
					if (this.operator.startsWith("<") && comp.operator.startsWith("<")) return true;
					if (this.semver.version === comp.semver.version && this.operator.includes("=") && comp.operator.includes("=")) return true;
					if (cmp(this.semver, "<", comp.semver, options) && this.operator.startsWith(">") && comp.operator.startsWith("<")) return true;
					if (cmp(this.semver, ">", comp.semver, options) && this.operator.startsWith("<") && comp.operator.startsWith(">")) return true;
					return false;
				}
			};
			const parseOptions = require_parse_options();
			const { safeRe: re, t } = require_re();
			const cmp = require_cmp();
			const debug = require_debug();
			const SemVer = require_semver$1();
			const Range = require_range();
		}));
		//#endregion
		//#region ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/satisfies.js
		var require_satisfies = /* @__PURE__ */ __commonJSMin(((exports, module) => {
			const Range = require_range();
			const satisfies = (version, range, options) => {
				try {
					range = new Range(range, options);
				} catch (er) {
					return false;
				}
				return range.test(version);
			};
			module.exports = satisfies;
		}));
		//#endregion
		//#region ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/to-comparators.js
		var require_to_comparators = /* @__PURE__ */ __commonJSMin(((exports, module) => {
			const Range = require_range();
			const toComparators = (range, options) => new Range(range, options).set.map((comp) => comp.map((c) => c.value).join(" ").trim().split(" "));
			module.exports = toComparators;
		}));
		//#endregion
		//#region ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/max-satisfying.js
		var require_max_satisfying = /* @__PURE__ */ __commonJSMin(((exports, module) => {
			const SemVer = require_semver$1();
			const Range = require_range();
			const maxSatisfying = (versions, range, options) => {
				let max = null;
				let maxSV = null;
				let rangeObj = null;
				try {
					rangeObj = new Range(range, options);
				} catch (er) {
					return null;
				}
				versions.forEach((v) => {
					if (rangeObj.test(v)) {
						if (!max || maxSV.compare(v) === -1) {
							max = v;
							maxSV = new SemVer(max, options);
						}
					}
				});
				return max;
			};
			module.exports = maxSatisfying;
		}));
		//#endregion
		//#region ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/min-satisfying.js
		var require_min_satisfying = /* @__PURE__ */ __commonJSMin(((exports, module) => {
			const SemVer = require_semver$1();
			const Range = require_range();
			const minSatisfying = (versions, range, options) => {
				let min = null;
				let minSV = null;
				let rangeObj = null;
				try {
					rangeObj = new Range(range, options);
				} catch (er) {
					return null;
				}
				versions.forEach((v) => {
					if (rangeObj.test(v)) {
						if (!min || minSV.compare(v) === 1) {
							min = v;
							minSV = new SemVer(min, options);
						}
					}
				});
				return min;
			};
			module.exports = minSatisfying;
		}));
		//#endregion
		//#region ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/min-version.js
		var require_min_version = /* @__PURE__ */ __commonJSMin(((exports, module) => {
			const SemVer = require_semver$1();
			const Range = require_range();
			const gt = require_gt();
			const minVersion = (range, loose) => {
				range = new Range(range, loose);
				let minver = new SemVer("0.0.0");
				if (range.test(minver)) return minver;
				minver = new SemVer("0.0.0-0");
				if (range.test(minver)) return minver;
				minver = null;
				for (let i = 0; i < range.set.length; ++i) {
					const comparators = range.set[i];
					let setMin = null;
					comparators.forEach((comparator) => {
						const compver = new SemVer(comparator.semver.version);
						switch (comparator.operator) {
							case ">":
								if (compver.prerelease.length === 0) compver.patch++;
								else compver.prerelease.push(0);
								compver.raw = compver.format();
							case "":
							case ">=":
								if (!setMin || gt(compver, setMin)) setMin = compver;
								break;
							case "<":
							case "<=": break;
							/* istanbul ignore next */
							default: throw new Error(`Unexpected operation: ${comparator.operator}`);
						}
					});
					if (setMin && (!minver || gt(minver, setMin))) minver = setMin;
				}
				if (minver && range.test(minver)) return minver;
				return null;
			};
			module.exports = minVersion;
		}));
		//#endregion
		//#region ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/valid.js
		var require_valid = /* @__PURE__ */ __commonJSMin(((exports, module) => {
			const Range = require_range();
			const validRange = (range, options) => {
				try {
					return new Range(range, options).range || "*";
				} catch (er) {
					return null;
				}
			};
			module.exports = validRange;
		}));
		//#endregion
		//#region ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/outside.js
		var require_outside = /* @__PURE__ */ __commonJSMin(((exports, module) => {
			const SemVer = require_semver$1();
			const Comparator = require_comparator();
			const { ANY } = Comparator;
			const Range = require_range();
			const satisfies = require_satisfies();
			const gt = require_gt();
			const lt = require_lt();
			const lte = require_lte();
			const gte = require_gte();
			const outside = (version, range, hilo, options) => {
				version = new SemVer(version, options);
				range = new Range(range, options);
				let gtfn, ltefn, ltfn, comp, ecomp;
				switch (hilo) {
					case ">":
						gtfn = gt;
						ltefn = lte;
						ltfn = lt;
						comp = ">";
						ecomp = ">=";
						break;
					case "<":
						gtfn = lt;
						ltefn = gte;
						ltfn = gt;
						comp = "<";
						ecomp = "<=";
						break;
					default: throw new TypeError("Must provide a hilo val of \"<\" or \">\"");
				}
				if (satisfies(version, range, options)) return false;
				for (let i = 0; i < range.set.length; ++i) {
					const comparators = range.set[i];
					let high = null;
					let low = null;
					comparators.forEach((comparator) => {
						if (comparator.semver === ANY) comparator = new Comparator(">=0.0.0");
						high = high || comparator;
						low = low || comparator;
						if (gtfn(comparator.semver, high.semver, options)) high = comparator;
						else if (ltfn(comparator.semver, low.semver, options)) low = comparator;
					});
					if (high.operator === comp || high.operator === ecomp) return false;
					if ((!low.operator || low.operator === comp) && ltefn(version, low.semver)) return false;
					else if (low.operator === ecomp && ltfn(version, low.semver)) return false;
				}
				return true;
			};
			module.exports = outside;
		}));
		//#endregion
		//#region ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/gtr.js
		var require_gtr = /* @__PURE__ */ __commonJSMin(((exports, module) => {
			const outside = require_outside();
			const gtr = (version, range, options) => outside(version, range, ">", options);
			module.exports = gtr;
		}));
		//#endregion
		//#region ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/ltr.js
		var require_ltr = /* @__PURE__ */ __commonJSMin(((exports, module) => {
			const outside = require_outside();
			const ltr = (version, range, options) => outside(version, range, "<", options);
			module.exports = ltr;
		}));
		//#endregion
		//#region ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/intersects.js
		var require_intersects = /* @__PURE__ */ __commonJSMin(((exports, module) => {
			const Range = require_range();
			const intersects = (r1, r2, options) => {
				r1 = new Range(r1, options);
				r2 = new Range(r2, options);
				return r1.intersects(r2, options);
			};
			module.exports = intersects;
		}));
		//#endregion
		//#region ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/simplify.js
		var require_simplify = /* @__PURE__ */ __commonJSMin(((exports, module) => {
			const satisfies = require_satisfies();
			const compare = require_compare();
			module.exports = (versions, range, options) => {
				const set = [];
				let first = null;
				let prev = null;
				const v = versions.sort((a, b) => compare(a, b, options));
				for (const version of v) if (satisfies(version, range, options)) {
					prev = version;
					if (!first) first = version;
				} else {
					if (prev) set.push([first, prev]);
					prev = null;
					first = null;
				}
				if (first) set.push([first, null]);
				const ranges = [];
				for (const [min, max] of set) if (min === max) ranges.push(min);
				else if (!max && min === v[0]) ranges.push("*");
				else if (!max) ranges.push(`>=${min}`);
				else if (min === v[0]) ranges.push(`<=${max}`);
				else ranges.push(`${min} - ${max}`);
				const simplified = ranges.join(" || ");
				const original = typeof range.raw === "string" ? range.raw : String(range);
				return simplified.length < original.length ? simplified : range;
			};
		}));
		//#endregion
		//#region ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/subset.js
		var require_subset = /* @__PURE__ */ __commonJSMin(((exports, module) => {
			const Range = require_range();
			const Comparator = require_comparator();
			const { ANY } = Comparator;
			const satisfies = require_satisfies();
			const compare = require_compare();
			const subset = (sub, dom, options = {}) => {
				if (sub === dom) return true;
				sub = new Range(sub, options);
				dom = new Range(dom, options);
				let sawNonNull = false;
				OUTER: for (const simpleSub of sub.set) {
					for (const simpleDom of dom.set) {
						const isSub = simpleSubset(simpleSub, simpleDom, options);
						sawNonNull = sawNonNull || isSub !== null;
						if (isSub) continue OUTER;
					}
					if (sawNonNull) return false;
				}
				return true;
			};
			const minimumVersionWithPreRelease = [new Comparator(">=0.0.0-0")];
			const minimumVersion = [new Comparator(">=0.0.0")];
			const simpleSubset = (sub, dom, options) => {
				if (sub === dom) return true;
				if (sub.length === 1 && sub[0].semver === ANY) {
					if (dom.length === 1 && dom[0].semver === ANY) return true;
					else if (options.includePrerelease) sub = minimumVersionWithPreRelease;
					else sub = minimumVersion;
				}
				if (dom.length === 1 && dom[0].semver === ANY) {
					if (options.includePrerelease) return true;
					else dom = minimumVersion;
				}
				const eqSet = /* @__PURE__ */ new Set();
				let gt, lt;
				for (const c of sub) if (c.operator === ">" || c.operator === ">=") gt = higherGT(gt, c, options);
				else if (c.operator === "<" || c.operator === "<=") lt = lowerLT(lt, c, options);
				else eqSet.add(c.semver);
				if (eqSet.size > 1) return null;
				let gtltComp;
				if (gt && lt) {
					gtltComp = compare(gt.semver, lt.semver, options);
					if (gtltComp > 0) return null;
					else if (gtltComp === 0 && (gt.operator !== ">=" || lt.operator !== "<=")) return null;
				}
				for (const eq of eqSet) {
					if (gt && !satisfies(eq, String(gt), options)) return null;
					if (lt && !satisfies(eq, String(lt), options)) return null;
					for (const c of dom) if (!satisfies(eq, String(c), options)) return false;
					return true;
				}
				let higher, lower;
				let hasDomLT, hasDomGT;
				let needDomLTPre = lt && !options.includePrerelease && lt.semver.prerelease.length ? lt.semver : false;
				let needDomGTPre = gt && !options.includePrerelease && gt.semver.prerelease.length ? gt.semver : false;
				if (needDomLTPre && needDomLTPre.prerelease.length === 1 && lt.operator === "<" && needDomLTPre.prerelease[0] === 0) needDomLTPre = false;
				for (const c of dom) {
					hasDomGT = hasDomGT || c.operator === ">" || c.operator === ">=";
					hasDomLT = hasDomLT || c.operator === "<" || c.operator === "<=";
					if (gt) {
						if (needDomGTPre) {
							if (c.semver.prerelease && c.semver.prerelease.length && c.semver.major === needDomGTPre.major && c.semver.minor === needDomGTPre.minor && c.semver.patch === needDomGTPre.patch) needDomGTPre = false;
						}
						if (c.operator === ">" || c.operator === ">=") {
							higher = higherGT(gt, c, options);
							if (higher === c && higher !== gt) return false;
						} else if (gt.operator === ">=" && !c.test(gt.semver)) return false;
					}
					if (lt) {
						if (needDomLTPre) {
							if (c.semver.prerelease && c.semver.prerelease.length && c.semver.major === needDomLTPre.major && c.semver.minor === needDomLTPre.minor && c.semver.patch === needDomLTPre.patch) needDomLTPre = false;
						}
						if (c.operator === "<" || c.operator === "<=") {
							lower = lowerLT(lt, c, options);
							if (lower === c && lower !== lt) return false;
						} else if (lt.operator === "<=" && !c.test(lt.semver)) return false;
					}
					if (!c.operator && (lt || gt) && gtltComp !== 0) return false;
				}
				if (gt && hasDomLT && !lt && gtltComp !== 0) return false;
				if (lt && hasDomGT && !gt && gtltComp !== 0) return false;
				if (needDomGTPre || needDomLTPre) return false;
				return true;
			};
			const higherGT = (a, b, options) => {
				if (!a) return b;
				const comp = compare(a.semver, b.semver, options);
				return comp > 0 ? a : comp < 0 ? b : b.operator === ">" && a.operator === ">=" ? b : a;
			};
			const lowerLT = (a, b, options) => {
				if (!a) return b;
				const comp = compare(a.semver, b.semver, options);
				return comp < 0 ? a : comp > 0 ? b : b.operator === "<" && a.operator === "<=" ? b : a;
			};
			module.exports = subset;
		}));
		//#endregion
		//#region src/client/model.ts
		var import_semver = (/* @__PURE__ */ __commonJSMin(((exports, module) => {
			const internalRe = require_re();
			const constants = require_constants();
			const SemVer = require_semver$1();
			const identifiers = require_identifiers();
			module.exports = {
				parse: require_parse(),
				valid: require_valid$1(),
				clean: require_clean(),
				inc: require_inc(),
				diff: require_diff(),
				major: require_major(),
				minor: require_minor(),
				patch: require_patch(),
				prerelease: require_prerelease(),
				compare: require_compare(),
				rcompare: require_rcompare(),
				compareLoose: require_compare_loose(),
				compareBuild: require_compare_build(),
				sort: require_sort(),
				rsort: require_rsort(),
				gt: require_gt(),
				lt: require_lt(),
				eq: require_eq(),
				neq: require_neq(),
				gte: require_gte(),
				lte: require_lte(),
				cmp: require_cmp(),
				coerce: require_coerce(),
				truncate: require_truncate(),
				Comparator: require_comparator(),
				Range: require_range(),
				satisfies: require_satisfies(),
				toComparators: require_to_comparators(),
				maxSatisfying: require_max_satisfying(),
				minSatisfying: require_min_satisfying(),
				minVersion: require_min_version(),
				validRange: require_valid(),
				outside: require_outside(),
				gtr: require_gtr(),
				ltr: require_ltr(),
				intersects: require_intersects(),
				simplifyRange: require_simplify(),
				subset: require_subset(),
				SemVer,
				re: internalRe.re,
				src: internalRe.src,
				tokens: internalRe.t,
				SEMVER_SPEC_VERSION: constants.SEMVER_SPEC_VERSION,
				RELEASE_TYPES: constants.RELEASE_TYPES,
				compareIdentifiers: identifiers.compareIdentifiers,
				rcompareIdentifiers: identifiers.rcompareIdentifiers
			};
		})))();
		/** Join catalog and installed entries without depending on their display order. */
		function pluginRows(plugins, installed) {
			const installedByName = new Map(installed.map((entry) => [entry.packageName, entry]));
			return plugins.map((plugin) => {
				const current = installedByName.get(plugin.packageName);
				return {
					plugin,
					...current === void 0 ? {} : { installed: current },
					updateAvailable: plugin.compatible && current !== void 0 && (current.version === void 0 || (0, import_semver.valid)(current.version) !== null && (0, import_semver.valid)(plugin.version) !== null && (0, import_semver.gt)(plugin.version, current.version))
				};
			});
		}
		/** Apply query and compatibility/update filters with stable catalog ordering. */
		function visibleRows(rows, query, filter) {
			const normalized = query.trim().toLocaleLowerCase();
			return rows.filter((row) => {
				if (filter === "compatible" && !row.plugin.compatible) return false;
				if (filter === "updates" && !row.updateAvailable) return false;
				return normalized === "" || [
					row.plugin.name,
					row.plugin.packageName,
					row.plugin.description
				].some((value) => value.toLocaleLowerCase().includes(normalized));
			});
		}
		//#endregion
		//#region src/client/native.ts
		/** Request a native Host restart when the native bridge is available. */
		function requestNativeRestart() {
			const handler = window.webkit?.messageHandlers?.dshNative;
			if (handler === void 0) return false;
			handler.postMessage({ action: "restartHost" });
			return true;
		}
		/** Open an OAuth URL through the native bridge when available. */
		function requestNativeOpen(url) {
			const handler = window.webkit?.messageHandlers?.dshNative;
			if (handler === void 0) return false;
			handler.postMessage({
				action: "openExternal",
				url
			});
			return true;
		}
		//#endregion
		//#region src/client/connect.ts
		function pause(signal) {
			signal.throwIfAborted();
			return new Promise((resolve, reject) => {
				const cancel = () => {
					clearTimeout(timer);
					reject(signal.reason);
				};
				const timer = setTimeout(() => {
					signal.removeEventListener("abort", cancel);
					resolve();
				}, 750);
				signal.addEventListener("abort", cancel, { once: true });
			});
		}
		/** Keep the selected address through authorization; never substitute another visible repository. */
		async function connectSource(remote, repositoryUrl, options) {
			const { signal } = options;
			signal.throwIfAborted();
			if (options.authorize) {
				const flow = await remote.beginOAuth({ repositoryUrl });
				signal.throwIfAborted();
				options.open(flow.authorizationUrl);
				const deadline = Date.now() + 6e5;
				while (true) {
					if (Date.now() >= deadline) throw new Error(options.timeoutMessage);
					await pause(signal);
					const status = await remote.oauthStatus(flow.flowId);
					signal.throwIfAborted();
					if (status.status === "failed") throw new Error(status.message);
					if (status.status === "complete") break;
				}
			}
			signal.throwIfAborted();
			await remote.configure({ repositoryUrl });
			signal.throwIfAborted();
			await remote.refreshCatalog();
		}
		//#endregion
		//#region src/source.ts
		/** Repository addresses accepted by the Git repository marketplace. */
		const GONGFENG_ORIGIN = "https://git.woa.com/";
		const GITHUB_ORIGIN = "https://github.com/";
		const DEFAULT_REPOSITORY_URL = "https://git.woa.com/shamcleren/dsh-plugin";
		const ORIGINS = {
			"https://git.woa.com": {
				host: "gongfeng",
				baseUrl: GONGFENG_ORIGIN
			},
			"https://github.com": {
				host: "github",
				baseUrl: GITHUB_ORIGIN
			}
		};
		function parseRepositoryUrl(value) {
			const text = value.trim();
			const url = new URL(text);
			const known = ORIGINS[url.origin];
			if (known === void 0 || url.username || url.password || url.search || url.hash || /[%\\\u0000-\u0020]/u.test(text)) throw new Error("Use an HTTPS repository address on git.woa.com or github.com");
			const repository = url.pathname.replace(/^\//u, "").replace(/\/$/u, "").replace(/\.git$/u, "");
			const segments = repository.split("/");
			if (!(known.host === "github" ? segments.length === 2 : segments.length >= 2) || segments.some((segment) => !/^[A-Za-z0-9_-][A-Za-z0-9_.-]*$/u.test(segment)) || text.split("/").some((segment) => segment === "." || segment === "..")) throw new Error("Use the repository home URL, without a file or branch path");
			return {
				host: known.host,
				baseUrl: known.baseUrl,
				repository,
				repositoryUrl: known.baseUrl + repository
			};
		}
		/** Host of a typed address, or undefined while the address is incomplete. */
		function repositoryHost(value) {
			try {
				return parseRepositoryUrl(value).host;
			} catch {
				return;
			}
		}
		//#endregion
		//#region \0dsh-marketplace-css:/Users/renjinming/code/git.woa.com/shamcleren/dsh-plugin/plugins/marketplace/src/client/MarketplacePanel.module.css.mjs
		const css = "._0dih5q_root{color:var(--dsw-alias-label-primary,inherit);gap:16px;display:grid}._0dih5q_root button,._0dih5q_root input,._0dih5q_root select{font:inherit}._0dih5q_root button{border:1px solid var(--dsw-alias-border-l2,#46484d);color:inherit;background:var(--dsw-alias-bg-layer-3,#34363b);cursor:pointer;border-radius:9px;padding:8px 12px}._0dih5q_root button:disabled{opacity:.5;cursor:default}._0dih5q_sourceCard{border:1px solid var(--dsw-alias-border-l2,#46484d);background:linear-gradient(135deg, color-mix(in srgb, var(--dsw-alias-bg-layer-3,#34363b) 86%, #5968ff 14%), var(--dsw-alias-bg-layer-2,#202226));border-radius:14px;justify-content:space-between;align-items:center;gap:16px;padding:16px;display:flex}._0dih5q_eyebrow{color:var(--dsw-alias-label-tertiary,#a5a8b0);letter-spacing:.08em;text-transform:uppercase;margin-bottom:4px;font-size:11px}._0dih5q_muted,._0dih5q_pluginCard p,._0dih5q_meta,._0dih5q_empty{color:var(--dsw-alias-label-tertiary,#a5a8b0)}._0dih5q_actions{flex-wrap:wrap;gap:8px;display:flex}._0dih5q_sourceForm{border:1px solid var(--dsw-alias-border-l2,#46484d);border-radius:14px;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px;padding:16px;display:grid}._0dih5q_sourceForm label{gap:6px;font-size:13px;display:grid}._0dih5q_sourceForm input,._0dih5q_sourceForm select,._0dih5q_toolbar input,._0dih5q_toolbar select{box-sizing:border-box;border:1px solid var(--dsw-alias-border-l2,#46484d);width:100%;color:inherit;background:var(--dsw-alias-bg-layer-2,#202226);border-radius:9px;padding:9px 11px}._0dih5q_stats{grid-template-columns:repeat(3,1fr);gap:8px;display:grid}._0dih5q_stats div{background:var(--dsw-alias-bg-module-platform,#27292e);border-radius:11px;justify-content:space-between;align-items:baseline;padding:12px 14px;display:flex}._0dih5q_stats span{color:var(--dsw-alias-label-tertiary,#a5a8b0);font-size:12px}._0dih5q_stats strong{font-size:20px}._0dih5q_tabs{background:var(--dsw-alias-bg-module-platform,#27292e);border-radius:11px;grid-template-columns:repeat(2,1fr);gap:4px;padding:4px;display:grid}._0dih5q_tabs button{background:0 0;border:0}._0dih5q_tabs button[data-active=true]{background:var(--dsw-alias-bg-layer-3,#3a3d43)}._0dih5q_toolbar{grid-template-columns:minmax(0,1fr) minmax(120px,auto) auto;gap:8px;display:grid}._0dih5q_notice,._0dih5q_error{border-radius:10px;justify-content:space-between;align-items:center;gap:12px;padding:11px 13px;display:flex}._0dih5q_notice{background:color-mix(in srgb, var(--dsh-color-success,#62ca8d) 13%, var(--dsw-alias-bg-module-platform,#27292e))}._0dih5q_error{color:var(--dsh-color-danger,#f08b8b);background:color-mix(in srgb, var(--dsh-color-danger,#f08b8b) 10%, var(--dsw-alias-bg-module-platform,#27292e))}._0dih5q_grid{grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:11px;margin:0;padding:0;list-style:none;display:grid}._0dih5q_pluginCard{border:1px solid var(--dsw-alias-border-l2,#46484d);background:var(--dsw-alias-bg-layer-2,#202226);border-radius:13px;align-content:start;gap:9px;min-height:190px;padding:15px;display:grid}._0dih5q_pluginHeader,._0dih5q_cardFooter,._0dih5q_meta{justify-content:space-between;align-items:center;gap:10px;display:flex}._0dih5q_pluginCard p{min-height:40px;margin:0;line-height:1.45}._0dih5q_pluginCard code,._0dih5q_list code{overflow-wrap:anywhere;color:var(--dsw-alias-label-tertiary,#a5a8b0);font-size:11px;display:block}._0dih5q_badge{color:var(--dsh-color-success,#62ca8d);background:color-mix(in srgb, var(--dsh-color-success,#62ca8d) 13%, transparent);border-radius:999px;padding:3px 7px;font-size:11px}._0dih5q_incompatible{color:var(--dsh-color-danger,#f08b8b);font-size:12px}._0dih5q_list{gap:8px;margin:0;padding:0;list-style:none;display:grid}._0dih5q_list li{border:1px solid var(--dsw-alias-border-l2,#46484d);border-radius:11px;justify-content:space-between;align-items:center;gap:12px;padding:13px 14px;display:flex}._0dih5q_danger{color:var(--dsh-color-danger,#f08b8b)!important;background:0 0!important}._0dih5q_empty{text-align:center;border:1px dashed var(--dsw-alias-border-l2,#46484d);border-radius:12px;margin:0;padding:28px}@media (max-width:720px){._0dih5q_sourceCard,._0dih5q_list li{flex-direction:column;align-items:stretch}._0dih5q_sourceForm,._0dih5q_toolbar{grid-template-columns:1fr}}";
		const tagId = "@shamcleren/dsh-plugin-marketplace/MarketplacePanel.module.css";
		if (typeof document !== "undefined" && document.querySelector("style[data-plugin-css=" + JSON.stringify(tagId) + "]") === null) {
			const tag = document.createElement("style");
			tag.dataset.plugin = "@shamcleren/dsh-plugin-marketplace";
			tag.dataset.pluginCss = tagId;
			tag.textContent = css;
			document.head.appendChild(tag);
		}
		var MarketplacePanel_module_css_default = {
			"sourceCard": "_0dih5q_sourceCard",
			"list": "_0dih5q_list",
			"error": "_0dih5q_error",
			"badge": "_0dih5q_badge",
			"incompatible": "_0dih5q_incompatible",
			"notice": "_0dih5q_notice",
			"root": "_0dih5q_root",
			"empty": "_0dih5q_empty",
			"stats": "_0dih5q_stats",
			"muted": "_0dih5q_muted",
			"meta": "_0dih5q_meta",
			"pluginCard": "_0dih5q_pluginCard",
			"toolbar": "_0dih5q_toolbar",
			"cardFooter": "_0dih5q_cardFooter",
			"sourceForm": "_0dih5q_sourceForm",
			"eyebrow": "_0dih5q_eyebrow",
			"pluginHeader": "_0dih5q_pluginHeader",
			"danger": "_0dih5q_danger",
			"tabs": "_0dih5q_tabs",
			"actions": "_0dih5q_actions",
			"grid": "_0dih5q_grid"
		};
		//#endregion
		//#region src/client/MarketplacePanel.tsx
		function errorMessage(error) {
			return error instanceof Error ? error.message : String(error);
		}
		/** Trusted catalog and installed-plugin management UI. */
		function MarketplacePanel({ remote, t }) {
			const [view, setView] = (0, react.useState)("catalog");
			const [filter, setFilter] = (0, react.useState)("all");
			const [query, setQuery] = (0, react.useState)("");
			const [state, setState] = (0, react.useState)();
			const [catalog, setCatalog] = (0, react.useState)();
			const [editing, setEditing] = (0, react.useState)(false);
			const [repositoryUrl, setRepositoryUrl] = (0, react.useState)(DEFAULT_REPOSITORY_URL);
			const [authorizationUrl, setAuthorizationUrl] = (0, react.useState)();
			const connecting = (0, react.useRef)();
			const [busy, setBusy] = (0, react.useState)();
			const [error, setError] = (0, react.useState)();
			const [notice, setNotice] = (0, react.useState)();
			const [restartPending, setRestartPending] = (0, react.useState)(false);
			const load = (0, react.useCallback)(async (refreshCatalog) => {
				setError(void 0);
				const nextState = await remote.state();
				setState(nextState);
				setRepositoryUrl(nextState.repositoryUrl);
				if (nextState.host === "github" || nextState.oauthConfigured) setCatalog(await (refreshCatalog ? remote.refreshCatalog() : remote.catalog()));
				else setCatalog(void 0);
			}, [remote]);
			(0, react.useEffect)(() => {
				load(false).catch((failure) => {
					setError(errorMessage(failure));
				});
			}, [load]);
			(0, react.useEffect)(() => () => {
				connecting.current?.abort();
			}, []);
			const ready = state?.host === "github" || state?.oauthConfigured === true;
			const enteredHost = repositoryHost(repositoryUrl);
			const rows = (0, react.useMemo)(() => pluginRows(catalog?.plugins ?? [], state?.installed ?? []), [catalog, state]);
			const updates = (0, react.useMemo)(() => rows.filter((row) => row.updateAvailable), [rows]);
			const visible = (0, react.useMemo)(() => visibleRows(rows, query, filter), [
				filter,
				query,
				rows
			]);
			const installedRows = (0, react.useMemo)(() => rows.filter((row) => row.installed !== void 0), [rows]);
			const unknownInstalled = (0, react.useMemo)(() => (state?.installed ?? []).filter((entry) => !rows.some((row) => row.installed?.packageName === entry.packageName)), [rows, state]);
			const mutate = async (key, operation) => {
				setBusy(key);
				setError(void 0);
				try {
					await operation();
					setRestartPending(true);
					setNotice(t("restartPending"));
					await load(false);
				} catch (failure) {
					setError(errorMessage(failure));
				} finally {
					setBusy(void 0);
				}
			};
			const refreshRemoteCatalog = async () => {
				setBusy("refresh");
				setError(void 0);
				try {
					await load(true);
				} catch (failure) {
					setError(errorMessage(failure));
				} finally {
					setBusy(void 0);
				}
			};
			const updateAll = async () => {
				setBusy("update-all");
				setError(void 0);
				let completed = 0;
				try {
					for (const row of updates) {
						await remote.add(row.plugin.packageName);
						completed += 1;
					}
				} catch (failure) {
					setError(`${t("partialUpdate")} ${errorMessage(failure)}`);
				} finally {
					if (completed > 0) {
						setRestartPending(true);
						setNotice(t("restartPending"));
						await load(false).catch((failure) => {
							setError(errorMessage(failure));
						});
					}
					setBusy(void 0);
				}
			};
			const connect = async (authorize) => {
				connecting.current?.abort();
				const controller = new AbortController();
				connecting.current = controller;
				setBusy("source");
				setError(void 0);
				setNotice(void 0);
				setAuthorizationUrl(void 0);
				try {
					await connectSource(remote, repositoryUrl, {
						authorize,
						signal: controller.signal,
						timeoutMessage: t("oauthExpired"),
						open: (url) => {
							setAuthorizationUrl(url);
							if (!requestNativeOpen(url)) window.open(url, "_blank", "noopener,noreferrer");
						}
					});
					if (controller.signal.aborted) return;
					await load(false);
					if (controller.signal.aborted) return;
					setEditing(false);
					setNotice(t("oauthConnected"));
				} catch (failure) {
					if (!controller.signal.aborted) setError(errorMessage(failure));
				} finally {
					if (!controller.signal.aborted) {
						setBusy(void 0);
						setAuthorizationUrl(void 0);
					}
				}
			};
			const restart = () => {
				if (requestNativeRestart()) setNotice(t("restartSent"));
			};
			return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("section", {
				className: MarketplacePanel_module_css_default.root,
				"aria-busy": busy !== void 0,
				children: [
					/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("header", {
						className: MarketplacePanel_module_css_default.sourceCard,
						children: [/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
								className: MarketplacePanel_module_css_default.eyebrow,
								children: t("source")
							}),
							/* @__PURE__ */ (0, react_jsx_runtime.jsx)("strong", { children: state?.repositoryUrl ?? repositoryUrl }),
							/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								className: MarketplacePanel_module_css_default.muted,
								children: [
									ready ? t("connected") : t("disconnected"),
									" · ",
									t("sourceSummary")
								]
							})
						] }), /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
							className: MarketplacePanel_module_css_default.actions,
							children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
								type: "button",
								disabled: busy !== void 0,
								onClick: () => {
									setEditing(!editing);
								},
								children: t("configure")
							}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
								type: "button",
								disabled: busy !== void 0 || !ready,
								onClick: () => {
									refreshRemoteCatalog();
								},
								children: busy === "refresh" ? t("working") : t("refresh")
							})]
						})]
					}),
					ready ? null : /* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
						className: MarketplacePanel_module_css_default.notice,
						children: t("optionalSource")
					}),
					editing ? /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
						className: MarketplacePanel_module_css_default.sourceForm,
						children: [
							/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("label", { children: [t("repositoryUrl"), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("input", {
								type: "url",
								value: repositoryUrl,
								placeholder: DEFAULT_REPOSITORY_URL,
								disabled: busy !== void 0,
								onChange: (event) => {
									setRepositoryUrl(event.currentTarget.value);
								}
							})] }),
							/* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
								className: MarketplacePanel_module_css_default.muted,
								children: t("sourceHint")
							}),
							/* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
								type: "button",
								disabled: busy !== void 0 || repositoryUrl.trim() === "",
								onClick: () => {
									connect(enteredHost !== "github" && state?.oauthConfigured !== true);
								},
								children: busy === "source" ? t("working") : enteredHost === "github" || state?.oauthConfigured === true ? t("save") : t("oauthLogin")
							}),
							state?.host === "gongfeng" && state.oauthConfigured ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
								type: "button",
								disabled: busy !== void 0,
								onClick: () => {
									connect(true);
								},
								children: t("oauthRelogin")
							}) : null,
							authorizationUrl ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("a", {
								href: authorizationUrl,
								target: "_blank",
								rel: "noopener noreferrer",
								children: t("openAuthorization")
							}) : null
						]
					}) : null,
					/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
						className: MarketplacePanel_module_css_default.stats,
						"aria-label": t("tab"),
						children: [
							/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", { children: t("catalogCount") }), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("strong", { children: rows.length })] }),
							/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", { children: t("installedCount") }), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("strong", { children: (state?.installed ?? []).length })] }),
							/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", { children: t("updateCount") }), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("strong", { children: updates.length })] })
						]
					}),
					/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
						className: MarketplacePanel_module_css_default.tabs,
						role: "tablist",
						children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
							type: "button",
							role: "tab",
							"aria-selected": view === "catalog",
							"data-active": view === "catalog" || void 0,
							onClick: () => {
								setView("catalog");
							},
							children: t("available")
						}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
							type: "button",
							role: "tab",
							"aria-selected": view === "installed",
							"data-active": view === "installed" || void 0,
							onClick: () => {
								setView("installed");
							},
							children: t("installed")
						})]
					}),
					error === void 0 ? null : /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
						className: MarketplacePanel_module_css_default.error,
						role: "alert",
						children: [/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", { children: [
							/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("strong", { children: [t("error"), ":"] }),
							" ",
							error
						] }), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => {
								load(false).catch((failure) => {
									setError(errorMessage(failure));
								});
							},
							children: t("retry")
						})]
					}),
					notice === void 0 ? null : /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
						className: MarketplacePanel_module_css_default.notice,
						children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", { children: notice }), restartPending && state?.nativeRestartAvailable === true ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: restart,
							children: t("restartNow")
						}) : null]
					}),
					view === "catalog" ? /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
						className: MarketplacePanel_module_css_default.toolbar,
						children: [
							/* @__PURE__ */ (0, react_jsx_runtime.jsx)("input", {
								type: "search",
								value: query,
								placeholder: t("search"),
								onChange: (event) => {
									setQuery(event.currentTarget.value);
								}
							}),
							/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("select", {
								value: filter,
								onChange: (event) => {
									setFilter(event.currentTarget.value);
								},
								"aria-label": t("compatible"),
								children: [
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("option", {
										value: "all",
										children: t("all")
									}),
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("option", {
										value: "compatible",
										children: t("compatible")
									}),
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("option", {
										value: "updates",
										children: t("updates")
									})
								]
							}),
							/* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
								type: "button",
								disabled: updates.length === 0 || busy !== void 0,
								onClick: () => {
									updateAll();
								},
								children: busy === "update-all" ? t("working") : `${t("updateAll")} (${updates.length})`
							})
						]
					}), visible.length === 0 ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
						className: MarketplacePanel_module_css_default.empty,
						children: t("empty")
					}) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)("ul", {
						className: MarketplacePanel_module_css_default.grid,
						children: visible.map((row) => /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("li", {
							className: MarketplacePanel_module_css_default.pluginCard,
							children: [
								/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
									className: MarketplacePanel_module_css_default.pluginHeader,
									children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("strong", { children: row.plugin.name }), row.installed === void 0 ? null : /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
										className: MarketplacePanel_module_css_default.badge,
										children: t("installedTag")
									})]
								}),
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", { children: row.plugin.description }),
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)("code", { children: row.plugin.packageName }),
								/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
									className: MarketplacePanel_module_css_default.meta,
									children: [/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", { children: ["v", row.plugin.version] }), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", { children: row.plugin.dshVersion })]
								}),
								/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
									className: MarketplacePanel_module_css_default.cardFooter,
									children: [row.plugin.compatible ? null : /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
										className: MarketplacePanel_module_css_default.incompatible,
										children: t("incompatible")
									}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
										type: "button",
										disabled: !row.plugin.compatible || row.installed !== void 0 && !row.updateAvailable || busy !== void 0,
										onClick: () => {
											mutate(row.plugin.packageName, () => remote.add(row.plugin.packageName));
										},
										children: busy === row.plugin.packageName ? t("working") : row.installed === void 0 ? t("install") : t("update")
									})]
								})
							]
						}, row.plugin.packageName))
					})] }) : installedRows.length === 0 && unknownInstalled.length === 0 ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
						className: MarketplacePanel_module_css_default.empty,
						children: t("emptyInstalled")
					}) : /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("ul", {
						className: MarketplacePanel_module_css_default.list,
						children: [installedRows.map((row) => /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("strong", { children: row.plugin.name }), /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("code", { children: [
							row.plugin.packageName,
							" · ",
							row.installed?.version ?? row.installed?.specifier
						] })] }), /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
							className: MarketplacePanel_module_css_default.actions,
							children: [row.updateAvailable ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
								type: "button",
								disabled: busy !== void 0,
								onClick: () => {
									mutate(row.plugin.packageName, () => remote.add(row.plugin.packageName));
								},
								children: t("update")
							}) : null, /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
								className: MarketplacePanel_module_css_default.danger,
								type: "button",
								disabled: busy !== void 0,
								onClick: () => {
									if (window.confirm(t("confirmRemove"))) mutate(row.plugin.packageName, () => remote.deletePackage(row.plugin.packageName));
								},
								children: busy === row.plugin.packageName ? t("removing") : t("remove")
							})]
						})] }, row.plugin.packageName)), unknownInstalled.map((entry) => /* @__PURE__ */ (0, react_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("strong", { children: entry.packageName }), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("code", { children: entry.version ?? entry.specifier })] }) }, entry.packageName))]
					})
				]
			});
		}
		//#endregion
		//#region src/client/locales.ts
		const zh = {
			tab: "Git 仓库市场",
			source: "可信来源",
			connected: "已连接",
			disconnected: "未配置（可选）",
			configure: "来源设置",
			refresh: "刷新目录",
			optionalSource: "Git 仓库市场为可选功能。你可以继续使用 DSH 和其他已安装的市场；需要从 Git 仓库安装插件时再打开“来源设置”。",
			installed: "已安装",
			available: "目录插件",
			compatible: "兼容",
			updates: "可更新",
			search: "搜索名称、包名或描述",
			all: "全部",
			install: "安装",
			update: "更新",
			updateAll: "更新全部",
			remove: "卸载",
			removing: "正在卸载…",
			working: "处理中…",
			installedTag: "已安装",
			incompatible: "此目录版本不兼容当前 DSH",
			empty: "没有符合条件的插件。",
			emptyInstalled: "当前 profile 没有安装目录中的插件。",
			restartPending: "变更已经写入 profile；完成本轮操作后统一重启即可生效。",
			restartNow: "立即重启",
			restartSent: "已请求原生 Host 重启。",
			error: "操作失败",
			retry: "重试",
			sourceSummary: "单一可信仓库 · 摘要校验 · 安装脚本禁用",
			repositoryUrl: "仓库地址",
			sourceHint: "填写 git.woa.com 或 github.com 仓库地址。工蜂地址通过 OAuth 连接；GitHub 公开仓库直接读取，不需要授权。",
			oauthLogin: "OAuth 登录并连接",
			oauthRelogin: "重新授权",
			openAuthorization: "打开授权页面",
			oauthConnected: "仓库已连接，插件目录已刷新。",
			oauthExpired: "OAuth 授权等待超时，请重试。",
			save: "保存来源",
			confirmRemove: "确认从当前 Web profile 卸载该插件？",
			partialUpdate: "部分插件已更新；请检查失败信息后重试。",
			catalogCount: "目录总数",
			updateCount: "可更新",
			installedCount: "已安装"
		};
		const en = {
			tab: "Git repository marketplace",
			source: "Trusted source",
			connected: "Connected",
			disconnected: "Not configured (optional)",
			configure: "Source settings",
			refresh: "Refresh catalog",
			optionalSource: "The Git repository marketplace is optional. You can keep using DSH and other installed marketplaces; open Source settings when you want plugins from a Git repository.",
			installed: "Installed",
			available: "Catalog",
			compatible: "Compatible",
			updates: "Updates",
			search: "Search name, package, or description",
			all: "All",
			install: "Install",
			update: "Update",
			updateAll: "Update all",
			remove: "Uninstall",
			removing: "Uninstalling…",
			working: "Working…",
			installedTag: "Installed",
			incompatible: "This catalog release is incompatible with the current DSH",
			empty: "No plugins match the current filters.",
			emptyInstalled: "The current profile has no catalog plugins installed.",
			restartPending: "Changes are saved to the profile; finish this batch and restart once to apply them.",
			restartNow: "Restart now",
			restartSent: "Native Host restart requested.",
			error: "Operation failed",
			retry: "Retry",
			sourceSummary: "Single trusted repository · digest verification · install scripts disabled",
			repositoryUrl: "Repository URL",
			sourceHint: "Enter a git.woa.com or github.com repository URL. Gongfeng uses OAuth. A public GitHub repository is read directly, without authorization.",
			oauthLogin: "Connect with OAuth",
			oauthRelogin: "Authorize again",
			openAuthorization: "Open authorization page",
			oauthConnected: "Repository connected and catalog refreshed.",
			oauthExpired: "OAuth authorization timed out; try again.",
			save: "Save source",
			confirmRemove: "Uninstall this plugin from the current Web profile?",
			partialUpdate: "Some plugins were updated; review the failure and retry.",
			catalogCount: "Catalog",
			updateCount: "Updates",
			installedCount: "Installed"
		};
		//#endregion
		//#region src/client/index.ts
		/** External Marketplace browser contribution. */
		const namespace = "settings.marketplace.external";
		const name = "@shamcleren/dsh-plugin-marketplace";
		const inject = [
			"slots",
			"locale",
			"connection"
		];
		function unwrap(response) {
			return response.then((result) => {
				if (result.ok) return result.value;
				throw new Error(`${result.error.code}: ${result.error.message}`);
			});
		}
		/** Add a remote Marketplace tab alongside the upstream Marketplace. */
		function apply(ctx) {
			ctx.effect(() => ctx.locale.register(namespace, {
				zh,
				en
			}), "external-marketplace: dictionaries");
			const t = ctx.locale.bind(namespace);
			const call = (endpoint, payload = {}) => unwrap(ctx.connection.rpc.call("/trusted-marketplace", endpoint, payload));
			const remote = {
				state: () => call("state"),
				catalog: () => call("catalog"),
				refreshCatalog: () => call("refreshCatalog"),
				configure: (request) => call("configure", request),
				add: (packageName) => call("add", { packageName }),
				deletePackage: (packageName) => call("deletePackage", { packageName }),
				beginOAuth: (request) => call("beginOAuth", request),
				oauthStatus: (flowId) => call("oauthStatus", { flowId })
			};
			ctx.slots.inject("settings.plugins.tab", () => ctx.slots.register({
				name: "settings.plugins.tab",
				id: "trusted-marketplace",
				order: 20,
				label: () => t("tab"),
				locale: namespace
			}, () => (0, react.createElement)(MarketplacePanel, {
				remote,
				t
			})));
		}
		//#endregion
		exports.apply = apply;
		exports.inject = inject;
		exports.name = name;
		return module.exports;
	}
});

//# sourceMappingURL=client.js.map