/** Public GitHub reads. Gongfeng credentials are never attached to these requests. */
/** Read the default branch of one public GitHub repository. */
export declare function githubRepository(repository: string): Promise<{
    defaultBranch: string;
}>;
/** Read one public file, following only GitHub content hosts. */
export declare function githubFile(repository: string, path: string, ref: string, maxBytes: number): Promise<Buffer>;
