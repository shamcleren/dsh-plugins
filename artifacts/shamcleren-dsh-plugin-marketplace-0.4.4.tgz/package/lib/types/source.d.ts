/** Repository addresses accepted by the Git repository marketplace. */
export declare const GONGFENG_ORIGIN = "https://git.woa.com/";
export declare const GITHUB_ORIGIN = "https://github.com/";
export declare const DEFAULT_REPOSITORY_URL = "https://git.woa.com/shamcleren/dsh-plugin";
export type RepositoryHost = 'gongfeng' | 'github';
export interface RepositoryAddress {
    readonly host: RepositoryHost;
    readonly baseUrl: string;
    readonly repository: string;
    readonly repositoryUrl: string;
}
export declare function parseRepositoryUrl(value: string): RepositoryAddress;
/** Host of a typed address, or undefined while the address is incomplete. */
export declare function repositoryHost(value: string): RepositoryHost | undefined;
