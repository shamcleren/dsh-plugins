/** WeCom settings scope and write-only credential projection for the browser card. */
import type { CardApi as IApiClient } from './api.js';
import type { SettingsScope } from '@deepseek-ai/dsh-client-ui-settings/client';
type SnapshotStore<T> = {
    getSnapshot(): T;
    subscribe(listener: () => void): () => void;
    set(value: T): void;
    update(mutator: (value: T) => void): void;
};
import type { Config } from '../config.js';
import { type FieldState, type FormActions, type FormState } from './form.js';
export interface WeComCardState extends FormState {
    enabled: FieldState;
    botId: FieldState;
    secret: FieldState;
    allowedUsers: FieldState;
    adminUsers: FieldState;
    workspaceId: FieldState;
    workspaceOptions: readonly WorkspaceOption[];
    workspacesLoading: boolean;
    workspacesFailed: boolean;
    preventIdleSleep: FieldState;
    agentPreset: FieldState;
    thinkingText: FieldState;
    turnTimeoutMs: FieldState;
    botIdConfigured: boolean;
    botIdWritable: boolean;
    secretConfigured: boolean;
    secretWritable: boolean;
}
export interface WorkspaceOption {
    id: string;
    title: string;
    path: string;
}
export interface WeComCardFace extends FormActions {
    hooks: {
        weComCard: SnapshotStore<WeComCardState>;
    };
}
/** Synchronizes one WeCom card with settings and credential stores. */
export declare class WeComCardController {
    private readonly scope;
    private readonly api;
    private readonly form;
    private readonly store;
    private botId;
    private secret;
    private workspaceOptions;
    private workspacesLoading;
    private workspacesFailed;
    constructor(scope: SettingsScope<Config>, api: Pick<IApiClient, 'credentials' | 'workspace'>);
    refreshCredential(ref: string): void;
    inject(): WeComCardFace;
    private projection;
    private readWorkspaces;
    private readCredentials;
    private writeCredential;
}
export {};
