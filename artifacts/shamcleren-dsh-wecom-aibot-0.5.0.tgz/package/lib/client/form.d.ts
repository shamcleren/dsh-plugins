/** Staged settings and credential writes for the WeCom browser card. */
import type { SettingsScope } from '@deepseek-ai/dsh-client-ui-settings/client';
type SnapshotStore<T> = {
    getSnapshot(): T;
    subscribe(listener: () => void): () => void;
    set(value: T): void;
    update(mutator: (value: T) => void): void;
};
export interface FieldState {
    text: string;
    overridden: boolean;
    invalid: boolean;
}
export interface FormState {
    available: boolean;
    writable: boolean;
    dirty: boolean;
    invalid: boolean;
    saving: boolean;
    failed: boolean;
}
export interface FormActions {
    edit(field: string, text: string): void;
    resetField(field: string): void;
    save(): void;
    discard(): void;
}
type FieldWrite = {
    kind: 'set';
    value: unknown;
} | {
    kind: 'clear';
};
interface FieldSpec {
    field: string;
    format(value: unknown): string;
    parse(text: string): FieldWrite | undefined;
}
interface SecretSpec {
    field: string;
    write(text: string): Promise<boolean>;
}
export declare function booleanField(field: string): FieldSpec;
export declare function numberField(field: string): FieldSpec;
export declare function textField(field: string): FieldSpec;
export declare function stringListField(field: string): FieldSpec;
/** Owns drafts over one settings namespace and writes them only on Save. */
export declare class CardForm<T> {
    private readonly scope;
    private readonly fields;
    private readonly secrets;
    private readonly staged;
    private readonly listeners;
    private saving;
    private failed;
    constructor(scope: SettingsScope<T>, fields: FieldSpec[], secrets: SecretSpec[]);
    bind<S>(project: () => S): SnapshotStore<S>;
    state(): FormState;
    field(field: string): FieldState;
    actions(): FormActions;
    private save;
    private plan;
    private clear;
    private store;
    private stage;
    private spec;
    private sectionValue;
    private baseValue;
    private userLayer;
    private stored;
    private publish;
}
export {};
