import type { Context } from '@deepseek-ai/cordis';
import type { RemoteResult } from '@deepseek-ai/dsh-typert-protocol';
import type { CredentialInfo } from '@deepseek-ai/dsh-credentials/types';
export interface CardApi {
    credentials: {
        describe(request: {
            refs: string[];
        }): Promise<{
            result: RemoteResult<{
                credentials: Record<string, CredentialInfo>;
            }>;
        }>;
        set(request: {
            ref: string;
            value: string;
        }): Promise<unknown>;
    };
    workspace: {
        list(request: object): Promise<{
            result: RemoteResult<{
                items: readonly {
                    workspaceId: string;
                    path: string;
                    title: string;
                }[];
            }>;
        }>;
    };
}
export declare function cardApi(ctx: Context): CardApi;
