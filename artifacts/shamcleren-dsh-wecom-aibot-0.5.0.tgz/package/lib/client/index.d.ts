import type { Context as ClientContext } from '@deepseek-ai/cordis';
import { type LocaleKey } from './locales.js';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** Copy owned by the external WeCom settings card. */
        'settings.wecom': LocaleKey;
    }
}
export declare const inject: string[];
/** Register the WeCom card when the generic plugin-settings slot exists. */
export declare function apply(ctx: ClientContext): void;
