import type { Context as ClientContext } from '@deepseek-ai/cordis';
import { type LocaleKey } from './locales.js';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** Copy owned by the external WeCom settings card. */
        'settings.wecom': LocaleKey;
    }
}
/**
 * Each Remote namespace is its own Cordis service keyed `remote.<namespace>`;
 * injecting `remote` alone resolves the mount point but not the namespaces this
 * card calls, and every call then throws before reaching the wire.
 */
export declare const inject: string[];
/** Register the WeCom card when the generic plugin-settings slot exists. */
export declare function apply(ctx: ClientContext): void;
