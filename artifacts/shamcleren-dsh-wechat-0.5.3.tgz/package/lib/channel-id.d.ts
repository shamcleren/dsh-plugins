/** Visible sidebar mark for personal WeChat sessions. */
export declare const CHANNEL_TITLE_MARK = "\u3010\u5FAE\u4FE1\u3011";
/** Durable Session id prefix owned by this channel. */
export declare const CHANNEL_SESSION_PREFIX = "session-wechat-";
/** Whether this Session was created by the personal WeChat channel. */
export declare function isChannelSession(sessionId: string): boolean;
/** Prefix a title without duplicating the channel mark. */
export declare function channelTitle(title?: string): string;
