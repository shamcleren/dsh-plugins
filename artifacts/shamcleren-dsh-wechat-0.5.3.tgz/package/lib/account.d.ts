import type { Logger } from '@deepseek-ai/cordis';
import type { WeChatInboundMessage } from './inbound.js';
import type { WeChatAccountCredentials } from './protocol.js';
import type { WeChatAccountStore } from './storage.js';
/** Long-lived iLink account transport and outbound reply operations. */
export declare class WeChatAccount {
    readonly credentials: WeChatAccountCredentials;
    private readonly store;
    private readonly logger;
    private readonly mediaMaxBytes;
    private readonly onMessage;
    private readonly abort;
    private readonly messageFailures;
    private task;
    constructor(credentials: WeChatAccountCredentials, store: WeChatAccountStore, logger: Logger, mediaMaxBytes: number, onMessage: (message: WeChatInboundMessage) => Promise<void>);
    start(): void;
    stop(): Promise<void>;
    sendText(userId: string, text: string, contextToken?: string): Promise<void>;
    sendImage(userId: string, bytes: Buffer, contextToken?: string): Promise<void>;
    typing(userId: string, status: 1 | 2, contextToken?: string): Promise<void>;
    private monitor;
}
