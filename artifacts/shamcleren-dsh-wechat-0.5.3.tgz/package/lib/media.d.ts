import type { CdnMedia } from './protocol.js';
/** Download and decrypt one iLink CDN object with AES-128-ECB. */
export declare function downloadMedia(media: CdnMedia, key: string | undefined, cdnBaseUrl: string, maxBytes: number): Promise<Buffer>;
/**
 * Encrypt one image, publish it to the iLink CDN and return the reference an
 * outbound `image_item` needs. This is the inverse of `downloadMedia`: the peer
 * decrypts with the key carried in the reference, so the key travels as raw bytes
 * in base64 while `getuploadurl` wants the same key as hex.
 */
export declare function uploadImage(request: {
    baseUrl: string;
    token: string;
    userId: string;
    bytes: Buffer;
    cdnBaseUrl: string;
    signal?: AbortSignal;
}): Promise<{
    media: CdnMedia;
    midSize: number;
}>;
