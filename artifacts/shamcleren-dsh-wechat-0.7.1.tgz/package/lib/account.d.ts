import type { Logger } from '@deepseek-ai/cordis';
import type { WeChatInboundMessage } from './inbound.js';
import type { WeChatAccountCredentials } from './protocol.js';
import type { WeChatAccountStore } from './storage.js';
import type { WeChatDelivery } from './delivery.js';
/** Long-lived iLink account transport and outbound reply operations. */
export declare class WeChatAccount {
    readonly credentials: WeChatAccountCredentials;
    private readonly store;
    private readonly logger;
    private readonly mediaMaxBytes;
    private readonly onMessage;
    private readonly delivery?;
    private readonly abort;
    private readonly messageFailures;
    private task;
    constructor(credentials: WeChatAccountCredentials, store: WeChatAccountStore, logger: Logger, mediaMaxBytes: number, onMessage: (message: WeChatInboundMessage) => Promise<void>, delivery?: WeChatDelivery | undefined);
    start(): void;
    stop(): Promise<void>;
    sendText(userId: string, text: string, contextToken?: string): Promise<void>;
    sendImage(userId: string, bytes: Buffer, contextToken?: string): Promise<void>;
    sendFile(userId: string, bytes: Buffer, name: string, contextToken?: string): Promise<void>;
    sendVideo(userId: string, bytes: Buffer, contextToken?: string): Promise<void>;
    private sendBinary;
    private send;
    typing(userId: string, status: 1 | 2, contextToken?: string): Promise<void>;
    private monitor;
}
