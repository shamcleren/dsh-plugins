import type { Context } from '@deepseek-ai/cordis';
interface BotModel {
    provider: string;
    model: string;
    reasoningEffort?: string;
}
/** Use public Agent waterfalls without persisting the deployment-wide model default. */
export declare class ConversationModels {
    private readonly ctx;
    private readonly selections;
    constructor(ctx: Context);
    current(id: string): BotModel | undefined;
    /** Read the durable choice after restart without changing it or creating an Agent. */
    describe(id: string): Promise<BotModel | undefined>;
    select(id: string, requested: BotModel): Promise<BotModel>;
}
export {};
