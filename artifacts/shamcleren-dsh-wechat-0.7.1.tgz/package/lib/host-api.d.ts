import type { Context } from '@deepseek-ai/cordis';
import type { PromptContentPart as HostPromptContentPart } from '@deepseek-ai/dsh-api-session-controller/types';
/** Minimal same-process Host API used by the channel plugin. */
export interface RpcRequest<T> {
    rpcId: string;
    payload: T;
}
export type RpcResult<T> = {
    ok: true;
    value: T;
} | {
    ok: false;
    error: {
        code: string;
        message: string;
    };
};
export interface RpcResponse<T> {
    rpcId: string;
    result: RpcResult<T>;
}
export interface HostSessionEvent {
    type: string;
    seq: number;
    data: unknown;
}
export interface SessionEventFrame {
    type: 'session/event';
    sessionId: string;
    event: HostSessionEvent;
}
export interface AskUserQuestionOption {
    label: string;
    description?: string;
}
export interface AskUserQuestionItem {
    id: string;
    question: string;
    detail?: string;
    header?: string;
    options?: AskUserQuestionOption[];
    multiSelect?: boolean;
}
export interface AskUserQuestionAnswerItem {
    id: string;
    selected: string[];
    custom?: string;
}
export interface QuestionRequestedFrame {
    type: 'question/requested';
    sessionId: string;
    questions: AskUserQuestionItem[];
}
export interface QuestionResolvedFrame {
    type: 'question/resolved';
    sessionId: string;
    questionRpcId: string;
    outcome: 'answered' | 'cancelled';
}
export type HostMuxFrame = SessionEventFrame | QuestionRequestedFrame | QuestionResolvedFrame | {
    type: string;
    sessionId?: string;
};
export interface ClientResponse {
    type: 'client-response';
    rpcId: string;
    result: RpcResult<unknown>;
}
export type RpcReceipt = {
    accepted: true;
} | {
    accepted: false;
    reason: 'not-pending' | 'bad-response';
};
export interface HistoryEntry {
    event: HostSessionEvent;
}
export type PromptContentPart = HostPromptContentPart | {
    type: 'file-bytes';
    data: string;
    name: string;
};
/** Agent preset row projected for channel command output. */
export interface HostPreset {
    id: string;
    name?: string;
    description?: string;
    /** Why this preset cannot compose a session, absent when it can. */
    broken?: string;
}
/** Host Workspace projection used for channel routing and command output. */
export interface HostWorkspace {
    workspaceId: string;
    path: string;
    title: string;
    sessionIds: string[];
}
export interface HostApiProxy {
    /** Release questions owned by a retiring channel router. */
    releaseSession?(sessionId: string): void;
    workspace: {
        list(request: RpcRequest<Record<string, never>>): Promise<RpcResponse<{
            items: HostWorkspace[];
            archivedSessionIds: string[];
        }>>;
        create(request: RpcRequest<{
            path: string;
        }>): Promise<RpcResponse<{
            workspace: HostWorkspace;
            created: boolean;
        }>>;
        rename(request: RpcRequest<{
            workspaceId: string;
            title: string;
        }>): Promise<RpcResponse<{
            workspace: HostWorkspace;
        }>>;
    };
    presets: {
        list(request: RpcRequest<Record<string, never>>): Promise<RpcResponse<{
            items: HostPreset[];
            defaultId: string;
        }>>;
    };
    sessions: {
        create(request: RpcRequest<{
            sessionId: string;
            workspaceId?: string;
            agentPreset?: string;
        }>): Promise<RpcResponse<{
            sessionId: string;
            agentPreset?: string;
        }>>;
        history(request: RpcRequest<{
            sessionId: string;
            beforeSeq?: number;
            maxMessages?: number;
        }>): Promise<RpcResponse<{
            events: HistoryEntry[];
            hasMore: boolean;
        }>>;
        prompt(request: RpcRequest<{
            sessionId: string;
            mode: 'queue' | 'steer';
            content: PromptContentPart[];
        }>): Promise<RpcResponse<{
            accepted: true;
            command?: {
                kind: 'success';
                text?: string;
            };
        }>>;
        cancel(request: RpcRequest<{
            sessionId: string;
        }>): Promise<RpcResponse<{
            accepted: true;
        }>>;
        models(request: RpcRequest<{
            sessionId: string;
        }>): Promise<RpcResponse<{
            current: {
                provider: string;
                model: string;
                reasoningEffort?: string;
            };
            groups: Array<{
                id: string;
                name: string;
                models: Array<{
                    id: string;
                    name: string;
                    reasoning?: {
                        efforts: Array<{
                            id: string;
                            name: string;
                        }>;
                        defaultEffort?: string;
                    };
                }>;
            }>;
        }>>;
        selectModel(request: RpcRequest<{
            sessionId: string;
            provider: string;
            model: string;
            reasoningEffort?: string;
        }>): Promise<RpcResponse<{
            selected: {
                provider: string;
                model: string;
                reasoningEffort?: string;
            };
        }>>;
    };
    events: {
        mux(request: RpcRequest<Record<string, never>>, signal: AbortSignal): AsyncIterable<RpcRequest<HostMuxFrame>>;
    };
    respond(message: ClientResponse): Promise<RpcReceipt>;
}
/** Host business error retaining its stable RPC code for recovery decisions. */
export declare class HostApiError extends Error {
    readonly code: string;
    constructor(code: string, message: string);
}
/** Return a successful unary value or raise the Host's business error. */
export declare function unwrap<T>(response: RpcResponse<T>): T;
/**
 * Submit through upstream queue/steer and report the channel's reply ownership.
 * A rejected steer may be queued once when the previous turn ended before admission.
 */
export declare function submitChannelPrompt(api: HostApiProxy, request: Parameters<HostApiProxy['sessions']['prompt']>[0]): Promise<{
    rpcId: string;
    result: {
        ok: false;
        error: {
            code: string;
            message: string;
        };
    };
} | {
    rpcId: string;
    result: {
        ok: true;
        value: {
            accepted: true;
            command?: {
                kind: 'success';
                text?: string;
            };
            disposition: "next-step" | "next-turn";
        };
    };
}>;
/** Translate this channel's local transport contract onto the public DSH controllers. */
export declare function createHostApi(ctx: Context, routesSession: (sessionId: string) => boolean): HostApiProxy;
