/**
 * Host HTTP routes that expose the scanned pet packs and their spritesheets to
 * the browser settings card. The card renders one clickable thumbnail per pack
 * by pointing each spritesheet at its first cell, mirroring the Codex pet
 * picker instead of asking the user to type an opaque pet id.
 *
 * Both routes are loopback-only (the host WebServer binds 127.0.0.1), read-only,
 * and serve the user's own already-copied assets, so they are treated like the
 * shell's public non-index static assets rather than authenticated index
 * responses.
 */
import type { Context } from '@deepseek-ai/cordis';
import type { PetPack } from './packs.js';
import { type PetPickerItem } from './shared/picker.js';
/** Project one scanned pack into the JSON row the browser picker consumes. */
export declare function petListItem(pack: PetPack): PetPickerItem;
/**
 * Resolve a sprite request pathname to a known pack id, or null. The id must
 * be a single path segment that names a scanned pack — this rejects traversal
 * segments and unknown ids before any file is read.
 */
export declare function resolveSpritePetId(pathname: string, packs: PetPack[]): string | null;
/**
 * Register the picker JSON route, the spritesheet route, and the pending-
 * activation route on the host WebServer. Each registration is owned by the
 * provided context so disposal withdraws all routes together.
 */
export declare function registerPetRoutes(ctx: Context, packsDir: string, getPacks: () => PetPack[], activation: {
    consumeActivation: () => string | null;
}): void;
