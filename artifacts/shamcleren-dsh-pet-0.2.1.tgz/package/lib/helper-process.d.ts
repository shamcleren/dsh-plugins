/**
 * Owns the spawned native Helper process: pipes stdio, parses inbound
 * newline-delimited JSON messages, and reports lifecycle. A crashed helper is
 * restarted by the caller (not here) so the restart policy stays in one place.
 */
import { type CompanionMessage, type MessageKind } from './protocol.js';
export interface HelperProcessOptions {
    binaryPath: string;
    onMessage: (message: CompanionMessage) => void;
    onError: (error: Error) => void;
    onExit: (code: number | null, signal: NodeJS.Signals | null) => void;
    onStderr: (line: string) => void;
}
export declare class HelperProcess {
    private readonly options;
    private child;
    private buffer;
    private stopped;
    private stopping;
    constructor(options: HelperProcessOptions);
    get running(): boolean;
    start(): void;
    private ingest;
    send(kind: MessageKind, payload?: Record<string, unknown>): boolean;
    /**
     * Ask the Helper to shut down and wait until its stdio has closed. Waiting
     * for `close` (rather than only `exit`) guarantees that the final `move`
     * snapshot emitted before `closed` has reached the host.
     */
    stop(): Promise<void>;
}
