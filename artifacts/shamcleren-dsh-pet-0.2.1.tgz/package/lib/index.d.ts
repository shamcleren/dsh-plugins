/**
 * desktop-pet — a desktop floating pet for DeepSeek Harness, reusing the
 * Codex/OpenAI pet asset packs. Host-only: reduces session events into a pet
 * state and drives a bundled native Helper (transparent always-on-top window)
 * over a stdio JSON protocol. No DSH app-shell changes are required.
 */
import type { Context } from '@deepseek-ai/cordis';
import { Config } from './config.js';
export { Config } from './config.js';
export type { Config as DesktopPetConfig } from './config.js';
export { PetSettings } from './config.js';
export { MessageKind } from './protocol.js';
export { HelperProcess } from './helper-process.js';
export { PetStatusTracker } from './status.js';
export declare const name = "desktop-pet";
export declare function apply(ctx: Context, config: Config): void;
