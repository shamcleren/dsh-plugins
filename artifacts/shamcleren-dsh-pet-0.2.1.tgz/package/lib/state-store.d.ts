/**
 * Runtime window-position persistence under `DSH_HOME/desktop-pet/state.json`.
 * Pet selection and size are owned by the host settings provider
 * (`desktop-pet` namespace); this store keeps only the latest pet coordinate so
 * it survives restarts independently of settings. New writes persist the
 * pet's bottom-center screen anchor rather than the resizable panel origin, so
 * task-card growth cannot move the pet. Legacy panel origins remain readable.
 */
/** Screen coordinate in AppKit's y-up coordinate space. */
export interface Position {
    x: number;
    y: number;
}
export type PositionMode = 'panel-origin' | 'pet-anchor';
export interface PanelState {
    /** Latest coordinate in the space described by `positionMode`. */
    position: Position | null;
    /** Missing legacy values are interpreted as a panel origin. */
    positionMode: PositionMode;
}
export declare class PanelStateStore {
    private readonly file;
    private state;
    constructor(file: string);
    load(): Promise<PanelState>;
    update(patch: {
        position?: Position | null;
        positionMode?: PositionMode;
    }): Promise<PanelState>;
}
