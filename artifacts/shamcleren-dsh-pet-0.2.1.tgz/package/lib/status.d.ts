/**
 * Aggregates DeepSeek Harness agent/session events into the pet display
 * snapshot (sprite animation + status bubble). The pet is a single
 * always-on-top window, so concurrent sessions reduce to the highest-priority
 * phase, mirroring Codex's task-state priority:
 *
 *   needs input (waiting) > blocked (error) > ready (review) > running
 *
 * `thinking` stays below `running`; `idle` is the floor.
 */
import type { Context } from '@deepseek-ai/cordis';
import { type PetDisplay } from './shared/state.js';
type CopyGroup = 'idle' | 'preparing' | 'thinking' | 'searching' | 'editing' | 'testing' | 'commanding' | 'working' | 'result' | 'waiting' | 'approval' | 'success' | 'error' | 'stopped';
type Activity = 'searching' | 'editing' | 'testing' | 'commanding' | 'using-tool';
export declare function toolActivity(name: string): Activity;
export declare function groupOf(activity: Activity): CopyGroup;
type DisplayListener = (display: PetDisplay) => void;
export declare class PetStatusTracker {
    private readonly ctx;
    private readonly now;
    private readonly records;
    private readonly listeners;
    private readonly disposers;
    private pulseTimer;
    private refreshTimer;
    private lastSignature;
    private clock;
    constructor(ctx: Context, now?: () => number);
    start(listener: DisplayListener): void;
    currentDisplay(): PetDisplay;
    dispose(): void;
    /** Mark a completed result as seen after the user clicks its task row. */
    acknowledge(id: string): void;
    private handleEvent;
    private record;
    private update;
    private emit;
    private emitErrorPulse;
    private emitStoppedPulse;
    private emitPulse;
    private clearPulse;
    private bubbleFor;
    private compute;
}
export {};
