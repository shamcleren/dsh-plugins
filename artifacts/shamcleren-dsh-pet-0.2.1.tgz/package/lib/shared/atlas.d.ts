/**
 * Codex pet atlas layout, reverse-engineered from the ChatGPT pet renderer and
 * verified against the reference pet packs (`1536×1872` v1, `1536×2288` v2).
 *
 * The atlas is selected by pixel dimensions, not by the manifest version field.
 */
export type SpriteVersion = 1 | 2;
export interface AtlasLayout {
    version: SpriteVersion;
    width: number;
    height: number;
    cellWidth: number;
    cellHeight: number;
    columns: number;
    rows: number;
    /** Max frame count per row, used only to validate a frame reference. */
    requiredFramesByRow: number[];
}
export declare const ATLAS_V1: AtlasLayout;
export declare const ATLAS_V2: AtlasLayout;
/** Select the atlas that matches the given pixel dimensions, or null. */
export declare function atlasForDimensions(width: number, height: number): AtlasLayout | null;
/** Row count for a manifest sprite version (default 1 when omitted). */
export declare function rowCountForVersion(version: number | undefined): number;
