/**
 * Codex pet animation engine, reverse-engineered to exact parity from the
 * ChatGPT pet renderer (`app-initial` bundle).
 *
 * Naming mirrors the original for auditability:
 * - `i4(row, count, baseMs, lastMs)` — frame builder.
 * - `Jlo` — idle base frames (row 0), `Ylo` — idle frames × 6.
 * - `Xlo` — state → frame list.
 * - `Ulo(state, isStatic)` — animation sequence.
 * - `Glo(frame, rowCount)` — CSS background-position.
 * - `auo(rect, cursor, version)` — look-direction frame (v2 only).
 */
import type { AtlasLayout, SpriteVersion } from './atlas.js';
import { ATLAS_V1, ATLAS_V2, rowCountForVersion } from './atlas.js';
import type { PetState } from './state.js';
export interface FrameRef {
    columnIndex: number;
    rowIndex: number;
    frameDurationMs: number;
}
export interface AnimationSequence {
    frames: FrameRef[];
    loopStartIndex: number | null;
}
/** Frame builder: `count` frames in `row`, base duration `baseMs`, last frame `lastMs`. */
declare function i4(row: number, count: number, baseMs: number, lastMs: number): FrameRef[];
/** Frame accessor; throws RangeError on out-of-range index (parity with original). */
declare function wlo(frames: FrameRef[], index: number): FrameRef;
/**
 * Build the animation sequence for a state.
 * - `isStatic`: single frame preview (no loop).
 * - `idle`: `Ylo` frames, loop from index 0.
 * - otherwise: state frames × 3 followed by `Ylo`, loop restarting after the tripled frames.
 */
export declare function sequenceFor(state: PetState, isStatic?: boolean): AnimationSequence;
/** CSS `background-position` for a frame within an atlas of `rowCount` rows. */
export declare function backgroundPosition(frame: FrameRef, rowCount: number): string;
/** CSS `background-size` for a full atlas of `rowCount` rows (8 columns fixed). */
export declare function backgroundSize(rowCount: number): string;
export interface PetRect {
    left: number;
    top: number;
    width: number;
    height: number;
}
export interface Point {
    x: number;
    y: number;
}
/**
 * Look-direction frame toward the cursor. Returns null when outside the dead
 * zone or when the atlas is v1 (no look rows).
 */
export declare function lookFrame(rect: PetRect, cursor: Point, version: SpriteVersion): FrameRef | null;
/** Exposed for tests: the base idle frames and the state frame map. */
export declare const __internal: {
    JLO: FrameRef[];
    YLO: FrameRef[];
    XLO: Record<"running" | "waiting" | "failed" | "review" | "waving" | "jumping" | "running-left" | "running-right", FrameRef[]>;
    i4: typeof i4;
    wlo: typeof wlo;
};
export type { AtlasLayout };
export { ATLAS_V1, ATLAS_V2, rowCountForVersion };
