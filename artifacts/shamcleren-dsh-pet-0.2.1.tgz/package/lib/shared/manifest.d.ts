/**
 * Codex pet manifest (`pet.json`) schema and validation.
 *
 * Manifest keys observed in the reference packs: `id`, `displayName`,
 * `description`, `kind` (optional), `spriteVersionNumber` (optional; 2 → v2,
 * omitted → v1), `spritesheetPath`.
 */
export interface PetManifest {
    id: string;
    displayName: string;
    description?: string;
    kind?: string;
    spriteVersionNumber?: 1 | 2;
    spritesheetPath: string;
}
/** Parse an unknown JSON value into a validated manifest, throwing on invalid input. */
export declare function parsePetManifest(raw: string): PetManifest;
