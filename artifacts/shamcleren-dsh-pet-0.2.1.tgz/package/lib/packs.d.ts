/**
 * Pet pack scanning, validation, and idempotent copy from the source directory
 * into `DSH_HOME/desktop-pet/packs/`.
 */
export interface PetPack {
    id: string;
    displayName: string;
    description?: string;
    spriteVersionNumber?: 1 | 2;
    spritesheetPath: string;
    /** Absolute directory containing pet.json and its spritesheet. */
    directory: string;
    /** Pixel width of the spritesheet, read from its WebP header. */
    spriteWidth: number;
    /** Pixel height of the spritesheet, read from its WebP header. */
    spriteHeight: number;
}
export interface ScanResult {
    packs: PetPack[];
    errors: string[];
}
export interface SyncPacksOptions {
    /** Report an unreadable source as an error. Optional import sources disable this. */
    missingSourceIsError?: boolean;
    /** Ignore retired or package-reserved ids while importing an external source. */
    excludedIds?: readonly string[];
}
/**
 * Copy each valid source pack into `targetDir/<id>/` idempotently. Returns the
 * list of packs now present in the target directory, plus per-pack errors.
 */
export declare function syncPacks(sourceDir: string, targetDir: string, options?: SyncPacksOptions): Promise<ScanResult>;
/**
 * Remove a retired bundled id only when its spritesheet is byte-for-byte the
 * same as the replacement. User-modified packs are deliberately preserved.
 */
export declare function retireBundledAlias(targetDir: string, legacyId: string, replacementDir: string): Promise<boolean>;
/** Enumerate valid packs already present in the target directory. */
export declare function scanTarget(targetDir: string): Promise<PetPack[]>;
/** Resolve the selected pack id, falling back to the first pack. */
export declare function resolveSelection(packs: PetPack[], requestedId: string): PetPack | undefined;
