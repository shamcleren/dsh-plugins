/** Settings-scope projection, live writes, and pet-list fetch for the browser card. */
import type { SettingsScope } from '@deepseek-ai/dsh-client-ui-settings/client';
import type { PetSettings } from '../config.js';
import { type PetPickerItem } from '../shared/picker.js';
type SnapshotStore<T> = {
    getSnapshot(): T;
    subscribe(listener: () => void): () => void;
    set(value: T): void;
};
export interface DesktopPetCardState {
    enabled: boolean;
    /** Currently selected pet id, resolved from the settings scope. */
    petId: string;
    petSizeDraft: string;
    /** Pets offered by the thumbnail picker. */
    pets: PetPickerItem[];
    petsLoading: boolean;
    petsFailed: boolean;
    available: boolean;
    writable: boolean;
}
export interface DesktopPetCardFace {
    hooks: {
        desktopPetCard: SnapshotStore<DesktopPetCardState>;
    };
    setEnabled(value: boolean): void;
    selectPet(id: string): void;
    editPetSize(text: string): void;
    commitPetSize(): void;
}
/** Validate an untrusted picker-route payload into `PetPickerItem` rows. */
export declare function parsePets(value: unknown): PetPickerItem[];
/** Live-editing controller: pet size edits are staged locally, selection commits immediately. */
export declare class DesktopPetCardController {
    private readonly scope;
    private readonly store;
    private petSizeDraft;
    private pets;
    private petsLoading;
    private petsFailed;
    private disposed;
    constructor(scope: SettingsScope<PetSettings>);
    inject(): DesktopPetCardFace;
    /** Stop background work so a late fetch cannot publish into a dead card. */
    dispose(): void;
    private loadPets;
    private projection;
    private publish;
}
export {};
