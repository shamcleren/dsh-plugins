/** Browser copy owned by the desktop-pet plugin. */
export declare const en: {
    readonly title: "Desktop Pet";
    readonly description: "Configure the desktop floating pet.";
    readonly enabled: "Enable desktop pet";
    readonly enabledHint: "Show or hide the floating pet window.";
    readonly on: "Enabled";
    readonly off: "Disabled";
    readonly pet: "Pet";
    readonly petHint: "Select the pet to display. Copy packs into the desktop-pet packs directory to add more.";
    readonly petsLoading: "Loading pets…";
    readonly petsError: "Could not load pets from the desktop-pet packs directory.";
    readonly petsEmpty: "No pets found. Copy a Codex pet pack into the desktop-pet packs directory.";
    readonly petSize: "Pet size (px)";
    readonly petSizeHint: "Sprite width in pixels, 80–224.";
    readonly invalid: "Enter a valid value.";
    readonly readOnly: "This deployment stores settings read-only.";
};
export declare const zh: Record<keyof typeof en, string>;
export type LocaleKey = keyof typeof en;
