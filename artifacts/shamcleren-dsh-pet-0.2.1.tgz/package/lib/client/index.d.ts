/** Browser half of the desktop-pet plugin: contributes its own settings card
 * and polls the host's pending-activation route to open the chat window a
 * pet task click requested. */
import type { Context as ClientContext } from '@deepseek-ai/cordis';
import { type LocaleKey } from './locales.js';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** Copy owned by the external desktop-pet settings card. */
        'settings.desktop-pet': LocaleKey;
    }
}
export declare const inject: string[];
/** Register the desktop-pet card in the generic plugin-settings slot. */
export declare function apply(ctx: ClientContext): void;
