/** Self-contained desktop-pet settings card contributed through `settings.plugin.item`. */
import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { DesktopPetCardFace } from './controller.js';
export type DesktopPetCardProps = PropsRuntime<'settings.plugin.item'> & PropsLocale<'settings.desktop-pet'> & InjectFace<DesktopPetCardFace>;
export declare function DesktopPetCard(props: DesktopPetCardProps): import("react").JSX.Element;
