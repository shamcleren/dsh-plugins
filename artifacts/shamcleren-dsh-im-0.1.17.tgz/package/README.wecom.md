# WeCom adapter in `@shamcleren/dsh-im`

WeCom AI Bot channel package for DeepSeek Harness.

## Install

Install the unified `im` release and open **IM workbench → WeCom**. See the [IM guide](README.md) for installation and legacy migration, and the [plugin management guide](../../docs/plugin-management.md) for development commands. The source package is `plugins/im`. Installation does not configure Bot credentials or complete account authorization.

## Current milestone

The package connects the official WeCom AI Bot WebSocket SDK to the same-process DeepSeek Harness Host API. It accepts text, image, mixed, voice-transcription, file and video callbacks, creates or resumes a deterministic durable session for each direct or group conversation, suppresses a previously admitted `msgid`, and submits messages through upstream `queue` and `steer` admission. A channel-owned active turn receives steering and an immediate acknowledgement. Other messages queue; a steer rejected as `agent-busy` retries once as queued input. The original WeCom stream remains the main output and accumulates assistant text across model steps.

The adapter always mounts so it remains configurable. Reception defaults off for new installations: enable it in the unified settings after configuring credentials and access. The SDK then connects when both credential references resolve and disconnects when reception is disabled or credentials are cleared. Headless deployments can set `connectionEnabled: true` in the retained `wecom-aibot` configuration scope; environment variables remain a credential fallback. IM installs the Host adapters and one client UI without modifying DeepSeek Harness. Tests cover Host/SDK boundaries; no live Bot message smoke is claimed. See the repository-level [design document](../../docs/plugins/wecom-aibot.md).

## Configuration

| Field | Default | Meaning |
| --- | --- | --- |
| `botIdEnv` | `WECOM_BOT_ID` | Credential reference containing the WeCom Bot ID. |
| `secretEnv` | `WECOM_BOT_SECRET` | Credential reference containing the WeCom Bot secret. |
| `allowedUsers` | `[]` | WeCom userids allowed to send messages. An empty list accepts every user visible to the Bot. |
| `adminUsers` | `[]` | WeCom userids allowed to run `/help`, `/status`, `/new`, `/session`, `/workspace`, `/preset`, `/model`, `/effort`, and `/compact`. `/whoami` is open to everyone. |
| `workspaceId` | omitted | Existing Harness Workspace used by new conversations. The settings card lists the current Workspace registry. |
| `workspaceName` | `企业微信机器人` | Title of the managed fallback Workspace created when `workspaceId` is omitted. |
| `preventIdleSleep` | `false` | On macOS, run a managed idle-sleep assertion while the Bot is active. |
| `agentPreset` | omitted | Harness agent preset used when a new WeCom session is created. Omitted inherits the deployment default. |
| `thinkingText` | `正在思考…` | Initial content of the WeCom stream while the Harness turn starts. |
| `turnTimeoutMs` | `300000` | Maximum observation time for one admitted Harness turn. |

The reference fields are names, not credential literals. The plugin resolves the Host credentials service first and then the process environment. Installing the plugin without both values keeps it disconnected and emits one warning per unconfigured streak; writing either referenced credential or changing settings reconciles the connection without remounting the plugin.

The settings card shows Bot ID, Secret, the two userid lists, and the default Workspace directly, and keeps `preventIdleSleep`, `agentPreset`, `thinkingText`, and `turnTimeoutMs` in the **Advanced settings** section. `botIdEnv`, `secretEnv`, and `workspaceName` stay configuration-file only.

The UI stores Bot ID and Secret through the Host credentials API, never in the settings document or a browser response. A save that does not land names the fields the deployment refused, and a credential write reports the deployment's own refusal text — or, when the write was accepted while the reference still reads unconfigured, says exactly that. Refusal text is diagnostic only and never carries the value back. Ordinary settings and credentials remain under the Harness home and survive application restarts.

Both lists match `from.userid` exactly and case-sensitively, and that value is not always the account name the WeCom console displays: [WeCom sends a plaintext userid only when the Bot's creator is a corp super admin](https://developer.work.weixin.qq.com/document/path/100719), and otherwise sends the corp-scoped encrypted userid. Because no console screen shows that encrypted value, `/whoami` answers every sender with the identity the Bot received, and both refusals — the allowlist rejection and the administrator-only command rejection — carry it too. A sender only ever learns their own identity this way.

Conversation and prompt identities are SHA-256-derived from the Bot and WeCom identifiers. Raw userids and chatids do not appear in Harness session ids. Deduplication reads the Host's durable `rpcId` admission receipt, so replaying a callback after restart does not enqueue another turn.

When a deterministic conversation id already belongs to a pre-Workspace release with another cwd, the plugin creates a new channel-Workspace Session, persists that active binding, and retains the legacy Session unchanged.

The plugin persists the hashed conversation key, the current opaque Session id, and the conversation's Session history under the Harness home. `/session` shows titles, Workspaces and stable selection numbers for the current chat. `/session list <page>` changes the page and `/session <number>` switches the active Session for future messages, including after a restart. Archived and deleted Sessions are excluded. Existing installations retain the active Session and start tracking history from there. Earlier WeCom Sessions can still be opened in the App.

`/workspace` reports the current and default Workspaces. `/workspace <name-or-id>` creates a Session in the selected Workspace and switches the conversation after creation succeeds. `/workspace reset` returns it to the configured default. Duplicate display names require the stable Workspace id. `/new` creates a Session in the conversation's current Workspace. Management commands are an explicit allowlist.

`/preset` follows the [channel default policy](../../docs/decisions/channel-default-policy.md) and is channel-local. The settings card selects the same value from the deployment preset roster; the first option follows the deployment default, and a roster that cannot be read does not fall back to a free-text preset. It reports the roster and the preset the channel currently names, `/preset <id>` pins one, and `/preset reset` clears the pin so new Sessions inherit the deployment default again. A pin is written to this plugin's own settings section through path ops, so it survives restarts and never touches a deployment-wide default; an unknown or broken preset is refused before anything is written, and a refused write is reported rather than reported as applied. Because a Session names its preset at creation and keeps it for life, the switch rebuilds the conversation's Session and leaves the prior one intact. The preset is deliberately outside the connection key so persisting it does not reopen the socket carrying the command's own reply. A deployment that mounts no preset registry still accepts `/preset <id>`; only the roster listing is unavailable.

`/model` and `/effort` change only the current conversation. The channel validates the requested model and uses the public Agent prompt-assembly and request waterfalls, persisting `model/selection` without saving the deployment-wide default. A Bot’s configured `model` initializes new conversations; existing conversations keep their selection. An unset model (including an empty object saved by an older settings form) inherits the Host default. A partial model selection is rejected before connecting.

When an active WeCom turn requests approval, the plugin intercepts its channel-owned request through the upstream approval waterfall and sends an Allow/Reject template card as a standalone message alongside the existing reply stream. The card presents the tool, the approval reason within WeCom's template limits, and the command recovered from the request's exact `callId`; command visibility follows the same Session ownership as the surrounding WeCom conversation and is not additionally redacted. Clicking a button first updates the title to `已允许` or `已拒绝` and uses WeCom's `replace_text` field to replace the decisions with a gray non-clickable `操作成功` state, then resumes or rejects the Host operation. `/approve` and `/reject` remain text fallbacks. Web and WeCom do not present the same approval concurrently. Unrelated requests delegate to the Host UI. Only the user who started the WeCom turn can decide; the upstream approval service owns the canonical audit record. Approval prompts, resolution notices, continuation acknowledgements, and final replies use the SDK's ordered reliable path; high-frequency text updates use its best-effort non-blocking path. Ask and approve requests for an active WeCom turn stay on WeCom even though DSH scopes those events to the Agent fiber.

Channel sessions keep a `【企业微信】` title prefix after DSH generates a title, and the session header shows a WeCom badge. The sidebar has no public row-icon slot, so list identity is the title prefix.

An interaction ends the current stream before waiting for the human. A text `/approve`, `/reject`, or final `/answer` receives a completed acknowledgement on that reply callback. After either a text answer or template-card click, the plugin buffers the remaining turn and sends its final text as a new proactive Markdown message. Earlier assistant text remains in the earlier bubble instead of being copied or reordered around the user's decision.

`ask_user_question` shows numbered questions, choices and supporting detail in text. Short, single-line single-select questions with up to six short options also get native buttons. Consecutive eligible questions reuse the card, and an ineligible next question closes it with a text reply example. Long or multiline content, multi-select, free-text, and larger option sets use text. If the reply exceeds the stream limit, WeCom receives the full question in ordered text messages.

For one question, `/answer 1` selects the first option. You can also reply with the full option label or type a custom answer. For a batch, `/answer 2 1` selects the first option for question 2. Comma-separated values select multiple choices where allowed. Answers retain the caller's stable question ids and are submitted as one Host response after the batch is complete. Web and WeCom share the Host request, so the first valid response wins.

The question answerer claims active WeCom turns before the Host Web answerer, regardless of listener registration order. Questions from other sessions continue through the Host waterfall.

## Channel compatibility

Observed WeCom channel text callbacks use `chattype: "group"` with `compat_info.source: "channel"`. They follow the existing group conversation route and preserve the callback's conversation identifier. A regression fixture covers this callback shape. Dedicated `topic_at_bot` events, isolation between channel posts, proactive messages, and template-card delivery inside posts still require live verification; accepting compatible text callbacks does not establish those capabilities.

## Known limitations

- User messages are limited to text; template-card click events are handled. Images, voice, files, video, mixed messages, and proactive sends are deferred.
- A turn's durable images are uploaded as WeCom temporary media and pushed as their own messages after the text reply. Whatever the deployment cannot upload or send is named in one notice rather than dropped silently. Voice, video, and files are still text-only.
- Group management commands accept the callback's leading Bot mention, such as `@dsh /help`; non-command text remains unchanged when sent to the Harness.
- Unloading the plugin stops its listeners, timers, and reply observation. A turn already admitted through the Host API remains Host-owned and may finish without sending another WeCom frame.

## Development

```sh
pnpm install
pnpm test
pnpm typecheck
pnpm build
```

The configuration card is available under **Plugins → this installed bundle** in DSH 0.1.6.


## Multiple Bots

In the plugin settings, select **Add Bot**, then configure each Bot’s credentials, default Workspace, model, administrator list and optional preset. Save before switching Bots. Existing single-Bot settings keep working; adding the first extra Bot preserves that connection’s credential references in a `default` entry. An explicit empty `bots` array disconnects every Bot. Disconnecting a Bot keeps its credentials and conversation history.

The `bots` array replaces the legacy top-level connection settings. Each entry has a unique stable `id` (1–64 letters, digits, underscores or hyphens), optional `name`, and the same settings as the legacy connection. Omitted credential references resolve to `WECOM_<id>_BOT_ID` and `WECOM_<id>_BOT_SECRET`. Never place credential values in this configuration. Fallback Workspaces use a separate directory per Bot (`default` preserves the legacy fallback directory), while explicit `workspaceId` values may intentionally name a shared Workspace. Configuring the same actual Bot account twice leaves both duplicate connections offline.

```yaml
- id: wecom-aibot
  config:
    bots:
      - id: development
        name: Development
        botIdEnv: WECOM_DEV_BOT_ID
        secretEnv: WECOM_DEV_BOT_SECRET
        workspaceId: workspace-project
        adminUsers: [your-userid]
        model:
          provider: your-provider
          model: your-model
      - id: writing
        name: Writing
        botIdEnv: WECOM_WRITING_BOT_ID
        secretEnv: WECOM_WRITING_BOT_SECRET
        model:
          provider: another-provider
          model: another-model
```

`/preset` persists only the sending Bot’s setting. `/workspace`, `/model` and `/effort` affect the current conversation. Bot identity participates in conversation and prompt keys, so two Bots in the same group do not share a Session.

## Media

Incoming images and mixed messages preserve both text and image bytes. Voice callbacks use WeCom’s transcription; files and videos are decrypted with the official SDK and staged through DSH’s Session-owned file upload receipts. Downloads enforce the per-message byte limit (default 10 MiB) and stop on unload. The model receives a normal file attachment; video understanding depends on the selected model/tools.

Outgoing images, explicit file attachments and successful `present` deliveries are uploaded through the official SDK, then sent to the originating conversation. Files ending in `.mp4`, `.m4v` or `.mov` use video messages. Paths are read through the public workspace filesystem, and prose links do not trigger reads. The default `mediaMaxBytes` is 10 MiB; failed or oversized files produce a count notice with a DSH fallback. No voice synthesis is added.
