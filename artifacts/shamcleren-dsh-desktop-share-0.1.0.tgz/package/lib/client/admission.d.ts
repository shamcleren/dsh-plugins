import type { ConversationController, InputActions } from '@deepseek-ai/dsh-client-ui-conversation/client';
import { type SharedBatch, type ShareTransport } from './transport.js';
export declare class ComposerBusy extends Error {
}
/** Capture the addressed composer before asynchronous reads; never resolve a new active session midway. */
export declare function admitBatch(transport: ShareTransport, batch: SharedBatch, signal: AbortSignal, conversation: Pick<ConversationController, 'createDrafts' | 'releaseDraftAttachments'>, sessionId: Parameters<ConversationController['createDrafts']>[0], actions: Pick<InputActions, 'addAttachments'>): Promise<void>;
