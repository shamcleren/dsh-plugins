export interface SharedFile {
    id: string;
    name: string;
    size: number;
}
export interface SharedBatch {
    id: string;
    files: SharedFile[];
}
export interface ShareTransport {
    postMessage(body: Record<string, unknown>): Promise<unknown>;
}
export declare function parseBatches(value: unknown): SharedBatch[];
/** Stream bounded bridge replies; no file path is ever accepted from the page. */
export declare function receiveFiles(transport: ShareTransport, batch: SharedBatch, signal: AbortSignal): Promise<File[]>;
