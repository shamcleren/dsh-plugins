export declare const en: {
    title: string;
    empty: string;
    waiting: string;
    add: string;
    adding: string;
    refresh: string;
    folder: string;
    error: string;
    busy: string;
    success: string;
    ackError: string;
};
export declare const zh: typeof en;
export type LocaleKey = keyof typeof en;
