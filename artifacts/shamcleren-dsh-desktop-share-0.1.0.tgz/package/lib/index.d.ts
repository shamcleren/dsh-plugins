/** The desktop bridge is browser-only; the Host has no extra file or network authority. */
export declare const name = "@shamcleren/dsh-desktop-share";
export declare function apply(): void;
