import type { Context } from '@deepseek-ai/cordis';
export declare const name = "security-audit-preset";
export declare const inject: string[];
/** Reopened audit sessions may launch/inspect scans, but cannot acquire ambient write tools. */
export declare function apply(ctx: Context): void;
