import { type LlmCallConfig } from '@deepseek-ai/dsh-llm';
import type { Context } from '@deepseek-ai/cordis';
import { type Review, type AdditionalFinding } from './report.js';
import { type AgentPolicy, type AgentAudit } from './agent-contract.js';
/** Remove common credential literals before code reaches the configured model or report. */
export declare function redactAgentText(value: string): string;
type Selection = LlmCallConfig;
export interface AgentReviewOptions {
    reportFile: string;
    workspace: string;
    policy: AgentPolicy;
    signal: AbortSignal;
    native?: Context;
    selection?: Selection;
    preset?: {
        id: string;
        mount(ctx: Context): Promise<void>;
    };
    keepSession?: boolean;
    sessionId?: string;
    prepare?(): Promise<string>;
    onSession?(id: string): Promise<void>;
    onComplete?(result: AgentReviewResult): Promise<{
        reportId: string;
        json: string;
        html: string;
    }>;
    onProgress?(audit: AgentAudit): Promise<void>;
}
export interface AgentReviewResult {
    audit: AgentAudit;
    reviews: Review[];
    findings: AdditionalFinding[];
}
/** Deterministic review tools hosted by the public native Agent factory and session driver. */
export declare function runAgentReview(options: AgentReviewOptions): Promise<AgentReviewResult>;
export {};
