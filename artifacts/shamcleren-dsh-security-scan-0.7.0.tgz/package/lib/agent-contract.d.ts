/** Shared configuration and audit metadata; safe to import in the browser. */
import { z } from 'zod';
export declare const AgentPolicySchema: z.ZodObject<{
    enabled: z.ZodDefault<z.ZodBoolean>;
    provider: z.ZodDefault<z.ZodString>;
    model: z.ZodDefault<z.ZodString>;
    maxSteps: z.ZodDefault<z.ZodNumber>;
    maxMinutes: z.ZodDefault<z.ZodNumber>;
    maxTokens: z.ZodDefault<z.ZodNumber>;
}, z.core.$strict>;
export type AgentPolicy = z.infer<typeof AgentPolicySchema>;
export declare const ReviewAreaSchema: z.ZodEnum<{
    authentication: "authentication";
    authorization: "authorization";
    "business-logic": "business-logic";
    "data-exposure": "data-exposure";
    "entry-points": "entry-points";
    injection: "injection";
}>;
export declare const AgentEventSchema: z.ZodObject<{
    step: z.ZodNumber;
    kind: z.ZodEnum<{
        finished: "finished";
        listing: "listing";
        planning: "planning";
        reading: "reading";
        rejected: "rejected";
        reviewing: "reviewing";
    }>;
    files: z.ZodDefault<z.ZodArray<z.ZodString>>;
    code: z.ZodOptional<z.ZodString>;
    count: z.ZodDefault<z.ZodNumber>;
}, z.core.$strict>;
export declare const AgentAuditSchema: z.ZodObject<{
    status: z.ZodEnum<{
        completed: "completed";
        incomplete: "incomplete";
    }>;
    reason: z.ZodEnum<{
        cancelled: "cancelled";
        completed: "completed";
        "context-limit": "context-limit";
        "evidence-unavailable": "evidence-unavailable";
        "invalid-response": "invalid-response";
        "model-failed": "model-failed";
        "model-unavailable": "model-unavailable";
        "output-limit": "output-limit";
        "preset-unavailable": "preset-unavailable";
        "step-limit": "step-limit";
        "time-limit": "time-limit";
    }>;
    preset: z.ZodOptional<z.ZodString>;
    provider: z.ZodString;
    model: z.ZodString;
    steps: z.ZodNumber;
    areas: z.ZodArray<z.ZodEnum<{
        authentication: "authentication";
        authorization: "authorization";
        "business-logic": "business-logic";
        "data-exposure": "data-exposure";
        "entry-points": "entry-points";
        injection: "injection";
    }>>;
    files: z.ZodArray<z.ZodString>;
    eligibleCandidates: z.ZodOptional<z.ZodNumber>;
    excludedCandidates: z.ZodOptional<z.ZodNumber>;
    reviewedFindings: z.ZodNumber;
    additionalFindings: z.ZodDefault<z.ZodNumber>;
    inputTokens: z.ZodNumber;
    outputTokens: z.ZodNumber;
    usageAvailable: z.ZodBoolean;
    events: z.ZodArray<z.ZodObject<{
        step: z.ZodNumber;
        kind: z.ZodEnum<{
            finished: "finished";
            listing: "listing";
            planning: "planning";
            reading: "reading";
            rejected: "rejected";
            reviewing: "reviewing";
        }>;
        files: z.ZodDefault<z.ZodArray<z.ZodString>>;
        code: z.ZodOptional<z.ZodString>;
        count: z.ZodDefault<z.ZodNumber>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type AgentAudit = z.infer<typeof AgentAuditSchema>;
