# `@shamcleren/dsh-wecom-aibot`

WeCom AI Bot channel package for DeepSeek Harness.

## Current milestone

The package connects the official WeCom AI Bot WebSocket SDK to the same-process DeepSeek Harness Host API. It accepts text callbacks, creates or resumes a deterministic durable session for each direct or group conversation, suppresses a previously admitted `msgid`, queues the prompt, and projects text deltas plus the final turn result into one WeCom stream.

The bundle row always mounts so the plugin remains visible and configurable. Its `enabled` setting defaults to `false`; the SDK connects only after the setting is enabled and both credential references resolve. The same package exports a dynamic `./client` bundle that contributes its card to the generic Plugins settings section, so `dsh plugin --profile web add <package>` installs the Host channel and its UI together without modifying or rebuilding DeepSeek Harness. Environment variables remain a fallback for headless deployments. The implementation has automated Host/SDK boundary coverage; a live Bot credential smoke remains before a production rollout. See the repository-level [design document](../../docs/plugins/wecom-aibot.md).

## Configuration

| Field | Default | Meaning |
| --- | --- | --- |
| `enabled` | `false` | Whether the SDK connects and accepts messages. |
| `botIdEnv` | `WECOM_BOT_ID` | Credential reference containing the WeCom Bot ID. |
| `secretEnv` | `WECOM_BOT_SECRET` | Credential reference containing the WeCom Bot secret. |
| `allowedUsers` | `[]` | WeCom userids allowed to send messages. An empty list accepts every user visible to the Bot. |
| `adminUsers` | `[]` | WeCom userids allowed to run `/help`, `/status`, `/new`, `/model`, `/effort`, and `/compact`. |
| `workspaceName` | `企业微信机器人` | Harness Workspace grouping every direct and group conversation. |
| `preventIdleSleep` | `false` | On macOS, run a managed idle-sleep assertion while the Bot is active. |
| `agentPreset` | omitted | Harness agent preset used when a new WeCom session is created. |
| `thinkingText` | `正在思考…` | Initial content of the WeCom stream while the Harness turn starts. |
| `turnTimeoutMs` | `300000` | Maximum observation time for one admitted Harness turn. |

The reference fields are names, not credential literals. The plugin resolves the Host credentials service first and then the process environment. Enabling the plugin without both values keeps it disconnected and emits a warning; writing either referenced credential or changing settings reconciles the connection without remounting the plugin.

The UI stores Bot ID and Secret through the Host credentials API, never in the settings document or a browser response. Ordinary settings and credentials remain under the Harness home and survive application restarts.

Conversation and prompt identities are SHA-256-derived from the Bot and WeCom identifiers. Raw userids and chatids do not appear in Harness session ids. Deduplication reads the Host's durable `rpcId` admission receipt, so replaying a callback after restart does not enqueue another turn.

The plugin persists only the hashed conversation key and current opaque Session id under the Harness home. `/new` switches that binding after the new Workspace-owned Session exists; the prior Session remains available in the App. Management commands are an explicit allowlist and never expand when Harness adds another command.

## Known limitations

- Only text callbacks are handled. Images, voice, files, video, mixed messages, cards, and proactive sends are deferred.
- Group delivery follows the WeCom AI Bot callback policy; the plugin does not add another mention parser.
- Approvals and interactive questions still require another connected Harness client or a profile policy that settles them.
- Unloading the plugin stops its listeners, timers, and reply observation. A turn already admitted through the Host API remains Host-owned and may finish without sending another WeCom frame.

## Development

```sh
pnpm install
pnpm test
pnpm typecheck
pnpm build
```
