import type { Logger } from '@deepseek-ai/cordis';
import type { WsFrame, WsFrameHeaders } from '@wecom/aibot-node-sdk';
import type { HostApiProxy } from './host-api.js';
import type { WeComTextFrame } from './inbound.js';
import type { ConversationBindings } from './bindings.js';
export interface WeComReplyClient {
    replyStreamNonBlocking(frame: WsFrameHeaders, streamId: string, content: string, finish?: boolean): Promise<WsFrame | 'skipped'>;
}
export interface RouterConfig {
    allowedUsers: readonly string[];
    adminUsers: readonly string[];
    agentPreset?: string;
    thinkingText: string;
    turnTimeoutMs: number;
}
export interface RouterRuntimeContext {
    bindings: Pick<ConversationBindings, 'current' | 'set'>;
    workspaceId: string;
}
/** Route WeCom text frames through the Host API and project durable turn output back to WeCom. */
export declare class WeComConversationRouter {
    private readonly api;
    private readonly replies;
    private readonly logger;
    private readonly config;
    private readonly runtime;
    private readonly allowedUsers;
    private readonly adminUsers;
    private readonly listeners;
    private readonly queues;
    private readonly tasks;
    private readonly sessionStates;
    private readonly turnAborts;
    private muxAbort;
    private muxTask;
    private muxFailure;
    private stopping;
    constructor(api: HostApiProxy, replies: WeComReplyClient, logger: Logger, config: RouterConfig, runtime: RouterRuntimeContext);
    /** Begin the one Host event stream shared by every WeCom conversation. */
    start(): void;
    /** Accept one SDK callback without allowing its promise to escape EventEmitter. */
    accept(frame: WeComTextFrame): void;
    /** Stop callbacks and the Host stream, then settle every router-owned task. */
    stop(): Promise<void>;
    private consumeMux;
    private publish;
    private subscribe;
    private routeFrame;
    private runTurn;
    private runManagementCommand;
    private status;
    private newSession;
    private model;
    private effort;
    private sessionState;
    private loadSessionState;
    private waitForTurn;
    private update;
    private finish;
}
