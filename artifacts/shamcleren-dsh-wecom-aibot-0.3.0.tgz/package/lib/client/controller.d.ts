/** WeCom settings scope and write-only credential projection for the browser card. */
import type { IApiClient } from '@deepseek-ai/dsh-client-connection/client';
import type { SettingsScope, SnapshotStore } from '@deepseek-ai/dsh-client-runtime/client';
import type { Config } from '../config.js';
import { type FieldState, type FormActions, type FormState } from './form.js';
export interface WeComCardState extends FormState {
    enabled: FieldState;
    botId: FieldState;
    secret: FieldState;
    allowedUsers: FieldState;
    adminUsers: FieldState;
    workspaceName: FieldState;
    preventIdleSleep: FieldState;
    agentPreset: FieldState;
    thinkingText: FieldState;
    turnTimeoutMs: FieldState;
    botIdConfigured: boolean;
    botIdWritable: boolean;
    secretConfigured: boolean;
    secretWritable: boolean;
}
export interface WeComCardFace extends FormActions {
    hooks: {
        weComCard: SnapshotStore<WeComCardState>;
    };
}
/** Synchronizes one WeCom card with settings and credential stores. */
export declare class WeComCardController {
    private readonly scope;
    private readonly api;
    private readonly form;
    private readonly store;
    private botId;
    private secret;
    constructor(scope: SettingsScope<Config>, api: Pick<IApiClient, 'credentials'>);
    refreshCredential(ref: string): void;
    inject(): WeComCardFace;
    private projection;
    private readCredentials;
    private writeCredential;
}
