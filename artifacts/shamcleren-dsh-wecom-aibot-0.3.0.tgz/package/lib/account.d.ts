import type { Logger } from '@deepseek-ai/cordis';
import type { TextMessage, WsFrame } from '@wecom/aibot-node-sdk';
type ConnectionListener = () => void;
type DisconnectionListener = (reason: string) => void;
type ErrorListener = (error: Error) => void;
type TextMessageListener = (frame: WsFrame<TextMessage>) => void;
/** SDK operations used by the connection lifecycle. */
export interface WeComBotClient {
    connect(): unknown;
    disconnect(): void;
    on(event: 'authenticated', listener: ConnectionListener): unknown;
    on(event: 'disconnected', listener: DisconnectionListener): unknown;
    on(event: 'error', listener: ErrorListener): unknown;
    on(event: 'message.text', listener: TextMessageListener): unknown;
    off(event: 'authenticated', listener: ConnectionListener): unknown;
    off(event: 'disconnected', listener: DisconnectionListener): unknown;
    off(event: 'error', listener: ErrorListener): unknown;
    off(event: 'message.text', listener: TextMessageListener): unknown;
}
/** Own one WeCom SDK connection and every listener attached to it. */
export declare class WeComBotAccount {
    private readonly client;
    private readonly logger;
    private readonly onTextMessage;
    private started;
    private readonly authenticated;
    private readonly disconnected;
    private readonly failed;
    private readonly textMessage;
    constructor(client: WeComBotClient, logger: Logger, onTextMessage: TextMessageListener);
    /** Attach diagnostics and begin the SDK-owned connection lifecycle. */
    start(): void;
    /** Disconnect and remove every listener owned by this account. */
    stop(): void;
    private attachListeners;
    private detachListeners;
}
export {};
