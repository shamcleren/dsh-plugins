/** Workspace bootstrap for channel-owned Sessions. */
import type { HostApiProxy } from './host-api.js';
/** Create or reuse the plugin's private directory-backed Workspace. */
export declare function ensureWeComWorkspace(api: HostApiProxy, dshHome: string, title: string): Promise<string>;
