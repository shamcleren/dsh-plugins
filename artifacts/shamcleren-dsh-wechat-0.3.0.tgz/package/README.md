# `@shamcleren/dsh-wechat`

Personal WeChat channel for DeepSeek Harness, backed by Tencent's official iLink Bot protocol.

## Install

Install through **Remote Market** or from this repository's local release tarball. For source changes, build `plugins/wechat` before installing the directory. See the [plugin management guide](../../docs/plugin-management.md) for commands, updates, removal, and the `before-web-app` ordering required after local installation. Installation does not enable the bot or complete account authorization.

## Capabilities

- QR-code login with local owner-only credential persistence.
- Multiple authorized accounts, optionally filtered by `accountIds`.
- Restart-safe long-poll cursors and per-peer reply context tokens.
- Direct text and image prompts; voice transcription, file names, and video notices are retained as text.
- Durable account-and-peer Session routing and callback deduplication. Messages steer an active channel-owned turn; otherwise they queue through the upstream Host API. A rejected steer retries once as queued input.
- Final assistant output accumulated across model steps, Unicode-safe outbound chunking, and typing indicators.
- `/new`, Host slash commands, `/approve`, `/reject`, and `/answer` interaction replies.
- Channel-owned approvals use the upstream approval waterfall and canonical audit id; unrelated sessions delegate to the Host UI. Questions use the Host interaction API. Web and WeChat do not present the same approval concurrently.

## Login

Open the WeChat card under Plugins settings and select **Connect WeChat**. Scan and confirm in WeChat; the plugin saves the account, enables it, and starts receiving messages automatically. The card presents a numeric verification field if WeChat requests one. No user ID, administrator ID, or separate start action is required. **Add account** starts another authorization flow and includes the new account in an existing account selection.

By default, each account accepts messages and administrator commands only from the person who scanned its QR code. The identity comes from iLink's `ilink_user_id` callback field; it is not a WeChat handle. The current integration has no handle-to-ID lookup. Existing nonempty custom permissions remain effective. Manual account selection, permissions, and the pause switch are available under **Advanced settings (optional)**. If authorization returns no owner identity, the account cannot start with default permissions: reconnect, or explicitly configure both permission lists in advanced settings. It never falls back to accepting everyone.

Credentials, poll cursors, and peer context tokens are stored under `<dsh-home>/channels/wechat/accounts.json` with owner-only permissions. The Remote login API exposes only QR state and account ids; tokens never enter browser responses, Cordis composition, or browser settings. Leaving `accountIds` empty runs every locally authorized account.

## Configuration

| Field | Default | Meaning |
| --- | --- | --- |
| `enabled` | `false` | QR confirmation automatically sets this to true; turn off to pause. Installing/updating alone does not enable existing accounts. |
| `accountIds` | `[]` | Local accounts to run; empty selects all. |
| `allowedUsers` | `[]` | Custom allowed iLink peer ids; empty derives the scanning owner of each account. |
| `adminUsers` | `[]` | Custom Host command administrators; empty derives the scanning owner of each account. |
| `workspaceId` | omitted | Existing default Workspace for new conversations. |
| `workspaceName` | `微信机器人` | Managed fallback Workspace title. |
| `agentPreset` | omitted | Agent preset for newly created Sessions. |
| `thinkingText` | `正在思考…` | Progress message emitted before the final answer. |
| `turnTimeoutMs` | `300000` | Maximum durable-turn observation time. |
| `mediaMaxBytes` | `20971520` | Maximum encrypted or decrypted inbound image size. |
| `sendTyping` | `true` | Publish and cancel WeChat typing state around a turn. |
| `preventIdleSleep` | `false` | Prevent idle macOS sleep while connected. |

## Protocol limits

Tencent iLink currently exposes direct-chat semantics to this plugin. Group behavior is not advertised. Harness prompt transport accepts text and image bytes, so voice uses Tencent's transcript when available; files and videos retain descriptive metadata instead of injecting unsupported binary prompt blocks. Assistant replies are text-only because durable assistant messages currently expose text content to external channels.

## Development

```sh
pnpm --filter @shamcleren/dsh-wechat test
pnpm --filter @shamcleren/dsh-wechat typecheck
pnpm --filter @shamcleren/dsh-wechat build
```
