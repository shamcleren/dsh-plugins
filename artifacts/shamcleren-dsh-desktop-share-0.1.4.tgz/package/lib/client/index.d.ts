import type { Context } from '@deepseek-ai/cordis';
import { type LocaleKey } from './locales.js';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        'desktop.share': LocaleKey;
    }
}
export declare const inject: string[];
/** Uses the exported ConversationController attachment API of the pinned runtime. */
export declare function apply(ctx: Context): void;
