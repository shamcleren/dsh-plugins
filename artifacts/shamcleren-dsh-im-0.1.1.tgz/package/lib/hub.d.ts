import { Service, type Context } from '@deepseek-ai/cordis';
import { type IMAdapter, type IMAdapterView, type IMFailure } from './contracts.js';
export type { IMAdapter, IMAdapterState, IMAdapterView, IMCapability, IMFailure } from './contracts.js';
declare module '@deepseek-ai/cordis' {
    interface Context {
        imHub: IMHub;
    }
}
/** Platform registration is public; account transports and their secrets remain adapter-owned. */
export declare class IMHub extends Service {
    private readonly adapters;
    private readonly failures;
    constructor(ctx: Context);
    register(adapter: IMAdapter): () => void;
    report(id: string, kind: IMFailure): void;
    state(): IMAdapterView[];
}
