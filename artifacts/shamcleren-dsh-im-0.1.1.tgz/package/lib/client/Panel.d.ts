import type { ConfigForm } from '@deepseek-ai/dsh-client-ui-settings/client';
import type { WeChatCardController } from '../adapters/wechat/client/controller.js';
import type { WeComCardController } from '../adapters/wecom/client/controller.js';
import type { CardApi } from '../adapters/wecom/client/api.js';
import type { Config as WeChatConfig } from '../adapters/wechat/config.js';
import type { Config as WeComConfig } from '../adapters/wecom/config.js';
import type { LocaleKey as WeChatLocaleKey } from '../adapters/wechat/client/locales.js';
import type { LocaleKey as WeComLocaleKey } from '../adapters/wecom/client/locales.js';
import type { IMAdapterView } from '../hub.js';
import type { LocaleKey } from './locales.js';
export interface PanelProps {
    t(key: LocaleKey): string;
    wechatT(key: WeChatLocaleKey): string;
    wecomT(key: WeComLocaleKey): string;
    wechat: WeChatCardController;
    wecom: WeComCardController;
    wechatForm: ConfigForm<WeChatConfig>;
    wecomForm: ConfigForm<WeComConfig>;
    api: CardApi;
    state(): Promise<IMAdapterView[]>;
}
export declare function Panel(props: PanelProps): import("react").JSX.Element;
