import type { CSSProperties } from 'react';
export declare const styles: Record<'form' | 'section' | 'sectionHeading' | 'hiddenLabel' | 'badge' | 'mutedBadge' | 'field' | 'fieldHead' | 'label' | 'input' | 'select' | 'hint' | 'error' | 'reset' | 'toggle' | 'qr' | 'loginActions' | 'footer' | 'button' | 'save' | 'disabled', CSSProperties>;
