import type { Context } from '@deepseek-ai/cordis';
import { type LocaleKey } from './locales.js';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        'im.workbench': LocaleKey;
    }
}
export declare const name = "@shamcleren/dsh-im";
export declare const inject: string[];
export declare function apply(ctx: Context): Promise<() => Promise<void>>;
