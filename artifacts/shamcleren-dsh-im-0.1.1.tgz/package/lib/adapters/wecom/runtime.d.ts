import type { Logger } from '@deepseek-ai/cordis';
import type { Config, WeComCredentials, WeComSettingsPatch } from './config.js';
import type { WeComBotClient } from './account.js';
import type { HostApiProxy } from './host-api.js';
import type { WeComReplyClient } from './router.js';
import type { ChannelApprovalAnswer, ChannelApprovalRequest, RouterRuntimeContext } from './router.js';
type RuntimeClient = WeComBotClient & WeComReplyClient;
export interface WeComRuntimeOptions {
    api: HostApiProxy;
    logger: Logger;
    resolveCredentials(config: Config): Promise<WeComCredentials | undefined>;
    createClient(credentials: WeComCredentials): RuntimeClient;
    prepareContext(config: Config & {
        id?: string;
    }): Promise<RouterRuntimeContext>;
    /** Persist a channel policy change made from a chat command. */
    writeSettings(section: WeComSettingsPatch, botId?: string): Promise<void>;
}
/** Reconcile independent connections; a missing credential only takes its own Bot offline. */
export declare class WeComRuntimeController {
    private readonly options;
    private readonly bots;
    private readonly credentials;
    private tail;
    private stopped;
    constructor(options: WeComRuntimeOptions);
    state(): {
        status: 'waiting' | 'starting' | 'running' | 'failed';
        accounts: number;
    };
    ready(): Promise<void>;
    update(config: Config): void;
    routesSession(id: string): boolean;
    observesSession(id: string): boolean;
    ownsSession(id: string): boolean;
    requestApproval(request: ChannelApprovalRequest): Promise<ChannelApprovalAnswer | undefined>;
    stop(): Promise<void>;
}
export {};
