/** WeCom settings scope and write-only credential projection for the browser card. */
import type { CardApi as IApiClient, PresetOption } from './api.js';
import type { ConfigForm } from '@deepseek-ai/dsh-client-ui-settings/client';
type SnapshotStore<T> = {
    getSnapshot(): T;
    subscribe(listener: () => void): () => void;
    set(value: T): void;
    update(mutator: (value: T) => void): void;
};
import type { Config } from '../config.js';
import { type FieldState, type FormActions, type FormState } from './form.js';
/**
 * Why one credential write did not leave the reference configured. A `message`
 * carries the deployment's own refusal text; its absence means the deployment
 * accepted the write and still reports the reference unconfigured.
 */
export interface CredentialFailure {
    ref: string;
    message?: string;
}
export interface WeComCardState extends FormState {
    bots: readonly {
        id: string;
        name?: string;
    }[];
    selectedBotId: string;
    rosterWritable: boolean;
    multiBot: boolean;
    model: FieldState;
    name: FieldState;
    botId: FieldState;
    secret: FieldState;
    allowedUsers: FieldState;
    adminUsers: FieldState;
    workspaceId: FieldState;
    workspaceOptions: readonly WorkspaceOption[];
    workspacesLoading: boolean;
    workspacesFailed: boolean;
    presetOptions: readonly PresetOption[];
    presetsLoading: boolean;
    presetsFailed: boolean;
    presetDefaultId?: string;
    preventIdleSleep: FieldState;
    agentPreset: FieldState;
    thinkingText: FieldState;
    turnTimeoutMs: FieldState;
    botIdConfigured: boolean;
    botIdWritable: boolean;
    secretConfigured: boolean;
    secretWritable: boolean;
    credentialFailure?: CredentialFailure;
}
export type { PresetOption } from './api.js';
export interface WorkspaceOption {
    id: string;
    title: string;
    path: string;
}
export interface WeComCardFace extends FormActions {
    selectBot(id: string): void;
    addBot(): void;
    removeBot(): void;
    hooks: {
        weComCard: SnapshotStore<WeComCardState>;
    };
}
/** Synchronizes one WeCom card with settings and credential stores. */
export declare class WeComCardController {
    private readonly rootScope;
    private readonly api;
    private readonly form;
    private readonly scope;
    private selectedBotId;
    private readonly selectionListeners;
    private readonly disposers;
    private readonly store;
    private botId;
    private secret;
    private workspaceOptions;
    private workspacesLoading;
    private workspacesFailed;
    private presetOptions;
    private presetsLoading;
    private presetsFailed;
    private presetDefaultId;
    private credentialFailure;
    constructor(rootScope: ConfigForm<Config>, api: Pick<IApiClient, 'credentials' | 'workspace' | 'presets'>);
    refreshCredential(ref: string): void;
    inject(): WeComCardFace;
    dispose(): void;
    private activeBotId;
    private changeRoster;
    private projection;
    private readWorkspaces;
    private readPresets;
    private readCredentials;
    private writeCredential;
}
/** Project a selected Bot and fence nested writes against roster changes. */
export declare function botScope(root: ConfigForm<Config>, selected: () => string, listeners: Set<() => void>, disposers: (() => void)[]): ConfigForm<Config>;
