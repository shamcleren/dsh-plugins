/** Self-contained WeCom settings card contributed through `plugins.bundle.config`. */
import type { WeComCardFace, WeComCardState } from './controller.js';
import type { LocaleKey } from './locales.js';
export type WeComCardProps = Omit<WeComCardFace, 'hooks'> & {
    embedded?: boolean;
    t(key: LocaleKey): string;
    useWeComCard<T>(select: (state: WeComCardState) => T): T;
};
/** Render the WeCom configuration contribution. */
export declare function WeComCard(props: WeComCardProps): import("react").JSX.Element;
