import type { FileAttachmentRef, ImageAttachmentRef } from '@deepseek-ai/dsh-attachment';
import type { HostSessionEvent } from './host-api.js';
/** WeCom's documented UTF-8 limit for a stream reply body. */
export declare const MAX_STREAM_REPLY_BYTES = 20480;
/** Cut text at a valid code-point boundary within WeCom's byte limit. */
export declare function boundReply(text: string, maxBytes?: number): string;
/** Return every Host prompt identity admitted by one durable event. */
export declare function admittedPromptRpcIds(event: HostSessionEvent): string[];
/** Whether a durable event contains the Host admission receipt for a prompt. */
export declare function eventAdmitsPrompt(event: HostSessionEvent, promptRpcId: string): boolean;
/** Extract text from one assembled assistant message event. */
export declare function assistantText(event: HostSessionEvent): string | undefined;
/** Durable image references carried by one assembled assistant message. */
export declare function assistantImages(event: HostSessionEvent): ImageAttachmentRef[];
/** Extract one text delta and its block index from a raw chunk event. */
export declare function textDelta(event: HostSessionEvent): {
    index: number;
    text: string;
} | undefined;
/** Extract the turn coordinate carried by a turn-scoped event. */
export declare function eventTurn(event: HostSessionEvent): number | undefined;
/** Recover a shell command from the exact durable tool call named by an approval. */
export declare function approvalCommand(event: HostSessionEvent, callId: string): string | undefined;
/** Convert a durable turn ending into a user-facing fallback when no text exists. */
export declare function fallbackReply(reason: unknown): string;
export type OutboundFile = {
    kind: 'attachment';
    attachment: FileAttachmentRef;
} | {
    kind: 'presented';
    path: string;
};
/** Only explicit delivered files are sent; prose links never trigger filesystem reads. */
export declare function deliveredFiles(event: HostSessionEvent): OutboundFile[];
export interface TurnOutcome {
    text: string;
    images: readonly ImageAttachmentRef[];
    files: readonly OutboundFile[];
    reason: unknown;
}
export interface TurnProjectionUpdate {
    partial?: string;
    outcome?: TurnOutcome;
}
/** Fold one admitted prompt's durable events into reply updates. */
export declare class TurnProjection {
    private readonly promptRpcId;
    private admitted;
    private openTurn;
    private ownedTurn;
    private readonly completedText;
    private stepText;
    private readonly images;
    private readonly files;
    constructor(promptRpcId: string);
    push(event: HostSessionEvent): TurnProjectionUpdate;
    private append;
    private stepValue;
    private commitStep;
    private fullText;
}
