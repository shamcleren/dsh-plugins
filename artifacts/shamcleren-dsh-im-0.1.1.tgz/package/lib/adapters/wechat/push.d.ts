import { Service, type Context } from '@deepseek-ai/cordis';
import type { WeChatDelivery, WeChatPushRequest } from './delivery.js';
export type { WeChatPushRequest, WeChatPushReceipt, WeChatRecipient } from './delivery.js';
export { WeChatPushError } from './delivery.js';
declare module '@deepseek-ai/cordis' {
    interface Context {
        wechatPush: WeChatPushService;
    }
}
/** Host-local integration for schedulers; no credentials or public HTTP sender. */
export declare class WeChatPushService extends Service {
    private readonly delivery;
    constructor(ctx: Context, delivery: WeChatDelivery);
    recipients(): import("./delivery.js").WeChatRecipient[];
    notify(request: WeChatPushRequest): Promise<import("./delivery.js").WeChatPushReceipt>;
    status(id: string): import("./delivery.js").WeChatPushReceipt;
    cancel(id: string): Promise<import("./delivery.js").WeChatPushReceipt>;
}
export declare function installPushTools(ctx: Context, delivery: WeChatDelivery): void;
