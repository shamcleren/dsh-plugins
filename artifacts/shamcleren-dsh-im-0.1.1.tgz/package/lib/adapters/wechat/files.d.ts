import type { Context } from '@deepseek-ai/cordis';
export interface OutboundFileBytes {
    name: string;
    bytes: Buffer;
}
/** Bound memory even when a stored reference understates its length. */
export declare function collectFileBytes(source: AsyncIterable<Uint8Array>, maxBytes: number, signal: AbortSignal): Promise<Buffer>;
/** Use the public composed filesystem, including its read policy and file-kind gates. */
export declare function readPresentedFile(ctx: Pick<Context, 'workspaceFiles' | 'sessionController'>, sessionId: string, path: string, fallbackRoot: string, maxBytes: number, signal: AbortSignal): Promise<OutboundFileBytes>;
