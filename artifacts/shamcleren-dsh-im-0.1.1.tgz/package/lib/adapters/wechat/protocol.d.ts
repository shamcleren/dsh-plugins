/** Tencent iLink JSON protocol fields used by the channel. */
export declare const MessageItemType: {
    readonly TEXT: 1;
    readonly IMAGE: 2;
    readonly VOICE: 3;
    readonly FILE: 4;
    readonly VIDEO: 5;
};
/**
 * Media kinds for `getuploadurl`. These are numbered independently of
 * `MessageItemType`, so an image is 1 here and 2 there.
 */
export declare const UploadMediaType: {
    readonly IMAGE: 1;
    readonly VIDEO: 2;
    readonly FILE: 3;
    readonly VOICE: 4;
};
export interface CdnMedia {
    encrypt_query_param?: string;
    aes_key?: string;
    encrypt_type?: number;
    full_url?: string;
}
export interface GetUploadUrlResponse {
    ret?: number;
    errmsg?: string;
    upload_param?: string;
    upload_full_url?: string;
}
export interface MessageItem {
    type?: number;
    msg_id?: string;
    text_item?: {
        text?: string;
    };
    ref_msg?: {
        message_item?: MessageItem;
        title?: string;
        svr_id?: string;
    };
    image_item?: {
        media?: CdnMedia;
        aeskey?: string;
        mid_size?: number;
    };
    voice_item?: {
        media?: CdnMedia;
        text?: string;
    };
    file_item?: {
        media?: CdnMedia;
        file_name?: string;
        len?: string;
    };
    video_item?: {
        media?: CdnMedia;
        video_size?: number;
    };
}
export interface WeixinMessage {
    message_id?: number | string;
    client_id?: string;
    from_user_id?: string;
    create_time_ms?: number;
    item_list?: MessageItem[];
    context_token?: string;
}
export interface GetUpdatesResponse {
    ret?: number;
    errcode?: number;
    errmsg?: string;
    msgs?: WeixinMessage[];
    get_updates_buf?: string;
    longpolling_timeout_ms?: number;
}
export interface QrCodeResponse {
    qrcode: string;
    qrcode_img_content: string;
}
export type QrStatus = 'wait' | 'scaned' | 'confirmed' | 'expired' | 'scaned_but_redirect' | 'need_verifycode' | 'verify_code_blocked' | 'binded_redirect';
export interface QrStatusResponse {
    status: QrStatus;
    bot_token?: string;
    ilink_bot_id?: string;
    baseurl?: string;
    ilink_user_id?: string;
    redirect_host?: string;
}
export interface WeChatAccountCredentials {
    accountId: string;
    token: string;
    baseUrl: string;
    userId?: string;
}
