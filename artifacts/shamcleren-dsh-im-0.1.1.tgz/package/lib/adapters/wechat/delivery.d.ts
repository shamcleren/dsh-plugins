import { z } from 'zod';
import type { ConversationBindings } from './bindings.js';
import type { MessageItem, WeChatAccountCredentials } from './protocol.js';
import type { WeChatAccountStore } from './storage.js';
declare const jobSchema: z.ZodObject<{
    id: z.ZodString;
    recipientId: z.ZodString;
    credential: z.ZodString;
    text: z.ZodString;
    status: z.ZodEnum<{
        failed: "failed";
        uncertain: "uncertain";
        cancelled: "cancelled";
        sent: "sent";
        queued: "queued";
        sending: "sending";
    }>;
    createdAt: z.ZodNumber;
    expiresAt: z.ZodNumber;
    nextAttemptAt: z.ZodNumber;
    sentChunks: z.ZodNumber;
    code: z.ZodOptional<z.ZodString>;
    key: z.ZodOptional<z.ZodString>;
    sessionId: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
type Job = z.infer<typeof jobSchema>;
export interface WeChatPushRequest {
    text: string;
    recipientId?: string;
    accountId?: string;
    /** Reuse the same key for retries of one scheduled occurrence, not all occurrences. */
    idempotencyKey?: string;
}
export interface WeChatRecipient {
    recipientId: string;
    accountId: string;
    userId: string;
    owner: boolean;
    available: boolean;
    lastReceivedAt: number;
}
export interface WeChatPushReceipt {
    id: string;
    recipientId: string;
    status: Job['status'];
    sentChunks: number;
    totalChunks: number;
    code?: string;
    nextAttemptAt: number;
    expiresAt: number;
}
export declare class WeChatPushError extends Error {
    readonly code: string;
    constructor(code: string);
}
export declare function recipientIdFor(accountId: string, userId: string): string;
/** One durable notification queue and a shared, serialized per-peer send budget. */
export declare class WeChatDelivery {
    private readonly filename;
    private document;
    private readonly accounts;
    private readonly bindings;
    private readonly activeAccounts;
    private readonly onError;
    private writes;
    private readonly sends;
    private timer;
    private worker;
    private abort;
    private paused;
    private stopped;
    private faulted;
    private constructor();
    static open(home: string, accounts: WeChatAccountStore, bindings: Pick<ConversationBindings, 'current'>, activeAccounts: () => readonly string[], onError: () => void): Promise<WeChatDelivery>;
    private account;
    private boundRecipient;
    recipients(sessionId?: string): WeChatRecipient[];
    private target;
    notify(input: WeChatPushRequest, sessionId?: string, signal?: AbortSignal): Promise<WeChatPushReceipt>;
    status(jobId: string, sessionId?: string): WeChatPushReceipt;
    cancel(jobId: string, sessionId?: string): Promise<WeChatPushReceipt>;
    /** Duplicate callbacks must not refresh the window or replenish its budget. */
    observe(account: WeChatAccountCredentials, userId: string, messageId: string): Promise<void>;
    /** Replies and notifications share a conservative ten-message interaction budget. */
    send(account: WeChatAccountCredentials, userId: string, item: MessageItem, contextToken: string | undefined, signal: AbortSignal, jobId?: string): Promise<void>;
    resume(): void;
    pause(): Promise<void>;
    stop(): Promise<void>;
    private wake;
    private process;
    private change;
}
export {};
