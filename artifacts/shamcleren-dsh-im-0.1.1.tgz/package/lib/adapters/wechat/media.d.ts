import type { CdnMedia } from './protocol.js';
import { UploadMediaType } from './protocol.js';
/** Download and decrypt one iLink CDN object with AES-128-ECB. */
export declare function downloadMedia(media: CdnMedia, key: string | undefined, cdnBaseUrl: string, maxBytes: number, signal?: AbortSignal): Promise<Buffer>;
/** Both key encodings accepted by iLink decode to the same AES-128 key. */
export interface MediaUploadRequest {
    baseUrl: string;
    token: string;
    userId: string;
    bytes: Buffer;
    cdnBaseUrl: string;
    signal?: AbortSignal;
}
/** Encrypt and upload a bounded media object; never retry an ambiguous send. */
export declare function uploadMedia(request: MediaUploadRequest & {
    mediaType: typeof UploadMediaType[keyof typeof UploadMediaType];
}): Promise<{
    media: CdnMedia;
    ciphertextSize: number;
}>;
/** Preserve the image sender's reference and ciphertext-size contract. */
export declare function uploadImage(request: MediaUploadRequest): Promise<{
    media: CdnMedia;
    midSize: number;
}>;
