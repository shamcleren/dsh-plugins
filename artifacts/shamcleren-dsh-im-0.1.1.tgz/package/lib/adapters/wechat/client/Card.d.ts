import type { WeChatCardFace, WeChatCardState } from './controller.js';
import type { LocaleKey } from './locales.js';
export type WeChatCardProps = Omit<WeChatCardFace, 'hooks'> & {
    t(key: LocaleKey): string;
    useWeChatCard<T>(select: (state: WeChatCardState) => T): T;
};
/** Render personal WeChat settings on this plugin's page in the official plugin manager. */
export declare function WeChatCard(props: WeChatCardProps): import("react").JSX.Element;
