import type { GetUpdatesResponse, GetUploadUrlResponse, MessageItem, QrCodeResponse, QrStatusResponse } from './protocol.js';
/** Structured failures never include response bodies, which can contain credentials. */
export declare class WeChatSendError extends Error {
    readonly kind: 'throttled' | 'context' | 'rejected' | 'uncertain';
    readonly retryAfterMs: number;
    constructor(kind: 'throttled' | 'context' | 'rejected' | 'uncertain', retryAfterMs?: number);
}
/** Start one official WeChat QR authorization. */
export declare function requestQrCode(baseUrl: string, localTokens: readonly string[]): Promise<QrCodeResponse>;
/** Poll an authorization status. */
export declare function requestQrStatus(baseUrl: string, qrCode: string, verifyCode?: string, signal?: AbortSignal): Promise<QrStatusResponse>;
/** Wait for new messages using the persisted opaque cursor. */
export declare function getUpdates(request: {
    baseUrl: string;
    token: string;
    cursor: string;
    timeoutMs: number;
    signal: AbortSignal;
}): Promise<GetUpdatesResponse>;
/**
 * Reserve CDN upload parameters for one outbound media object. The sizes describe
 * the same bytes twice: `rawSize` before AES-128-ECB and `fileSize` after it.
 */
export declare function getUploadUrl(request: {
    baseUrl: string;
    token: string;
    userId: string;
    fileKey: string;
    mediaType: number;
    rawSize: number;
    rawFileMd5: string;
    fileSize: number;
    aesKeyHex: string;
    signal?: AbortSignal;
}): Promise<GetUploadUrlResponse>;
/** Send one completed iLink message. */
export declare function sendMessage(request: {
    baseUrl: string;
    token: string;
    userId: string;
    contextToken?: string;
    item: MessageItem;
    signal?: AbortSignal;
    clientId?: string;
}): Promise<void>;
/** Resolve and publish a typing state for one peer. */
export declare function sendTyping(request: {
    baseUrl: string;
    token: string;
    userId: string;
    contextToken?: string;
    status: 1 | 2;
}): Promise<void>;
/** Notify iLink that one account monitor started or stopped. */
export declare function notifyLifecycle(account: {
    baseUrl: string;
    token: string;
}, state: 'start' | 'stop'): Promise<void>;
/** iLink identifiers exceed IEEE-754's exact integer range on recent WeChat clients. */
export declare function parseProtocolJson(text: string): unknown;
