import { z } from 'zod';
export declare const capabilitySchema: z.ZodEnum<{
    text: "text";
    image: "image";
    file: "file";
    video: "video";
    approval: "approval";
    questions: "questions";
    groups: "groups";
    notifications: "notifications";
}>;
export declare const failureSchema: z.ZodEnum<{
    "message-format": "message-format";
    media: "media";
    host: "host";
    connection: "connection";
}>;
export declare const adapterIdSchema: z.ZodString;
export declare const capabilitiesSchema: z.ZodArray<z.ZodEnum<{
    text: "text";
    image: "image";
    file: "file";
    video: "video";
    approval: "approval";
    questions: "questions";
    groups: "groups";
    notifications: "notifications";
}>>;
export declare const adapterStateSchema: z.ZodObject<{
    enabled: z.ZodBoolean;
    status: z.ZodEnum<{
        disabled: "disabled";
        waiting: "waiting";
        starting: "starting";
        running: "running";
        failed: "failed";
    }>;
    accounts: z.ZodNumber;
}, z.core.$strip>;
export declare const adapterViewsSchema: z.ZodArray<z.ZodObject<{
    enabled: z.ZodBoolean;
    status: z.ZodEnum<{
        disabled: "disabled";
        waiting: "waiting";
        starting: "starting";
        running: "running";
        failed: "failed";
    }>;
    accounts: z.ZodNumber;
    id: z.ZodString;
    capabilities: z.ZodArray<z.ZodEnum<{
        text: "text";
        image: "image";
        file: "file";
        video: "video";
        approval: "approval";
        questions: "questions";
        groups: "groups";
        notifications: "notifications";
    }>>;
    lastFailure: z.ZodOptional<z.ZodObject<{
        kind: z.ZodEnum<{
            "message-format": "message-format";
            media: "media";
            host: "host";
            connection: "connection";
        }>;
        at: z.ZodNumber;
    }, z.core.$strip>>;
}, z.core.$strip>>;
export type IMCapability = z.infer<typeof capabilitySchema>;
export type IMFailure = z.infer<typeof failureSchema>;
export type IMAdapterState = z.infer<typeof adapterStateSchema>;
export type IMAdapterView = z.infer<typeof adapterViewsSchema>[number];
export interface IMAdapter {
    id: string;
    capabilities: readonly IMCapability[];
    state(): IMAdapterState;
}
