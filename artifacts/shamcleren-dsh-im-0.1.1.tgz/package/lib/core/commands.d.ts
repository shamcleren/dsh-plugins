export declare function requiresHostSession(text: string | undefined, administrator: boolean): boolean;
export declare function managementHelp(options?: {
    tasks?: boolean;
    identity?: boolean;
}): string;
/** Never echo a Host exception, message body or credential into an IM response. */
export declare function managementFailure(): string;
export declare function inboundFailure(phase: 'decode' | 'route', media: boolean): string;
