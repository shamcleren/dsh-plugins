import type { HostApiProxy } from './host-api.js';
export declare function channelWorkspaceTitle(platform: '微信' | '企业微信', name: string | undefined, fallback: string): string;
export declare function accountLabel(accountIds: readonly string[]): string;
/** Rename only the owned path and recognizable generated titles. */
export declare function nameManagedWorkspace(api: HostApiProxy, dshHome: string, created: {
    created: boolean;
    workspace: {
        workspaceId: string;
        path: string;
        title: string;
    };
}, path: string, title: string, legacyTitles: readonly string[]): Promise<string>;
