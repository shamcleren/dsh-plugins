import { type HostApiProxy } from './host-api.js';
/** `sessionController.create` may mint a different id; only its returned identity is authoritative. */
export declare function ensureConversationSession(options: {
    api: {
        workspace: Pick<HostApiProxy['workspace'], 'list'>;
        sessions: Pick<HostApiProxy['sessions'], 'history'>;
    };
    key: string;
    requested: string;
    defaultWorkspaceId: string;
    bindings: {
        set(key: string, sessionId: string): Promise<void>;
    };
    create(sessionId: string, workspaceId: string): Promise<string>;
}): Promise<string>;
