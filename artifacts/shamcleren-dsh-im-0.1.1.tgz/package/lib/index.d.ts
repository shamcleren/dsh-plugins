import type { Context } from '@deepseek-ai/cordis';
export { IMHub } from './hub.js';
export type { IMAdapter, IMAdapterState, IMAdapterView, IMCapability } from './hub.js';
export declare const name = "im";
export declare function apply(ctx: Context): void;
