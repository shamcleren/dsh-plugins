window.__ModuleLoader__.load({
	id: "@shamcleren/dsh-plugin-marketplace",
	factory: (require) => {
		var module = { exports: {} };
		var exports = module.exports;
		Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
		let react = require("react");
		let react_jsx_runtime = require("react/jsx-runtime");
		//#region src/client/model.ts
		/** Join catalog and installed entries without depending on their display order. */
		function pluginRows(plugins, installed) {
			const installedByName = new Map(installed.map((entry) => [entry.packageName, entry]));
			return plugins.map((plugin) => {
				const current = installedByName.get(plugin.packageName);
				return {
					plugin,
					...current === void 0 ? {} : { installed: current },
					updateAvailable: plugin.compatible && current !== void 0 && current.version !== plugin.version
				};
			});
		}
		/** Apply query and compatibility/update filters with stable catalog ordering. */
		function visibleRows(rows, query, filter) {
			const normalized = query.trim().toLocaleLowerCase();
			return rows.filter((row) => {
				if (filter === "compatible" && !row.plugin.compatible) return false;
				if (filter === "updates" && !row.updateAvailable) return false;
				return normalized === "" || [
					row.plugin.name,
					row.plugin.packageName,
					row.plugin.description
				].some((value) => value.toLocaleLowerCase().includes(normalized));
			});
		}
		//#endregion
		//#region src/client/native.ts
		/** Request a native Host restart when the native bridge is available. */
		function requestNativeRestart() {
			const handler = window.webkit?.messageHandlers?.dshNative;
			if (handler === void 0) return false;
			handler.postMessage({ action: "restartHost" });
			return true;
		}
		/** Open an OAuth URL through the native bridge when available. */
		function requestNativeOpen(url) {
			const handler = window.webkit?.messageHandlers?.dshNative;
			if (handler === void 0) return false;
			handler.postMessage({
				action: "openExternal",
				url
			});
			return true;
		}
		//#endregion
		//#region \0dsh-marketplace-css:/private/tmp/dsh-upstream-migration.SGmXFX/marketplace/src/client/MarketplacePanel.module.css.mjs
		const css = "._0dih5q_root{color:var(--dsw-alias-label-primary,inherit);gap:16px;display:grid}._0dih5q_root button,._0dih5q_root input,._0dih5q_root select{font:inherit}._0dih5q_root button{border:1px solid var(--dsw-alias-border-l2,#46484d);color:inherit;background:var(--dsw-alias-bg-layer-3,#34363b);cursor:pointer;border-radius:9px;padding:8px 12px}._0dih5q_root button:disabled{opacity:.5;cursor:default}._0dih5q_sourceCard{border:1px solid var(--dsw-alias-border-l2,#46484d);background:linear-gradient(135deg, color-mix(in srgb, var(--dsw-alias-bg-layer-3,#34363b) 86%, #5968ff 14%), var(--dsw-alias-bg-layer-2,#202226));border-radius:14px;justify-content:space-between;align-items:center;gap:16px;padding:16px;display:flex}._0dih5q_eyebrow{color:var(--dsw-alias-label-tertiary,#a5a8b0);letter-spacing:.08em;text-transform:uppercase;margin-bottom:4px;font-size:11px}._0dih5q_muted,._0dih5q_pluginCard p,._0dih5q_meta,._0dih5q_empty{color:var(--dsw-alias-label-tertiary,#a5a8b0)}._0dih5q_actions{flex-wrap:wrap;gap:8px;display:flex}._0dih5q_sourceForm{border:1px solid var(--dsw-alias-border-l2,#46484d);border-radius:14px;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px;padding:16px;display:grid}._0dih5q_sourceForm label{gap:6px;font-size:13px;display:grid}._0dih5q_sourceForm input,._0dih5q_sourceForm select,._0dih5q_toolbar input,._0dih5q_toolbar select{box-sizing:border-box;border:1px solid var(--dsw-alias-border-l2,#46484d);width:100%;color:inherit;background:var(--dsw-alias-bg-layer-2,#202226);border-radius:9px;padding:9px 11px}._0dih5q_stats{grid-template-columns:repeat(3,1fr);gap:8px;display:grid}._0dih5q_stats div{background:var(--dsw-alias-bg-module-platform,#27292e);border-radius:11px;justify-content:space-between;align-items:baseline;padding:12px 14px;display:flex}._0dih5q_stats span{color:var(--dsw-alias-label-tertiary,#a5a8b0);font-size:12px}._0dih5q_stats strong{font-size:20px}._0dih5q_tabs{background:var(--dsw-alias-bg-module-platform,#27292e);border-radius:11px;grid-template-columns:repeat(2,1fr);gap:4px;padding:4px;display:grid}._0dih5q_tabs button{background:0 0;border:0}._0dih5q_tabs button[data-active=true]{background:var(--dsw-alias-bg-layer-3,#3a3d43)}._0dih5q_toolbar{grid-template-columns:minmax(0,1fr) minmax(120px,auto) auto;gap:8px;display:grid}._0dih5q_notice,._0dih5q_error{border-radius:10px;justify-content:space-between;align-items:center;gap:12px;padding:11px 13px;display:flex}._0dih5q_notice{background:color-mix(in srgb, var(--dsh-color-success,#62ca8d) 13%, var(--dsw-alias-bg-module-platform,#27292e))}._0dih5q_error{color:var(--dsh-color-danger,#f08b8b);background:color-mix(in srgb, var(--dsh-color-danger,#f08b8b) 10%, var(--dsw-alias-bg-module-platform,#27292e))}._0dih5q_grid{grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:11px;margin:0;padding:0;list-style:none;display:grid}._0dih5q_pluginCard{border:1px solid var(--dsw-alias-border-l2,#46484d);background:var(--dsw-alias-bg-layer-2,#202226);border-radius:13px;align-content:start;gap:9px;min-height:190px;padding:15px;display:grid}._0dih5q_pluginHeader,._0dih5q_cardFooter,._0dih5q_meta{justify-content:space-between;align-items:center;gap:10px;display:flex}._0dih5q_pluginCard p{min-height:40px;margin:0;line-height:1.45}._0dih5q_pluginCard code,._0dih5q_list code{overflow-wrap:anywhere;color:var(--dsw-alias-label-tertiary,#a5a8b0);font-size:11px;display:block}._0dih5q_badge{color:var(--dsh-color-success,#62ca8d);background:color-mix(in srgb, var(--dsh-color-success,#62ca8d) 13%, transparent);border-radius:999px;padding:3px 7px;font-size:11px}._0dih5q_incompatible{color:var(--dsh-color-danger,#f08b8b);font-size:12px}._0dih5q_list{gap:8px;margin:0;padding:0;list-style:none;display:grid}._0dih5q_list li{border:1px solid var(--dsw-alias-border-l2,#46484d);border-radius:11px;justify-content:space-between;align-items:center;gap:12px;padding:13px 14px;display:flex}._0dih5q_danger{color:var(--dsh-color-danger,#f08b8b)!important;background:0 0!important}._0dih5q_empty{text-align:center;border:1px dashed var(--dsw-alias-border-l2,#46484d);border-radius:12px;margin:0;padding:28px}@media (max-width:720px){._0dih5q_sourceCard,._0dih5q_list li{flex-direction:column;align-items:stretch}._0dih5q_sourceForm,._0dih5q_toolbar{grid-template-columns:1fr}}";
		const tagId = "@shamcleren/dsh-plugin-marketplace/MarketplacePanel.module.css";
		if (typeof document !== "undefined" && document.querySelector("style[data-plugin-css=" + JSON.stringify(tagId) + "]") === null) {
			const tag = document.createElement("style");
			tag.dataset.plugin = "@shamcleren/dsh-plugin-marketplace";
			tag.dataset.pluginCss = tagId;
			tag.textContent = css;
			document.head.appendChild(tag);
		}
		var MarketplacePanel_module_css_default = {
			"list": "_0dih5q_list",
			"danger": "_0dih5q_danger",
			"sourceCard": "_0dih5q_sourceCard",
			"error": "_0dih5q_error",
			"pluginCard": "_0dih5q_pluginCard",
			"empty": "_0dih5q_empty",
			"meta": "_0dih5q_meta",
			"sourceForm": "_0dih5q_sourceForm",
			"muted": "_0dih5q_muted",
			"grid": "_0dih5q_grid",
			"pluginHeader": "_0dih5q_pluginHeader",
			"actions": "_0dih5q_actions",
			"incompatible": "_0dih5q_incompatible",
			"eyebrow": "_0dih5q_eyebrow",
			"cardFooter": "_0dih5q_cardFooter",
			"tabs": "_0dih5q_tabs",
			"toolbar": "_0dih5q_toolbar",
			"stats": "_0dih5q_stats",
			"notice": "_0dih5q_notice",
			"root": "_0dih5q_root",
			"badge": "_0dih5q_badge"
		};
		//#endregion
		//#region src/client/MarketplacePanel.tsx
		function errorMessage(error) {
			return error instanceof Error ? error.message : String(error);
		}
		/** Trusted catalog and installed-plugin management UI. */
		function MarketplacePanel({ remote, t }) {
			const [view, setView] = (0, react.useState)("catalog");
			const [filter, setFilter] = (0, react.useState)("all");
			const [query, setQuery] = (0, react.useState)("");
			const [state, setState] = (0, react.useState)();
			const [catalog, setCatalog] = (0, react.useState)();
			const [repositories, setRepositories] = (0, react.useState)([]);
			const [editing, setEditing] = (0, react.useState)(false);
			const [baseUrl, setBaseUrl] = (0, react.useState)("https://git.woa.com/");
			const [repository, setRepository] = (0, react.useState)("shamcleren/dsh-plugin");
			const [ref, setRef] = (0, react.useState)("main");
			const [token, setToken] = (0, react.useState)("");
			const [oauthClientId, setOauthClientId] = (0, react.useState)("78a69ee90433425fbd1cad0fe687c2e6");
			const [busy, setBusy] = (0, react.useState)();
			const [error, setError] = (0, react.useState)();
			const [notice, setNotice] = (0, react.useState)();
			const [restartPending, setRestartPending] = (0, react.useState)(false);
			const load = (0, react.useCallback)(async (refreshCatalog) => {
				setError(void 0);
				const nextState = await remote.state();
				setState(nextState);
				setBaseUrl(nextState.baseUrl);
				setRepository(nextState.repository);
				setRef(nextState.ref);
				setOauthClientId(nextState.oauthClientId ?? "");
				if (nextState.tokenConfigured) setCatalog(await (refreshCatalog ? remote.refreshCatalog() : remote.catalog()));
				else setCatalog(void 0);
			}, [remote]);
			(0, react.useEffect)(() => {
				load(false).catch((failure) => {
					setError(errorMessage(failure));
				});
			}, [load]);
			const rows = (0, react.useMemo)(() => pluginRows(catalog?.plugins ?? [], state?.installed ?? []), [catalog, state]);
			const updates = (0, react.useMemo)(() => rows.filter((row) => row.updateAvailable), [rows]);
			const visible = (0, react.useMemo)(() => visibleRows(rows, query, filter), [
				filter,
				query,
				rows
			]);
			const installedRows = (0, react.useMemo)(() => rows.filter((row) => row.installed !== void 0), [rows]);
			const unknownInstalled = (0, react.useMemo)(() => (state?.installed ?? []).filter((entry) => !rows.some((row) => row.installed?.packageName === entry.packageName)), [rows, state]);
			const mutate = async (key, operation) => {
				setBusy(key);
				setError(void 0);
				try {
					await operation();
					setRestartPending(true);
					setNotice(t("restartPending"));
					await load(false);
				} catch (failure) {
					setError(errorMessage(failure));
				} finally {
					setBusy(void 0);
				}
			};
			const refreshRemoteCatalog = async () => {
				setBusy("refresh");
				setError(void 0);
				try {
					await load(true);
				} catch (failure) {
					setError(errorMessage(failure));
				} finally {
					setBusy(void 0);
				}
			};
			const updateAll = async () => {
				setBusy("update-all");
				setError(void 0);
				let completed = 0;
				try {
					for (const row of updates) {
						await remote.add(row.plugin.packageName);
						completed += 1;
					}
				} catch (failure) {
					setError(`${t("partialUpdate")} ${errorMessage(failure)}`);
				} finally {
					if (completed > 0) {
						setRestartPending(true);
						setNotice(t("restartPending"));
						await load(false).catch((failure) => {
							setError(errorMessage(failure));
						});
					}
					setBusy(void 0);
				}
			};
			const openSettings = async () => {
				const opening = !editing;
				setEditing(opening);
				if (opening && state?.authMode === "oauth" && repositories.length === 0) try {
					setRepositories(await remote.repositories());
				} catch (failure) {
					setError(errorMessage(failure));
				}
			};
			const saveSource = async () => {
				setBusy("source");
				setError(void 0);
				try {
					await remote.configure({
						baseUrl,
						repository,
						ref,
						...token.trim() === "" ? {} : { token }
					});
					setToken("");
					await load(true);
					setEditing(false);
				} catch (failure) {
					setError(errorMessage(failure));
				} finally {
					setBusy(void 0);
				}
			};
			const startOAuth = async () => {
				setBusy("oauth");
				setError(void 0);
				try {
					const flow = await remote.beginOAuth({
						baseUrl,
						clientId: oauthClientId
					});
					if (!requestNativeOpen(flow.authorizationUrl)) window.open(flow.authorizationUrl, "_blank", "noopener,noreferrer");
					for (let attempt = 0; attempt < 800; attempt += 1) {
						await new Promise((resolve) => window.setTimeout(resolve, 750));
						const status = await remote.oauthStatus(flow.flowId);
						if (status.status === "pending") continue;
						if (status.status === "failed") throw new Error(status.message);
						const available = await remote.repositories();
						setRepositories(available);
						const selected = available.find((entry) => entry.path === repository) ?? available[0];
						if (selected !== void 0) {
							setRepository(selected.path);
							if (selected.defaultBranch !== void 0) setRef(selected.defaultBranch);
						}
						setNotice(t("oauthConnected"));
						return;
					}
					throw new Error(t("oauthExpired"));
				} catch (failure) {
					setError(errorMessage(failure));
				} finally {
					setBusy(void 0);
				}
			};
			const restart = () => {
				if (requestNativeRestart()) setNotice(t("restartSent"));
			};
			return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("section", {
				className: MarketplacePanel_module_css_default.root,
				"aria-busy": busy !== void 0,
				children: [
					/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("header", {
						className: MarketplacePanel_module_css_default.sourceCard,
						children: [/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
								className: MarketplacePanel_module_css_default.eyebrow,
								children: t("source")
							}),
							/* @__PURE__ */ (0, react_jsx_runtime.jsx)("strong", { children: state?.repository ?? repository }),
							/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
								className: MarketplacePanel_module_css_default.muted,
								children: [
									state?.tokenConfigured === true ? t("connected") : t("disconnected"),
									" · ",
									t("sourceSummary")
								]
							})
						] }), /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
							className: MarketplacePanel_module_css_default.actions,
							children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => {
									openSettings();
								},
								children: t("configure")
							}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
								type: "button",
								disabled: busy !== void 0 || state?.tokenConfigured !== true,
								onClick: () => {
									refreshRemoteCatalog();
								},
								children: busy === "refresh" ? t("working") : t("refresh")
							})]
						})]
					}),
					editing || state?.tokenConfigured !== true ? /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
						className: MarketplacePanel_module_css_default.sourceForm,
						children: [
							/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("label", { children: [t("baseUrl"), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("input", {
								value: baseUrl,
								onChange: (event) => {
									setBaseUrl(event.currentTarget.value);
								}
							})] }),
							/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("label", { children: [t("oauthClientId"), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("input", {
								value: oauthClientId,
								onChange: (event) => {
									setOauthClientId(event.currentTarget.value);
								}
							})] }),
							/* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
								type: "button",
								disabled: busy !== void 0 || oauthClientId.trim() === "",
								onClick: () => {
									startOAuth();
								},
								children: t("oauthLogin")
							}),
							/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("label", { children: [t("repository"), repositories.length === 0 ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("input", {
								value: repository,
								onChange: (event) => {
									setRepository(event.currentTarget.value);
								}
							}) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)("select", {
								value: repository,
								onChange: (event) => {
									const selected = repositories.find((entry) => entry.path === event.currentTarget.value);
									setRepository(event.currentTarget.value);
									if (selected?.defaultBranch !== void 0) setRef(selected.defaultBranch);
								},
								children: repositories.map((entry) => /* @__PURE__ */ (0, react_jsx_runtime.jsx)("option", {
									value: entry.path,
									children: entry.path
								}, entry.id))
							})] }),
							/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("label", { children: [t("ref"), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("input", {
								value: ref,
								onChange: (event) => {
									setRef(event.currentTarget.value);
								}
							})] }),
							/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("label", { children: [t("token"), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("input", {
								type: "password",
								value: token,
								placeholder: t("tokenHint"),
								onChange: (event) => {
									setToken(event.currentTarget.value);
								}
							})] }),
							/* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
								type: "button",
								disabled: busy !== void 0,
								onClick: () => {
									saveSource();
								},
								children: state?.authMode === "oauth" ? t("save") : t("connectToken")
							})
						]
					}) : null,
					/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
						className: MarketplacePanel_module_css_default.stats,
						"aria-label": t("tab"),
						children: [
							/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", { children: t("catalogCount") }), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("strong", { children: rows.length })] }),
							/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", { children: t("installedCount") }), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("strong", { children: (state?.installed ?? []).length })] }),
							/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", { children: t("updateCount") }), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("strong", { children: updates.length })] })
						]
					}),
					/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
						className: MarketplacePanel_module_css_default.tabs,
						role: "tablist",
						children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
							type: "button",
							role: "tab",
							"aria-selected": view === "catalog",
							"data-active": view === "catalog" || void 0,
							onClick: () => {
								setView("catalog");
							},
							children: t("available")
						}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
							type: "button",
							role: "tab",
							"aria-selected": view === "installed",
							"data-active": view === "installed" || void 0,
							onClick: () => {
								setView("installed");
							},
							children: t("installed")
						})]
					}),
					error === void 0 ? null : /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
						className: MarketplacePanel_module_css_default.error,
						role: "alert",
						children: [/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", { children: [
							/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("strong", { children: [t("error"), ":"] }),
							" ",
							error
						] }), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => {
								load(false).catch((failure) => {
									setError(errorMessage(failure));
								});
							},
							children: t("retry")
						})]
					}),
					notice === void 0 ? null : /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
						className: MarketplacePanel_module_css_default.notice,
						children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", { children: notice }), restartPending && state?.nativeRestartAvailable === true ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: restart,
							children: t("restartNow")
						}) : null]
					}),
					view === "catalog" ? /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
						className: MarketplacePanel_module_css_default.toolbar,
						children: [
							/* @__PURE__ */ (0, react_jsx_runtime.jsx)("input", {
								type: "search",
								value: query,
								placeholder: t("search"),
								onChange: (event) => {
									setQuery(event.currentTarget.value);
								}
							}),
							/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("select", {
								value: filter,
								onChange: (event) => {
									setFilter(event.currentTarget.value);
								},
								"aria-label": t("compatible"),
								children: [
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("option", {
										value: "all",
										children: t("all")
									}),
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("option", {
										value: "compatible",
										children: t("compatible")
									}),
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("option", {
										value: "updates",
										children: t("updates")
									})
								]
							}),
							/* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
								type: "button",
								disabled: updates.length === 0 || busy !== void 0,
								onClick: () => {
									updateAll();
								},
								children: busy === "update-all" ? t("working") : `${t("updateAll")} (${updates.length})`
							})
						]
					}), visible.length === 0 ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
						className: MarketplacePanel_module_css_default.empty,
						children: t("empty")
					}) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)("ul", {
						className: MarketplacePanel_module_css_default.grid,
						children: visible.map((row) => /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("li", {
							className: MarketplacePanel_module_css_default.pluginCard,
							children: [
								/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
									className: MarketplacePanel_module_css_default.pluginHeader,
									children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("strong", { children: row.plugin.name }), row.installed === void 0 ? null : /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
										className: MarketplacePanel_module_css_default.badge,
										children: t("installedTag")
									})]
								}),
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", { children: row.plugin.description }),
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)("code", { children: row.plugin.packageName }),
								/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
									className: MarketplacePanel_module_css_default.meta,
									children: [/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", { children: ["v", row.plugin.version] }), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", { children: row.plugin.dshVersion })]
								}),
								/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
									className: MarketplacePanel_module_css_default.cardFooter,
									children: [row.plugin.compatible ? null : /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
										className: MarketplacePanel_module_css_default.incompatible,
										children: t("incompatible")
									}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
										type: "button",
										disabled: !row.plugin.compatible || row.installed?.version === row.plugin.version || busy !== void 0,
										onClick: () => {
											mutate(row.plugin.packageName, () => remote.add(row.plugin.packageName));
										},
										children: busy === row.plugin.packageName ? t("working") : row.installed === void 0 ? t("install") : t("update")
									})]
								})
							]
						}, row.plugin.packageName))
					})] }) : installedRows.length === 0 && unknownInstalled.length === 0 ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
						className: MarketplacePanel_module_css_default.empty,
						children: t("emptyInstalled")
					}) : /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("ul", {
						className: MarketplacePanel_module_css_default.list,
						children: [installedRows.map((row) => /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("strong", { children: row.plugin.name }), /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("code", { children: [
							row.plugin.packageName,
							" · ",
							row.installed?.version ?? row.installed?.specifier
						] })] }), /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
							className: MarketplacePanel_module_css_default.actions,
							children: [row.updateAvailable ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
								type: "button",
								disabled: busy !== void 0,
								onClick: () => {
									mutate(row.plugin.packageName, () => remote.add(row.plugin.packageName));
								},
								children: t("update")
							}) : null, /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
								className: MarketplacePanel_module_css_default.danger,
								type: "button",
								disabled: busy !== void 0,
								onClick: () => {
									if (window.confirm(t("confirmRemove"))) mutate(row.plugin.packageName, () => remote.deletePackage(row.plugin.packageName));
								},
								children: busy === row.plugin.packageName ? t("removing") : t("remove")
							})]
						})] }, row.plugin.packageName)), unknownInstalled.map((entry) => /* @__PURE__ */ (0, react_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("strong", { children: entry.packageName }), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("code", { children: entry.version ?? entry.specifier })] }) }, entry.packageName))]
					})
				]
			});
		}
		//#endregion
		//#region src/client/locales.ts
		const zh = {
			tab: "插件市场",
			source: "可信来源",
			connected: "已连接",
			disconnected: "需要连接",
			configure: "来源设置",
			refresh: "刷新目录",
			installed: "已安装",
			available: "目录插件",
			compatible: "兼容",
			updates: "可更新",
			search: "搜索名称、包名或描述",
			all: "全部",
			install: "安装",
			update: "更新",
			updateAll: "更新全部",
			remove: "卸载",
			removing: "正在卸载…",
			working: "处理中…",
			installedTag: "已安装",
			incompatible: "当前 DSH 版本不兼容",
			empty: "没有符合条件的插件。",
			emptyInstalled: "当前 profile 没有安装目录中的插件。",
			restartPending: "变更已经写入 profile；完成本轮操作后统一重启即可生效。",
			restartNow: "立即重启",
			restartSent: "已请求原生 Host 重启。",
			error: "操作失败",
			retry: "重试",
			sourceSummary: "单一可信仓库 · 摘要校验 · 安装脚本禁用",
			baseUrl: "工蜂地址",
			oauthClientId: "OAuth Application ID",
			repository: "仓库",
			ref: "分支或 Tag",
			token: "Private Token",
			tokenHint: "留空以保留已配置 Token",
			oauthLogin: "使用 OAuth 登录",
			oauthConnected: "OAuth 授权成功，请选择仓库。",
			oauthExpired: "OAuth 授权等待超时，请重试。",
			connectToken: "使用 Token 连接",
			save: "保存来源",
			confirmRemove: "确认从当前 Web profile 卸载该插件？",
			partialUpdate: "部分插件已更新；请检查失败信息后重试。",
			catalogCount: "目录总数",
			updateCount: "可更新",
			installedCount: "已安装"
		};
		const en = {
			tab: "Plugin marketplace",
			source: "Trusted source",
			connected: "Connected",
			disconnected: "Connection required",
			configure: "Source settings",
			refresh: "Refresh catalog",
			installed: "Installed",
			available: "Catalog",
			compatible: "Compatible",
			updates: "Updates",
			search: "Search name, package, or description",
			all: "All",
			install: "Install",
			update: "Update",
			updateAll: "Update all",
			remove: "Uninstall",
			removing: "Uninstalling…",
			working: "Working…",
			installedTag: "Installed",
			incompatible: "Incompatible with this DSH version",
			empty: "No plugins match the current filters.",
			emptyInstalled: "The current profile has no catalog plugins installed.",
			restartPending: "Changes are saved to the profile; finish this batch and restart once to apply them.",
			restartNow: "Restart now",
			restartSent: "Native Host restart requested.",
			error: "Operation failed",
			retry: "Retry",
			sourceSummary: "Single trusted repository · digest verification · install scripts disabled",
			baseUrl: "Gongfeng URL",
			oauthClientId: "OAuth application ID",
			repository: "Repository",
			ref: "Branch or tag",
			token: "Private token",
			tokenHint: "Leave blank to keep the configured token",
			oauthLogin: "Sign in with OAuth",
			oauthConnected: "OAuth authorized; select a repository.",
			oauthExpired: "OAuth authorization timed out; try again.",
			connectToken: "Connect with token",
			save: "Save source",
			confirmRemove: "Uninstall this plugin from the current Web profile?",
			partialUpdate: "Some plugins were updated; review the failure and retry.",
			catalogCount: "Catalog",
			updateCount: "Updates",
			installedCount: "Installed"
		};
		//#endregion
		//#region src/client/index.ts
		/** External Marketplace browser contribution. */
		const namespace = "settings.marketplace.external";
		const name = "@shamcleren/dsh-plugin-marketplace";
		const inject = [
			"slots",
			"locale",
			"connection"
		];
		function unwrap(response) {
			return response.then((result) => {
				if (result.ok) return result.value;
				throw new Error(`${result.error.code}: ${result.error.message}`);
			});
		}
		/** Register one replacement Marketplace tab backed by the trusted Host service. */
		function apply(ctx) {
			ctx.effect(() => ctx.locale.register(namespace, {
				zh,
				en
			}), "external-marketplace: dictionaries");
			const t = ctx.locale.bind(namespace);
			const call = (endpoint, payload = {}) => unwrap(ctx.connection.rpc.call("/trusted-marketplace", endpoint, payload));
			const remote = {
				state: () => call("state"),
				catalog: () => call("catalog"),
				refreshCatalog: () => call("refreshCatalog"),
				configure: (request) => call("configure", request),
				add: (packageName) => call("add", { packageName }),
				deletePackage: (packageName) => call("deletePackage", { packageName }),
				beginOAuth: (request) => call("beginOAuth", request),
				oauthStatus: (flowId) => call("oauthStatus", { flowId }),
				repositories: () => call("repositories")
			};
			ctx.slots.inject("settings.plugins.tab", () => ctx.slots.register({
				name: "settings.plugins.tab",
				id: "marketplace",
				order: 10,
				label: () => t("tab"),
				locale: namespace
			}, () => (0, react.createElement)(MarketplacePanel, {
				remote,
				t
			})));
		}
		//#endregion
		exports.apply = apply;
		exports.inject = inject;
		exports.name = name;
		return module.exports;
	}
});

//# sourceMappingURL=client.js.map