import type { Logger } from '@deepseek-ai/cordis';
import type { ApprovalOutcome } from '@deepseek-ai/dsh-user-approval';
import type { WsFrame, WsFrameHeaders } from '@wecom/aibot-node-sdk';
import type { HostApiProxy, HostWorkspace } from './host-api.js';
import type { WeComTextFrame } from './inbound.js';
import type { ConversationBindings } from './bindings.js';
export interface WeComReplyClient {
    replyStream(frame: WsFrameHeaders, streamId: string, content: string, finish?: boolean): Promise<WsFrame>;
    replyStreamNonBlocking(frame: WsFrameHeaders, streamId: string, content: string, finish?: boolean): Promise<WsFrame | 'skipped'>;
}
export interface RouterConfig {
    allowedUsers: readonly string[];
    adminUsers: readonly string[];
    agentPreset?: string;
    thinkingText: string;
    turnTimeoutMs: number;
}
export interface RouterRuntimeContext {
    bindings: Pick<ConversationBindings, 'current' | 'set'>;
    defaultWorkspace: HostWorkspace;
}
export interface ChannelApprovalRequest {
    id: string;
    sessionId: string;
    toolName: string;
    reason?: string;
    signal?: AbortSignal;
    resolved: Promise<{
        outcome: ApprovalOutcome;
    }>;
}
export interface ChannelApprovalAnswer {
    outcome: 'allowed-once' | 'rejected';
    actorRef: string;
}
/** Route WeCom text frames through the Host API and project durable turn output back to WeCom. */
export declare class WeComConversationRouter {
    private readonly api;
    private readonly replies;
    private readonly logger;
    private readonly config;
    private readonly runtime;
    private readonly allowedUsers;
    private readonly adminUsers;
    private readonly listeners;
    private readonly admissions;
    private readonly tasks;
    private readonly sessionStates;
    private readonly activeTurns;
    private readonly pendingApprovals;
    private readonly turnAborts;
    private muxAbort;
    private muxTask;
    private muxFailure;
    private stopping;
    constructor(api: HostApiProxy, replies: WeComReplyClient, logger: Logger, config: RouterConfig, runtime: RouterRuntimeContext);
    /** Begin the one Host event stream shared by every WeCom conversation. */
    start(): void;
    /** Accept one SDK callback without allowing its promise to escape EventEmitter. */
    accept(frame: WeComTextFrame): void;
    private track;
    /** Stop callbacks and the Host stream, then settle every router-owned task. */
    stop(): Promise<void>;
    /** Whether this channel owns the exact live session turn. */
    ownsSession(sessionId: string): boolean;
    /** Offer one DSH approval only when its agent turn is currently owned by this channel. */
    requestApproval(request: ChannelApprovalRequest): Promise<ChannelApprovalAnswer | undefined>;
    private consumeMux;
    private publish;
    private subscribe;
    private routeFrame;
    private admitFrame;
    private completeTurn;
    private handleApprovalCommand;
    private settleApproval;
    private withdrawApproval;
    private removePendingApproval;
    private actorRef;
    private withNotice;
    private ensureSession;
    private createSession;
    private runManagementCommand;
    private status;
    private newSession;
    private workspace;
    private selectWorkspace;
    private workspaceIdForSession;
    private listWorkspaces;
    private model;
    private effort;
    private sessionState;
    private loadSessionState;
    private waitForTurn;
    private update;
    private reliableUpdate;
    private finish;
}
