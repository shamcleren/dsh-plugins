/** Durable WeCom conversation-to-Session bindings without raw chat identifiers. */
/** Owner-only JSON persistence for the active Session of each WeCom conversation. */
export declare class ConversationBindings {
    private readonly filename;
    private readonly bindings;
    private writeTail;
    private constructor();
    static open(filename: string): Promise<ConversationBindings>;
    current(key: string, fallback: string): string;
    set(key: string, sessionId: string): Promise<void>;
    drain(): Promise<void>;
    private enqueueWrite;
}
