import type { Context } from '@deepseek-ai/cordis';
import type { Config, WeComCredentials } from './config.js';
/** Resolve the current credential-service or environment values for one Bot. */
export declare function resolveCredentials(ctx: Context, config: Config): Promise<WeComCredentials | undefined>;
/** Subscribe to credential changes without importing a concrete provider package. */
export declare function onCredentialsUpdated(ctx: Context, listener: (ref: string) => void): () => void;
