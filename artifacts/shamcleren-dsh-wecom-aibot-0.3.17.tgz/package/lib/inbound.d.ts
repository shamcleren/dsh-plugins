import type { TextMessage, WsFrame } from '@wecom/aibot-node-sdk';
export type WeComTextFrame = WsFrame<TextMessage>;
export interface WeComInboundText {
    messageId: string;
    userId: string;
    text: string;
    chatType: 'single' | 'group';
    conversationId: string;
    botId: string;
}
/** Routing fields recovered from a WeCom template-card callback. */
export interface WeComTemplateCardClick {
    taskId: string;
    eventKey: string;
    userId: string;
}
/** Validate the SDK frame fields used for routing one text message. */
export declare function normalizeTextFrame(frame: WeComTextFrame): WeComInboundText;
/** Read the nested button payload used by WeCom template-card callbacks. */
export declare function normalizeTemplateCardClick(frame: WsFrame<unknown>): WeComTemplateCardClick | undefined;
/** Stable non-PII key for the plugin's durable active-Session binding. */
export declare function conversationKeyFor(message: WeComInboundText): string;
/** Derive a stable, non-PII Harness session id for one WeCom conversation. */
export declare function sessionIdFor(message: WeComInboundText): string;
/** Derive the durable Host prompt identity used for restart-safe deduplication. */
export declare function promptRpcIdFor(message: WeComInboundText): string;
