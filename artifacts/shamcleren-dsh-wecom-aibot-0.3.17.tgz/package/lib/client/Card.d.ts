/** Self-contained WeCom settings card contributed through `settings.plugin.item`. */
import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { WeComCardFace } from './controller.js';
export type WeComCardProps = PropsRuntime<'settings.plugin.item'> & PropsLocale<'settings.wecom'> & InjectFace<WeComCardFace>;
/** Render the WeCom configuration contribution. */
export declare function WeComCard(props: WeComCardProps): import("react").JSX.Element;
