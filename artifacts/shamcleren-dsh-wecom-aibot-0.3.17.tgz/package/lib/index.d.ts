import type { Context } from '@deepseek-ai/cordis';
import { Config } from './config.js';
export { WeComBotAccount } from './account.js';
export type { WeComBotClient } from './account.js';
export { Config, DEFAULT_BOT_ID_ENV, DEFAULT_SECRET_ENV, DEFAULT_THINKING_TEXT, DEFAULT_TURN_TIMEOUT_MS, DEFAULT_WORKSPACE_NAME, } from './config.js';
export type { Config as WeComAiBotConfig, WeComCredentials, } from './config.js';
/** Stable Cordis plugin name. */
export declare const name = "wecom-aibot";
/** Host gateway required for durable session and turn orchestration. */
export declare const inject: string[];
/** User-settings namespace that keeps this installed plugin configurable while disconnected. */
export declare const WECOM_AIBOT_SETTINGS_NAMESPACE: import("@deepseek-ai/dsh-settings").SettingsNamespace;
/** Connect one configured WeCom Bot for the lifetime of this plugin fiber. */
export declare function apply(ctx: Context, config: Config): void;
