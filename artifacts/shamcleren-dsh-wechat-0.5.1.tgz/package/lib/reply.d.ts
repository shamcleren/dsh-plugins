import type { HostSessionEvent } from './host-api.js';
/** Return every Host prompt identity admitted by one durable event. */
export declare function admittedPromptRpcIds(event: HostSessionEvent): string[];
/** Whether a durable event contains the Host admission receipt for a prompt. */
export declare function eventAdmitsPrompt(event: HostSessionEvent, promptRpcId: string): boolean;
/** Extract text from one assembled assistant message event. */
export declare function assistantText(event: HostSessionEvent): string | undefined;
/** Extract one text delta and its block index from a raw chunk event. */
export declare function textDelta(event: HostSessionEvent): {
    index: number;
    text: string;
} | undefined;
/** Extract the turn coordinate carried by a turn-scoped event. */
export declare function eventTurn(event: HostSessionEvent): number | undefined;
/** Convert a durable turn ending into a user-facing fallback when no text exists. */
export declare function fallbackReply(reason: unknown): string;
export interface TurnProjectionUpdate {
    partial?: string;
    outcome?: {
        text: string;
        imageCount: number;
        reason: unknown;
    };
}
/** Fold one admitted prompt's durable events into reply updates. */
export declare class TurnProjection {
    private readonly promptRpcId;
    private admitted;
    private openTurn;
    private ownedTurn;
    private readonly completedText;
    private stepText;
    private imageCount;
    constructor(promptRpcId: string);
    push(event: HostSessionEvent): TurnProjectionUpdate;
    private append;
    private stepValue;
    private commitStep;
    private fullText;
}
