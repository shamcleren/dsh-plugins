type SnapshotStore<T> = {
    getSnapshot(): T;
    subscribe(listener: () => void): () => void;
    set(value: T): void;
    update(mutator: (value: T) => void): void;
};
import type { SettingsScope } from '@deepseek-ai/dsh-client-ui-settings/client';
import type { RemoteResult, TypertRemoteNamespaceMap } from '@deepseek-ai/dsh-typert-protocol';
import type { Config } from '../config.js';
import type { WeChatLoginView } from '../login.js';
type LoginRemote = TypertRemoteNamespaceMap['wechatLogin'];
export interface PresetOption {
    id: string;
    name?: string;
    broken?: string;
}
export interface PresetRosterApi {
    list(): Promise<{
        result: RemoteResult<{
            items: readonly PresetOption[];
            defaultId?: string;
        }>;
    }>;
}
export interface WeChatCardState {
    login: WeChatLoginView;
    qrDataUrl?: string;
    qrRenderError?: string;
    loginBusy: boolean;
    verificationCode: string;
    writable: boolean;
    dirty: boolean;
    saving: boolean;
    failed: boolean;
    failureMessage?: string;
    presetText: string;
    presetOverridden: boolean;
    presetOptions: readonly PresetOption[];
    presetsLoading: boolean;
    presetsFailed: boolean;
    presetDefaultId?: string;
}
export interface WeChatCardFace {
    hooks: {
        weChatCard: SnapshotStore<WeChatCardState>;
    };
    beginLogin(): void;
    cancelLogin(): void;
    refreshLogin(): void;
    setVerificationCode(code: string): void;
    submitVerification(): void;
    editPreset(id: string): void;
    savePreset(): void;
    discardPreset(): void;
}
/** Browser settings and QR login state for the WeChat card. */
export declare class WeChatCardController {
    private readonly remote;
    private readonly scope;
    private readonly presets;
    private readonly state;
    private login;
    private qrDataUrl;
    private qrRenderError;
    private qrSource;
    private loginBusy;
    private verificationCode;
    private pollTimer;
    private disposed;
    private presetDraft;
    private presetOptions;
    private presetsLoading;
    private presetsFailed;
    private presetDefaultId;
    private saving;
    private failed;
    private failureMessage;
    constructor(remote: LoginRemote, scope: SettingsScope<Config>, presets: PresetRosterApi);
    inject(): WeChatCardFace;
    dispose(): void;
    private refreshLogin;
    private mutate;
    private applyLogin;
    private renderQr;
    private schedulePoll;
    private readPresets;
    private savePreset;
    private savedPreset;
    private snapshot;
    private publish;
}
export {};
