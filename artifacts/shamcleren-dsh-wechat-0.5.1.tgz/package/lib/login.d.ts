import type { Context, Logger } from '@deepseek-ai/cordis';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import type { WeChatAccountCredentials } from './protocol.js';
import type { WeChatAccountStore } from './storage.js';
export interface WeChatLoginAccountView {
    accountId: string;
    userId?: string;
}
export interface WeChatReceiverView {
    status: 'waiting' | 'starting' | 'running' | 'failed';
    accounts: number;
}
export type WeChatLoginView = {
    receiver?: WeChatReceiverView | undefined;
    accounts: WeChatLoginAccountView[];
} & ({
    status: 'idle';
} | {
    status: 'qr';
    flowId: string;
    qrUrl: string;
    expiresAt: number;
} | {
    status: 'scanned';
    flowId: string;
    qrUrl: string;
    expiresAt: number;
} | {
    status: 'verification-required';
    flowId: string;
    qrUrl: string;
    expiresAt: number;
} | {
    status: 'complete';
    accountId: string;
} | {
    status: 'failed';
    message: string;
});
/** Host-owned QR authorization state exposed to the settings card. */
export declare class WeChatLoginService extends TypertRemoteService {
    private readonly store;
    private readonly logger;
    private readonly onAccountAdded;
    private readonly receiver?;
    private flow;
    private settled;
    private pollTask;
    constructor(ctx: Context, store: WeChatAccountStore, logger: Logger, onAccountAdded: (account: WeChatAccountCredentials) => void | Promise<void>, receiver?: (() => WeChatReceiverView) | undefined);
    /** Read browser-safe login status and locally authorized account ids. */
    state(): WeChatLoginView;
    /** Start or reuse one QR authorization flow. */
    begin(): Promise<WeChatLoginView>;
    /** Submit the numeric confirmation requested by WeChat. */
    verify(code: string): WeChatLoginView;
    /** Cancel the active QR flow without changing authorized accounts. */
    cancel(): Promise<WeChatLoginView>;
    private view;
    private poll;
    private applyStatus;
    private waitForVerification;
    private complete;
    private fail;
    private cancelFlow;
}
