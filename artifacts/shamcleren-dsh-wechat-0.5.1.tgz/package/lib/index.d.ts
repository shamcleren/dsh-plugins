import type { Context } from '@deepseek-ai/cordis';
import { Config } from './config.js';
export { Config, DEFAULT_BASE_URL, DEFAULT_CDN_BASE_URL, DEFAULT_MEDIA_MAX_BYTES, DEFAULT_THINKING_TEXT, DEFAULT_TURN_TIMEOUT_MS, DEFAULT_WORKSPACE_NAME } from './config.js';
export type { Config as WeChatConfig } from './config.js';
export declare const name = "wechat";
export declare const inject: string[];
export declare const WECHAT_SETTINGS_NAMESPACE = "wechat";
/** Mount the personal WeChat account runtime and its settings namespace. */
export declare function apply(ctx: Context, config: Config): void;
