import type { SharedBatch } from './transport.js';
import type { LocaleKey } from './locales.js';
export interface SessionChoice {
    id: string;
    title: string;
    directory?: string | undefined;
}
export interface DraftChoice {
    id: string;
    name: string;
    size: number;
    status?: 'uploading' | 'ready' | 'error' | undefined;
}
export interface PanelProps {
    t: (key: LocaleKey) => string;
    pending: SharedBatch[];
    drafts: DraftChoice[];
    sessions: SessionChoice[];
    current?: string | undefined;
    busy: boolean;
    locked: boolean;
    notice: string;
    onChoose: (id: string) => void;
    onAdd: (batch: SharedBatch) => void;
    onDismiss: (batch: SharedBatch) => void;
    onRemove: (id: string) => void;
    onRetry: (id: string) => void;
    onRefresh: () => void;
    onReveal: () => void;
    onClearNotice: () => void;
}
export declare function fileSize(bytes: number): string;
export declare function sessionChoices(rows: SessionChoice[], query: string): SessionChoice[];
/** All controls use scoped styles, with browser-native focus and keyboard semantics. */
export declare function SharePanel(p: PanelProps): import("react").JSX.Element;
export declare const panelCSS = "\n.dsh-share{--share-line:#e5e7eb;--share-bg:#fff;--share-soft:#f6f7f9;--share-text:#252a34;--share-muted:#727985;color:var(--share-text);background:var(--share-bg);border:1px solid var(--share-line);border-radius:14px;font:13px/1.5 -apple-system,BlinkMacSystemFont,sans-serif;margin:0 20px 10px;overflow:hidden;text-align:left;box-shadow:0 2px 8px #00000004}\nbody[data-ds-dark-theme] .dsh-share{--share-line:#35383e;--share-bg:#202226;--share-soft:#292c31;--share-text:#e5e7eb;--share-muted:#a1a8b5}\n.dsh-share *{box-sizing:border-box}.dsh-share button,.dsh-share input{font:inherit}.dsh-share button{cursor:pointer;border:0;background:none;color:inherit;line-height:1.5}.dsh-share button:disabled{cursor:default;opacity:.45}.dsh-share button:focus-visible,.dsh-share input:focus-visible{outline:2px solid #4b76f8;outline-offset:2px}.dsh-share button:hover:not(:disabled){filter:brightness(.92)}\n.dsh-share-header{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:12px 16px}.dsh-share-heading{display:flex;align-items:center;gap:8px;padding:0;min-width:0}.dsh-share-heading strong{font-weight:600}.dsh-share-count{font-size:11px;background:var(--share-soft);color:var(--share-muted);border-radius:6px;padding:1px 6px}.dsh-share-chevron{color:var(--share-muted)}.dsh-share .dsh-share-link{font-size:12px;color:var(--share-muted);padding:4px}\n.dsh-share-body{padding:0 16px 10px;max-height:min(440px,48vh);overflow-y:auto}.dsh-share-target{display:flex;align-items:center;gap:12px;margin:0 0 10px;color:var(--share-muted);font-size:12px}.dsh-share .dsh-share-target-button{display:flex;align-items:center;justify-content:space-between;gap:8px;min-width:0;max-width:75%;border:1px solid var(--share-line);border-radius:8px;padding:5px 10px;color:var(--share-text);text-align:left;overflow:hidden}.dsh-share-target-button span{margin-left:8px}\n.dsh-share-picker{border:1px solid var(--share-line);padding:8px;border-radius:10px;margin-bottom:12px}.dsh-share input{display:block;width:100%;padding:8px 10px;border:1px solid var(--share-line);border-radius:7px;background:var(--share-soft);color:var(--share-text)}.dsh-share-options{max-height:210px;overflow:auto;margin-top:5px}.dsh-share-options button{display:flex;flex-direction:column;align-items:flex-start;width:100%;padding:8px;border-radius:6px;text-align:left}.dsh-share-options button:hover,.dsh-share-options button[aria-current=true]{background:var(--share-soft)}.dsh-share-options span,.dsh-share-options small{max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.dsh-share-options small{color:var(--share-muted);font-size:11px}\n.dsh-share-batch{background:var(--share-soft);border-radius:10px;padding:10px 12px;margin:8px 0}.dsh-share-file{display:flex;align-items:center;gap:10px;min-width:0;padding:4px 0}.dsh-share-icon{display:flex;align-items:center;justify-content:center;width:34px;height:38px;border:1px solid var(--share-line);border-radius:7px;background:var(--share-bg);color:#6684ca;flex-shrink:0}.dsh-share-file-text{display:flex;flex-direction:column;min-width:0;flex:1}.dsh-share-file-text>span{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-weight:500}.dsh-share-file-text small{font-size:11px;color:var(--share-muted);margin-top:2px}.dsh-share-actions{display:flex;justify-content:flex-end;align-items:center;gap:14px;margin-top:6px}.dsh-share .dsh-share-primary{background:#4775ee;color:#fff;padding:6px 14px;border-radius:8px;font-weight:500}.dsh-share .dsh-share-remove{font-size:20px;color:var(--share-muted);width:28px;height:28px;flex-shrink:0;border-radius:6px;padding:0}.dsh-share-remove:hover{background:var(--share-soft)}.dsh-share-drafts{padding:8px 0}.dsh-share-label{font-size:11px;color:var(--share-muted);margin-bottom:5px}.dsh-share-notice{display:flex;align-items:center;justify-content:space-between;gap:8px;background:var(--share-soft);border-radius:8px;padding:6px 10px;margin-top:8px;font-size:12px}.dsh-share footer{display:flex;justify-content:space-between;align-items:center;gap:8px;color:var(--share-muted);font-size:11px;margin-top:6px}.dsh-share-muted{color:var(--share-muted);padding:8px}.dsh-share-floating{position:fixed;right:24px;bottom:24px;z-index:100;width:min(420px,calc(100vw - 32px))}.dsh-share-floating .dsh-share{margin:0;box-shadow:0 8px 28px #0002;max-height:70vh;overflow:auto}@media(max-width:600px){.dsh-share{margin:0 8px 8px}.dsh-share-header{padding:10px 12px}.dsh-share-body{padding:0 12px 8px}}\n";
